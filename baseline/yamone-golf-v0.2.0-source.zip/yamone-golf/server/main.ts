import { createApp } from "./http";
import { configuredMailer } from "./mail";
const port = Number(process.env.PORT ?? 8080);
const app = createApp({
  database: process.env.DATABASE_PATH ?? "var/yamone.sqlite",
  mailer: configuredMailer(),
  origins: (
    process.env.ALLOWED_ORIGINS ??
    `http://localhost:${port},http://localhost:8081`
  ).split(","),
  secureCookie: process.env.NODE_ENV === "production",
  staticRoot: process.env.STATIC_ROOT ?? "dist",
});
app.server.listen(port, process.env.HOST ?? "127.0.0.1", () =>
  console.log(`Yamone Golf API listening on ${port}`),
);
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => app.server.close());
