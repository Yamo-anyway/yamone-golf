import { createServer, IncomingMessage, ServerResponse } from "node:http";
import { readFile } from "node:fs/promises";
import { resolve, extname, sep } from "node:path";
import { z } from "zod";
import { Identity, hash, Mailer } from "./identity";
import { openDatabase } from "./db";
import { Store } from "./store";
import { commandSchema, email, language, secret, token } from "./validation";
import { RuleError } from "../src/domain/engine";
export type ServerOptions = {
  database?: string;
  mailer: Mailer;
  clock?: () => number;
  origins?: string[];
  secureCookie?: boolean;
  staticRoot?: string;
  sweepMs?: number;
  rateLimit?: boolean;
};
export function createApp(options: ServerOptions) {
  const clock = options.clock ?? Date.now,
    db = openDatabase(options.database ?? ":memory:"),
    identity = new Identity(db, options.mailer, clock),
    store = new Store(db, identity, clock);
  const allowed = new Set(
    options.origins ?? ["http://localhost:8080", "http://localhost:8081"],
  );
  const cookieName = options.secureCookie ? "__Host-yamone" : "yamone";
  function rate(key: string, limit: number, windowMs: number) {
    if (options.rateLimit === false) return;
    const now = clock(),
      row = db.prepare("SELECT * FROM rate_limits WHERE key=?").get(key);
    if (!row || now - Number(row.window_start) >= windowMs) {
      db.prepare(
        "INSERT INTO rate_limits VALUES(?,?,1) ON CONFLICT(key) DO UPDATE SET window_start=excluded.window_start,count=1",
      ).run(key, now);
    } else {
      if (Number(row.count) >= limit) throw new RuleError("rateLimit");
      db.prepare("UPDATE rate_limits SET count=count+1 WHERE key=?").run(key);
    }
  }
  async function body(req: IncomingMessage) {
    if (!req.headers["content-type"]?.startsWith("application/json"))
      throw new RuleError("invalid");
    let size = 0;
    const chunks: Buffer[] = [];
    for await (const chunk of req) {
      size += chunk.length;
      if (size > 100000) throw new RuleError("invalid");
      chunks.push(chunk);
    }
    try {
      return JSON.parse(Buffer.concat(chunks).toString());
    } catch {
      throw new RuleError("invalid");
    }
  }
  function respond(res: ServerResponse, data: unknown, status = 200) {
    res.writeHead(status, {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    });
    res.end(JSON.stringify(data));
  }
  function setCookie(res: ServerResponse, value: string) {
    res.setHeader(
      "Set-Cookie",
      `${cookieName}=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=31536000${options.secureCookie ? "; Secure" : ""}`,
    );
  }
  const server = createServer(async (req, res) => {
    try {
      const origin = req.headers.origin;
      if (origin && !allowed.has(origin)) throw new RuleError("origin");
      if (origin) {
        res.setHeader("Access-Control-Allow-Origin", origin);
        res.setHeader("Access-Control-Allow-Credentials", "true");
        res.setHeader("Vary", "Origin");
      }
      if (req.method === "OPTIONS") {
        res.writeHead(204, {
          "Access-Control-Allow-Methods": "GET, POST",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
        });
        res.end();
        return;
      }
      const path = new URL(req.url ?? "/", "http://local").pathname;
      if (!path.startsWith("/api/")) {
        if (
          options.staticRoot &&
          (req.method === "GET" || req.method === "HEAD")
        ) {
          const root = resolve(options.staticRoot),
            file = resolve(root, "." + decodeURIComponent(path));
          if (!file.startsWith(root + sep) && file !== root)
            throw new RuleError("invalid");
          const types: Record<string, string> = {
            ".js": "application/javascript",
            ".css": "text/css",
            ".html": "text/html",
            ".png": "image/png",
            ".svg": "image/svg+xml",
            ".ttf": "font/ttf",
            ".woff2": "font/woff2",
            ".ico": "image/x-icon",
          };
          let data: Buffer, type: string;
          try {
            data = await readFile(file);
            type = types[extname(file)] ?? "application/octet-stream";
          } catch {
            data = await readFile(resolve(root, "index.html"));
            type = "text/html";
          }
          res.writeHead(200, {
            "Content-Type": type,
            "X-Content-Type-Options": "nosniff",
          });
          res.end(req.method === "HEAD" ? undefined : data);
          return;
        }
        respond(res, { error: "notFound" }, 404);
        return;
      }
      if (path === "/api/health" && req.method === "GET") {
        respond(res, { ok: true, serverTime: clock() });
        return;
      }
      const bearer = req.headers.authorization?.startsWith("Bearer ")
        ? req.headers.authorization.slice(7)
        : null;
      const cookie = (req.headers.cookie ?? "")
        .split(";")
        .map((x) => x.trim())
        .find((x) => x.startsWith(cookieName + "="))
        ?.slice(cookieName.length + 1);
      // Native clients use bearer tokens. Cookie mutations require an explicitly allowed browser origin.
      if (req.method === "POST" && cookie && !bearer && !origin)
        throw new RuleError("origin");
      const ip = req.socket.remoteAddress ?? "unknown";
      rate(`all:${ip}`, 600, 60000);
      if (path === "/api/state" && req.method === "GET") {
        const auth = identity.authenticate(bearer ?? cookie ?? "");
        store.sweep();
        if (bearer) setCookie(res, bearer);
        respond(res, { state: store.state(auth), serverTime: clock() });
        return;
      }
      if (req.method !== "POST") {
        respond(res, { error: "notFound" }, 404);
        return;
      }
      const input = await body(req);
      if (path !== "/api/command") {
        rate(`identity:${ip}`, 60, 60000);
        if (typeof input.email === "string")
          rate(
            `email:${path}:${hash(input.email.trim().toLowerCase())}`,
            path.endsWith("/request") || path.endsWith("/issue") ? 5 : 15,
            15 * 60000,
          );
      }
      let result: unknown;
      const auth = () => identity.authenticate(bearer ?? cookie ?? "");
      switch (path) {
        case "/api/users": {
          const x = z
            .object({ nickname: z.string().min(1).max(64), secret, language })
            .parse(input);
          rate(`register:${ip}`, 20, 3600000);
          result = identity.register(x.nickname, x.secret, x.language);
          setCookie(res, x.secret);
          break;
        }
        case "/api/command":
          result = {
            state: store.command(auth(), commandSchema.parse(input)),
            serverTime: clock(),
          };
          break;
        case "/api/transfer/issue": {
          const x = z
            .object({
              email,
              days: z.union([z.literal(1), z.literal(3), z.literal(5)]),
              language: z.enum(["ko", "en"]).optional(),
            })
            .parse(input);
          result = await identity.sendTransfer(
            auth(),
            x.email,
            x.days,
            x.language,
          );
          break;
        }
        case "/api/transfer/claim": {
          const x = z.object({ email, code: token, secret }).parse(input);
          result = identity.claimTransfer(x.email, x.code, x.secret);
          setCookie(res, x.secret);
          break;
        }
        case "/api/recovery/key/rotate":
          result = identity.rotateRecoveryKey(auth());
          break;
        case "/api/recovery/key/claim": {
          const x = z.object({ key: token, secret }).parse(input);
          result = identity.recoverKey(x.key, x.secret);
          setCookie(res, x.secret);
          break;
        }
        case "/api/recovery/email/register/request": {
          const x = z
            .object({ email, language: z.enum(["ko", "en"]).optional() })
            .parse(input);
          result = await identity.requestEmailVerification(
            auth(),
            x.email,
            x.language,
          );
          break;
        }
        case "/api/recovery/email/register/verify": {
          const x = z.object({ email, code: token }).parse(input);
          result = identity.verifyEmail(auth(), x.email, x.code);
          break;
        }
        case "/api/recovery/email/request": {
          const x = z
            .object({ email, language: z.enum(["ko", "en"]) })
            .parse(input);
          result = await identity.requestEmailRecovery(x.email, x.language);
          break;
        }
        case "/api/recovery/email/verify": {
          const x = z.object({ email, code: token }).parse(input);
          result = identity.verifyEmailRecovery(x.email, x.code);
          break;
        }
        case "/api/recovery/email/claim": {
          const x = z
            .object({ email, grant: token, userId: z.string().uuid(), secret })
            .parse(input);
          result = identity.claimEmail(x.email, x.grant, x.userId, x.secret);
          setCookie(res, x.secret);
          break;
        }
        case "/api/device/reset":
          res.setHeader(
            "Set-Cookie",
            `${cookieName}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${options.secureCookie ? "; Secure" : ""}`,
          );
          result = { ok: true };
          break;
        default:
          respond(res, { error: "notFound" }, 404);
          return;
      }
      respond(res, result);
    } catch (e) {
      const code =
        e instanceof RuleError
          ? e.code
          : e instanceof z.ZodError
            ? "invalid"
            : "server";
      const status = ["unauthorized", "deviceMoved"].includes(code)
        ? 401
        : code === "permission" || code === "origin"
          ? 403
          : code === "conflict"
            ? 409
            : code === "rateLimit"
              ? 429
              : code === "mailUnavailable" || code === "server"
                ? 503
                : 400;
      respond(
        res,
        {
          error: code,
          ...(e instanceof RuleError && e.details
            ? { details: e.details }
            : {}),
        },
        status,
      );
    }
  });
  store.sweep();
  const interval = setInterval(() => {
    try {
      store.sweep();
    } catch (e) {
      console.error(
        "Round expiry failed",
        e instanceof Error ? e.message : "unknown",
      );
    }
  }, options.sweepMs ?? 60000);
  interval.unref();
  server.on("close", () => {
    clearInterval(interval);
    db.close();
  });
  return { server, db, identity, store };
}
