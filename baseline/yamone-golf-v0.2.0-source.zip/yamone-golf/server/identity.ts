import {
  createHash,
  randomInt,
  randomUUID,
  timingSafeEqual,
} from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { transaction } from "./db";
import { RuleError } from "../src/domain/engine";
import { DAY, Profile } from "../src/domain/model";
export type MailMessage = {
  to: string;
  kind: "transfer" | "verify-email" | "recover-email";
  code: string;
  expiresAt: number;
  language: "ko" | "en";
  requestId: string;
};
export interface Mailer {
  send(message: MailMessage): Promise<void>;
}
export type UserRow = {
  id: string;
  nickname: string;
  personal_code: string;
  language: "system" | "ko" | "en";
  created_at: number;
  active_device_id: string;
};
export type Auth = { user: UserRow; deviceId: string };
type Ticket = {
  id: string;
  purpose: string;
  user_id: string | null;
  email: string | null;
  token_hash: string;
  expires_at: number;
  used_at: number | null;
  attempts: number;
  issuer_device_id: string | null;
};
export const hash = (s: string) => createHash("sha256").update(s).digest("hex");
export const cleanCode = (s: string) => s.toUpperCase().replace(/[\s-]/g, "");
export const cleanEmail = (s: string) => s.trim().toLowerCase();
const alphabet = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
function code(n: number, prefix = "") {
  let s = "";
  for (let i = 0; i < n; i++) s += alphabet[randomInt(alphabet.length)];
  return prefix + s.match(/.{1,4}/g)!.join("-");
}
const check = (ok: unknown, error: string): void => {
  if (!ok) throw new RuleError(error);
};
export class Identity {
  constructor(
    public db: DatabaseSync,
    public mailer: Mailer,
    public clock: () => number = Date.now,
  ) {}
  user(id: string): UserRow {
    const row = this.db
      .prepare("SELECT * FROM users WHERE id=?")
      .get(id) as unknown as UserRow | undefined;
    check(row, "identity");
    return row!;
  }
  authenticate(secret: string): Auth {
    check(/^[a-f0-9]{64}$/.test(secret), "unauthorized");
    const d = this.db
      .prepare("SELECT * FROM devices WHERE token_hash=?")
      .get(hash(secret)) as
      { id: string; user_id: string; revoked_at: number | null } | undefined;
    check(d, "unauthorized");
    const u = this.user(d!.user_id);
    check(
      d!.revoked_at === null && u.active_device_id === d!.id,
      "deviceMoved",
    );
    return { user: u, deviceId: d!.id };
  }
  info(u: UserRow): Profile {
    return {
      id: u.id,
      nickname: u.nickname,
      language: u.language,
      personalCode: u.personal_code,
      personalQr: `yamone-golf:user:${u.personal_code}`,
      createdAt: u.created_at,
      recoveryEmail:
        (
          this.db
            .prepare("SELECT email FROM recovery_emails WHERE user_id=?")
            .get(u.id) as { email: string } | undefined
        )?.email ?? null,
    };
  }
  register(nickname: string, secret: string, language: "ko" | "en" | "system") {
    check(/^[a-f0-9]{64}$/.test(secret), "invalid");
    check(
      nickname.trim().length > 0 && [...nickname.trim()].length <= 16,
      "name",
    );
    const existing = this.db
      .prepare("SELECT id FROM devices WHERE token_hash=?")
      .get(hash(secret));
    if (existing) {
      const auth = this.authenticate(secret);
      return { profile: this.info(auth.user), recoveryKey: null };
    }
    return transaction(this.db, () => {
      const now = this.clock(),
        id = randomUUID(),
        deviceId = randomUUID(),
        personal = code(12, "P-"),
        recoveryKey = code(32, "YMGF-");
      this.db
        .prepare("INSERT INTO users VALUES(?,?,?,?,?,?)")
        .run(id, nickname.trim(), personal, language, now, deviceId);
      this.db
        .prepare("INSERT INTO devices VALUES(?,?,?,?,NULL)")
        .run(deviceId, id, hash(secret), now);
      this.db
        .prepare("INSERT INTO recovery_keys VALUES(?,?,?)")
        .run(hash(cleanCode(recoveryKey)), id, now);
      return { profile: this.info(this.user(id)), recoveryKey };
    });
  }
  assertActive(auth: Auth) {
    const u = this.user(auth.user.id);
    check(u.active_device_id === auth.deviceId, "deviceMoved");
  }
  rotateRecoveryKey(auth: Auth) {
    this.assertActive(auth);
    return transaction(this.db, () => {
      const key = code(32, "YMGF-");
      this.db
        .prepare("DELETE FROM recovery_keys WHERE user_id=?")
        .run(auth.user.id);
      this.db
        .prepare("INSERT INTO recovery_keys VALUES(?,?,?)")
        .run(hash(cleanCode(key)), auth.user.id, this.clock());
      return { recoveryKey: key };
    });
  }
  async sendTransfer(
    auth: Auth,
    email: string,
    days: 1 | 3 | 5,
    language?: "ko" | "en",
  ) {
    this.assertActive(auth);
    const value = code(16),
      now = this.clock(),
      id = randomUUID();
    transaction(this.db, () => {
      this.db
        .prepare(
          "UPDATE tickets SET used_at=? WHERE user_id=? AND purpose='transfer' AND used_at IS NULL",
        )
        .run(now, auth.user.id);
      this.insertTicket(
        id,
        "transfer",
        auth.user.id,
        cleanEmail(email),
        value,
        now + days * DAY,
        auth.deviceId,
      );
    });
    try {
      await this.mailer.send({
        to: cleanEmail(email),
        kind: "transfer",
        code: value,
        expiresAt: now + days * DAY,
        language: language ?? (auth.user.language === "ko" ? "ko" : "en"),
        requestId: id,
      });
    } catch {
      this.db
        .prepare("UPDATE tickets SET used_at=? WHERE id=?")
        .run(this.clock(), id);
      throw new RuleError("mailUnavailable");
    }
    this.assertActive(auth);
    return { expiresAt: now + days * DAY };
  }
  insertTicket(
    id: string,
    purpose: string,
    userId: string | null,
    email: string | null,
    token: string,
    expiresAt: number,
    deviceId: string | null = null,
  ) {
    this.db
      .prepare(
        "INSERT INTO tickets(id,purpose,user_id,email,token_hash,created_at,expires_at,issuer_device_id) VALUES(?,?,?,?,?,?,?,?)",
      )
      .run(
        id,
        purpose,
        userId,
        email,
        hash(cleanCode(token)),
        this.clock(),
        expiresAt,
        deviceId,
      );
  }
  // Failed attempts commit outside a claim transaction. A later successful claim rechecks under BEGIN IMMEDIATE.
  verifyTicket(
    purpose: string,
    email: string,
    token: string,
    userId?: string,
  ): Ticket {
    const rows = this.db
      .prepare(
        "SELECT * FROM tickets WHERE purpose=? AND email=? AND used_at IS NULL AND expires_at>? ORDER BY created_at DESC",
      )
      .all(purpose, cleanEmail(email), this.clock()) as unknown as Ticket[];
    const candidates = rows.filter((x) => !userId || x.user_id === userId);
    const digest = hash(cleanCode(token));
    const ticket = candidates.find(
      (t) =>
        t.attempts < 5 &&
        timingSafeEqual(
          Buffer.from(t.token_hash, "hex"),
          Buffer.from(digest, "hex"),
        ),
    );
    if (!ticket) {
      for (const row of candidates)
        this.db
          .prepare("UPDATE tickets SET attempts=attempts+1 WHERE id=?")
          .run(row.id);
      throw new RuleError("invalidCode");
    }
    return ticket;
  }
  activeTicket(id: string) {
    const t = this.db
      .prepare("SELECT * FROM tickets WHERE id=?")
      .get(id) as unknown as Ticket;
    check(
      t && t.used_at === null && t.expires_at > this.clock() && t.attempts < 5,
      "invalidCode",
    );
    return t;
  }
  activate(userId: string, newSecret: string, kind: string) {
    check(/^[a-f0-9]{64}$/.test(newSecret), "invalid");
    const now = this.clock(),
      u = this.user(userId);
    const existing = this.db
      .prepare("SELECT * FROM devices WHERE token_hash=?")
      .get(hash(newSecret)) as
      { id: string; user_id: string; revoked_at: number | null } | undefined;
    check(
      !existing ||
        (existing.user_id === userId &&
          existing.revoked_at === null &&
          existing.id === u.active_device_id),
      "deviceUsed",
    );
    const deviceId = existing?.id ?? randomUUID();
    this.db
      .prepare(
        "UPDATE devices SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL AND id<>?",
      )
      .run(now, userId, deviceId);
    if (!existing)
      this.db
        .prepare("INSERT INTO devices VALUES(?,?,?,?,NULL)")
        .run(deviceId, userId, hash(newSecret), now);
    this.db
      .prepare("UPDATE users SET active_device_id=? WHERE id=?")
      .run(deviceId, userId);
    this.db
      .prepare(
        "UPDATE tickets SET used_at=? WHERE user_id=? AND used_at IS NULL",
      )
      .run(now, userId);
    const email = (
      this.db
        .prepare("SELECT email FROM recovery_emails WHERE user_id=?")
        .get(userId) as { email: string } | undefined
    )?.email;
    if (email)
      this.db
        .prepare(
          "UPDATE tickets SET used_at=? WHERE email=? AND purpose IN ('recover-email','email-grant') AND used_at IS NULL",
        )
        .run(now, email);
    this.db
      .prepare("INSERT INTO device_events VALUES(?,?,?,?,?,?)")
      .run(randomUUID(), userId, u.active_device_id, deviceId, kind, now);
    return this.info(this.user(userId));
  }
  claimTransfer(email: string, token: string, newSecret: string) {
    const ticket = this.verifyTicket("transfer", email, token);
    return transaction(this.db, () => {
      const t = this.activeTicket(ticket.id);
      const u = this.user(t.user_id!);
      check(u.active_device_id === t.issuer_device_id, "invalidCode");
      return { profile: this.activate(u.id, newSecret, "transfer") };
    });
  }
  async requestEmailVerification(
    auth: Auth,
    email: string,
    language?: "ko" | "en",
  ) {
    this.assertActive(auth);
    const id = randomUUID(),
      token = String(randomInt(10000000, 100000000)),
      address = cleanEmail(email),
      expiry = this.clock() + 15 * 60 * 1000;
    transaction(this.db, () => {
      this.db
        .prepare(
          "UPDATE tickets SET used_at=? WHERE user_id=? AND purpose='verify-email' AND used_at IS NULL",
        )
        .run(this.clock(), auth.user.id);
      this.insertTicket(
        id,
        "verify-email",
        auth.user.id,
        address,
        token,
        expiry,
        auth.deviceId,
      );
    });
    try {
      await this.mailer.send({
        to: address,
        kind: "verify-email",
        code: token,
        expiresAt: expiry,
        language: language ?? (auth.user.language === "ko" ? "ko" : "en"),
        requestId: id,
      });
    } catch {
      this.db
        .prepare("UPDATE tickets SET used_at=? WHERE id=?")
        .run(this.clock(), id);
      throw new RuleError("mailUnavailable");
    }
    this.assertActive(auth);
    return { expiresAt: expiry };
  }
  verifyEmail(auth: Auth, email: string, token: string) {
    this.assertActive(auth);
    const ticket = this.verifyTicket(
      "verify-email",
      email,
      token,
      auth.user.id,
    );
    return transaction(this.db, () => {
      const t = this.activeTicket(ticket.id);
      check(t.issuer_device_id === auth.deviceId, "invalidCode");
      this.db
        .prepare(
          "INSERT INTO recovery_emails VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET email=excluded.email,verified_at=excluded.verified_at",
        )
        .run(auth.user.id, cleanEmail(email), this.clock());
      this.db
        .prepare("UPDATE tickets SET used_at=? WHERE id=?")
        .run(this.clock(), t.id);
      return { profile: this.info(this.user(auth.user.id)) };
    });
  }
  async requestEmailRecovery(email: string, language: "ko" | "en") {
    const address = cleanEmail(email);
    const users = this.db
      .prepare("SELECT user_id FROM recovery_emails WHERE email=?")
      .all(address);
    if (!users.length) return { requested: true };
    const id = randomUUID(),
      token = String(randomInt(10000000, 100000000)),
      expiry = this.clock() + 15 * 60 * 1000;
    transaction(this.db, () => {
      this.db
        .prepare(
          "UPDATE tickets SET used_at=? WHERE email=? AND purpose IN ('recover-email','email-grant') AND used_at IS NULL",
        )
        .run(this.clock(), address);
      this.insertTicket(id, "recover-email", null, address, token, expiry);
    });
    try {
      await this.mailer.send({
        to: address,
        kind: "recover-email",
        code: token,
        expiresAt: expiry,
        language,
        requestId: id,
      });
    } catch {
      this.db
        .prepare("UPDATE tickets SET used_at=? WHERE id=?")
        .run(this.clock(), id);
      throw new RuleError("mailUnavailable");
    }
    return { requested: true };
  }
  verifyEmailRecovery(email: string, token: string) {
    const ticket = this.verifyTicket("recover-email", email, token);
    return transaction(this.db, () => {
      const t = this.activeTicket(ticket.id);
      const grant = code(32);
      this.db
        .prepare("UPDATE tickets SET used_at=? WHERE id=?")
        .run(this.clock(), t.id);
      this.insertTicket(
        randomUUID(),
        "email-grant",
        null,
        cleanEmail(email),
        grant,
        this.clock() + 10 * 60 * 1000,
      );
      const accounts = this.db
        .prepare(
          "SELECT u.id,u.nickname,u.personal_code FROM users u JOIN recovery_emails e ON e.user_id=u.id WHERE e.email=?",
        )
        .all(cleanEmail(email));
      return { grant, accounts };
    });
  }
  claimEmail(email: string, grant: string, userId: string, newSecret: string) {
    const ticket = this.verifyTicket("email-grant", email, grant);
    return transaction(this.db, () => {
      this.activeTicket(ticket.id);
      check(
        this.db
          .prepare(
            "SELECT user_id FROM recovery_emails WHERE user_id=? AND email=?",
          )
          .get(userId, cleanEmail(email)),
        "invalidCode",
      );
      return { profile: this.activate(userId, newSecret, "email-recovery") };
    });
  }
  recoverKey(key: string, newSecret: string) {
    return transaction(this.db, () => {
      const row = this.db
        .prepare("SELECT user_id FROM recovery_keys WHERE token_hash=?")
        .get(hash(cleanCode(key))) as { user_id: string } | undefined;
      check(row, "invalidCode");
      const profile = this.activate(row!.user_id, newSecret, "key-recovery");
      const recoveryKey = code(32, "YMGF-");
      this.db
        .prepare("DELETE FROM recovery_keys WHERE user_id=?")
        .run(row!.user_id);
      this.db
        .prepare("INSERT INTO recovery_keys VALUES(?,?,?)")
        .run(hash(cleanCode(recoveryKey)), row!.user_id, this.clock());
      return { profile, recoveryKey };
    });
  }
}
