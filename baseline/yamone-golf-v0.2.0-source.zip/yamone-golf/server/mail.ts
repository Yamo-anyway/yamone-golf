import nodemailer from "nodemailer";
import { Mailer, MailMessage } from "./identity";
import { RuleError } from "../src/domain/engine";
import { translator } from "../src/ui/i18n";
export function configuredMailer(): Mailer {
  if (!process.env.SMTP_HOST || !process.env.MAIL_FROM)
    return {
      send: async () => {
        throw new RuleError("mailUnavailable");
      },
    };
  const port = Number(process.env.SMTP_PORT ?? 587);
  const transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure: port === 465,
    requireTLS: port !== 465,
    auth: process.env.SMTP_USER
      ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD }
      : undefined,
    connectionTimeout: 10000,
    socketTimeout: 15000,
  });
  return {
    send: async (m: MailMessage) => {
      const t = translator(m.language);
      const subject = t(
        m.kind === "transfer"
          ? "mailTransfer"
          : m.kind === "verify-email"
            ? "mailVerify"
            : "mailRecover",
      );
      await transport.sendMail({
        from: process.env.MAIL_FROM,
        to: m.to,
        subject,
        text: `${subject}\n\n${m.code}\n\n${t("mailExpires")}: ${new Date(m.expiresAt).toISOString()}\n${t("mailCaution")}`,
      });
    },
  };
}
