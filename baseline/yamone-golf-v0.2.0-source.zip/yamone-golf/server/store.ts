import { randomBytes, randomUUID } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { applyCommand, expireRounds, RuleError } from "../src/domain/engine";
import {
  Command,
  Course,
  EMPTY_STATE,
  Round,
  State,
} from "../src/domain/model";
import { Auth, Identity } from "./identity";
import { transaction } from "./db";
const check = (ok: unknown, code: string): void => {
  if (!ok) throw new RuleError(code);
};
export class Store {
  constructor(
    public db: DatabaseSync,
    public identity: Identity,
    public clock = Date.now,
  ) {
    db.exec(`
 CREATE TABLE IF NOT EXISTS player_slots(id TEXT NOT NULL,round_id TEXT NOT NULL REFERENCES rounds(id),user_id TEXT,name TEXT NOT NULL,sort_order INTEGER NOT NULL,PRIMARY KEY(round_id,id));
 CREATE TABLE IF NOT EXISTS scores(round_id TEXT NOT NULL,player_id TEXT NOT NULL,hole INTEGER NOT NULL,value INTEGER,version INTEGER NOT NULL,PRIMARY KEY(round_id,player_id,hole));
 CREATE TABLE IF NOT EXISTS input_targets(round_id TEXT NOT NULL,user_id TEXT NOT NULL,player_id TEXT NOT NULL,sort_order INTEGER NOT NULL,PRIMARY KEY(round_id,user_id,player_id));
 CREATE TABLE IF NOT EXISTS participant_rights(round_id TEXT NOT NULL,user_id TEXT NOT NULL,can_end INTEGER NOT NULL,PRIMARY KEY(round_id,user_id));
 CREATE TABLE IF NOT EXISTS receipts(round_id TEXT NOT NULL,user_id TEXT NOT NULL,received_at INTEGER NOT NULL,deleted_at INTEGER,PRIMARY KEY(round_id,user_id));
 CREATE TABLE IF NOT EXISTS deliveries(id TEXT PRIMARY KEY,round_id TEXT NOT NULL,player_id TEXT NOT NULL,user_id TEXT NOT NULL,status TEXT NOT NULL,created_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS score_audit(round_id TEXT NOT NULL,ordinal INTEGER NOT NULL,document TEXT NOT NULL,PRIMARY KEY(round_id,ordinal));
 CREATE TABLE IF NOT EXISTS invitations(id TEXT PRIMARY KEY,round_id TEXT NOT NULL REFERENCES rounds(id),user_id TEXT NOT NULL REFERENCES users(id),status TEXT NOT NULL,created_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS peoria_runs(id TEXT PRIMARY KEY,round_id TEXT NOT NULL,ordinal INTEGER NOT NULL CHECK(ordinal BETWEEN 1 AND 3),calculated_at INTEGER NOT NULL,actor_id TEXT NOT NULL,target_players TEXT NOT NULL,excluded_players TEXT NOT NULL,score_snapshot TEXT NOT NULL,results TEXT NOT NULL,hidden_holes TEXT NOT NULL,UNIQUE(round_id,ordinal));
 CREATE INDEX IF NOT EXISTS active_invitations ON invitations(user_id,status);
 `);
  }
  round(id: string): Round {
    const row = this.db
      .prepare("SELECT document FROM rounds WHERE id=?")
      .get(id) as { document: string } | undefined;
    check(row, "round");
    const r = JSON.parse(row!.document) as Round;
    r.players = this.db
      .prepare(
        "SELECT * FROM player_slots WHERE round_id=? ORDER BY sort_order",
      )
      .all(id)
      .map((p) => ({
        id: String(p.id),
        name: String(p.name),
        userId: p.user_id === null ? null : String(p.user_id),
        scores: this.db
          .prepare(
            "SELECT value,version FROM scores WHERE round_id=? AND player_id=? ORDER BY hole",
          )
          .all(id, p.id)
          .map((s) => ({
            value: s.value === null ? null : Number(s.value),
            version: Number(s.version),
          })),
      }));
    r.participants = this.db
      .prepare(
        "SELECT p.user_id,coalesce(r.can_end,0) AS can_end FROM round_participants p LEFT JOIN participant_rights r ON r.round_id=p.round_id AND r.user_id=p.user_id WHERE p.round_id=?",
      )
      .all(id)
      .map((p) => ({
        userId: String(p.user_id),
        canEnd: !!p.can_end,
        targets: this.db
          .prepare(
            "SELECT player_id FROM input_targets WHERE round_id=? AND user_id=? ORDER BY sort_order",
          )
          .all(id, p.user_id)
          .map((t) => String(t.player_id)),
      }));
    r.receipts = this.db
      .prepare("SELECT * FROM receipts WHERE round_id=?")
      .all(id)
      .map((x) => ({
        userId: String(x.user_id),
        receivedAt: Number(x.received_at),
        deletedAt: x.deleted_at === null ? null : Number(x.deleted_at),
      }));
    r.deliveries = this.db
      .prepare("SELECT * FROM deliveries WHERE round_id=? ORDER BY created_at")
      .all(id)
      .map((x) => ({
        id: String(x.id),
        playerId: String(x.player_id),
        userId: String(x.user_id),
        status: x.status as "pending" | "received" | "cancelled",
        createdAt: Number(x.created_at),
      }));
    r.audit = this.db
      .prepare(
        "SELECT document FROM score_audit WHERE round_id=? ORDER BY ordinal",
      )
      .all(id)
      .map((x) => JSON.parse(String(x.document)));
    r.joinCode = String(
      this.db.prepare("SELECT code FROM round_codes WHERE round_id=?").get(id)
        ?.code ?? "",
    );
    return r;
  }
  saveRound(r: Round) {
    const {
      players,
      participants,
      receipts,
      audit,
      deliveries,
      joinCode,
      ...meta
    } = r;
    this.db
      .prepare(
        "INSERT INTO rounds VALUES(?,?) ON CONFLICT(id) DO UPDATE SET document=excluded.document",
      )
      .run(r.id, JSON.stringify(meta));
    if (
      !this.db
        .prepare("SELECT code FROM round_codes WHERE round_id=?")
        .get(r.id)
    )
      this.db
        .prepare("INSERT INTO round_codes VALUES(?,?)")
        .run(r.id, joinCode || randomBytes(8).toString("hex").toUpperCase());
    // Round document holds metadata only. Separate relations are the sole source for each entity.
    for (const table of [
      "player_slots",
      "scores",
      "round_participants",
      "input_targets",
      "participant_rights",
      "receipts",
      "deliveries",
      "score_audit",
    ])
      this.db.prepare(`DELETE FROM ${table} WHERE round_id=?`).run(r.id);
    players.forEach((p, i) => {
      this.db
        .prepare("INSERT INTO player_slots VALUES(?,?,?,?,?)")
        .run(p.id, r.id, p.userId, p.name, i);
      p.scores.forEach((s, h) =>
        this.db
          .prepare("INSERT INTO scores VALUES(?,?,?,?,?)")
          .run(r.id, p.id, h, s.value, s.version),
      );
    });
    participants.forEach((p) => {
      this.db
        .prepare("INSERT INTO round_participants VALUES(?,?)")
        .run(r.id, p.userId);
      this.db
        .prepare("INSERT INTO participant_rights VALUES(?,?,?)")
        .run(r.id, p.userId, Number(p.canEnd));
      p.targets.forEach((id, i) =>
        this.db
          .prepare("INSERT INTO input_targets VALUES(?,?,?,?)")
          .run(r.id, p.userId, id, i),
      );
    });
    receipts.forEach((x) =>
      this.db
        .prepare("INSERT INTO receipts VALUES(?,?,?,?)")
        .run(r.id, x.userId, x.receivedAt, x.deletedAt ?? null),
    );
    (deliveries ?? []).forEach((x) =>
      this.db
        .prepare("INSERT INTO deliveries VALUES(?,?,?,?,?,?)")
        .run(
          x.id.startsWith("pending:") ? randomUUID() : x.id,
          r.id,
          x.playerId,
          x.userId,
          x.status,
          x.createdAt,
        ),
    );
    audit.forEach((x, i) =>
      this.db
        .prepare("INSERT INTO score_audit VALUES(?,?,?)")
        .run(r.id, i, JSON.stringify(x)),
    );
  }
  sweep() {
    transaction(this.db, () => {
      const rounds = this.db
        .prepare("SELECT id FROM rounds")
        .all()
        .map((x) => this.round(String(x.id)));
      const state = { ...EMPTY_STATE, rounds };
      const next = expireRounds(state, this.clock());
      if (next !== state)
        next.rounds.forEach((r, i) => {
          if (r !== rounds[i]) this.saveRound(r);
        });
    });
  }
  state(auth: Auth): State {
    this.identity.assertActive(auth);
    const uid = auth.user.id;
    return {
      schemaVersion: 1,
      profile: this.identity.info(this.identity.user(uid)),
      session: true,
      courses: this.db
        .prepare(
          "SELECT c.document FROM user_courses u JOIN courses c ON u.course_id=c.id WHERE u.user_id=? ORDER BY u.sort_order",
        )
        .all(uid)
        .map((x) => JSON.parse(String(x.document)) as Course),
      rounds: this.db
        .prepare("SELECT round_id FROM round_participants WHERE user_id=?")
        .all(uid)
        .map((x) => this.round(String(x.round_id)))
        .sort((a, b) => b.createdAt - a.createdAt),
      invitations: this.db
        .prepare(
          "SELECT i.id,i.round_id,r.document FROM invitations i JOIN rounds r ON r.id=i.round_id WHERE i.user_id=? AND i.status='pending'",
        )
        .all(uid)
        .flatMap((x) => {
          const r = JSON.parse(String(x.document));
          return r.status === "active"
            ? [
                {
                  id: String(x.id),
                  roundId: String(x.round_id),
                  courseName: r.courseName,
                },
              ]
            : [];
        }),
    };
  }
  command(auth: Auth, command: Command) {
    this.sweep();
    return transaction(this.db, () => {
      this.identity.assertActive(auth);
      const state = this.state(auth),
        uid = auth.user.id;
      if (command.type === "session" || command.type === "tick")
        throw new RuleError("invalid");
      if (command.type === "join" || command.type === "acceptInvite") {
        let roundId: string;
        if (command.type === "join") {
          const row = this.db
            .prepare("SELECT round_id FROM round_codes WHERE code=?")
            .get(command.code.trim().toUpperCase());
          check(row, "round");
          roundId = String(row!.round_id);
        } else {
          const row = this.db
            .prepare(
              "SELECT round_id FROM invitations WHERE id=? AND user_id=? AND status='pending'",
            )
            .get(command.invitationId, uid);
          check(row, "invalid");
          roundId = String(row!.round_id);
        }
        const r = this.round(roundId);
        check(r.status === "active", "ended");
        if (!r.participants.some((p) => p.userId === uid)) {
          check(!state.rounds.some((r) => r.status === "active"), "active");
          r.participants.push({ userId: uid, canEnd: false, targets: [] });
          r.lastActivityAt = this.clock();
          this.saveRound(r);
        }
        this.db
          .prepare(
            "UPDATE invitations SET status='accepted' WHERE round_id=? AND user_id=? AND status='pending'",
          )
          .run(roundId, uid);
      } else if (command.type === "cancelInvite") {
        this.db
          .prepare(
            "UPDATE invitations SET status='cancelled' WHERE id=? AND user_id=? AND status='pending'",
          )
          .run(command.invitationId, uid);
      } else if (command.type === "invite") {
        const roundId = command.roundId;
        const r = state.rounds.find((r) => r.id === roundId);
        check(r && r.status === "active", "permission");
        const target = this.db
          .prepare("SELECT id FROM users WHERE personal_code=?")
          .get(command.personalCode.trim().toUpperCase());
        check(target && target.id !== uid, "identity");
        check(
          !r!.participants.some((p) => p.userId === target!.id),
          "duplicate",
        );
        check(
          !this.db
            .prepare(
              "SELECT id FROM invitations WHERE round_id=? AND user_id=? AND status='pending'",
            )
            .get(r!.id, target!.id),
          "duplicate",
        );
        this.db
          .prepare("INSERT INTO invitations VALUES(?,?,?,?,?)")
          .run(randomUUID(), r!.id, target!.id, "pending", this.clock());
      } else {
        if (command.type === "profile")
          command = {
            type: "profile",
            profile: {
              ...state.profile!,
              nickname: command.profile.nickname,
              language: command.profile.language,
            },
          };
        if (command.type === "create")
          check(
            !this.db
              .prepare("SELECT id FROM rounds WHERE id=?")
              .get(command.id),
            "duplicate",
          );
        if (command.type === "course") {
          const courseId = command.course.id;
          check(
            !this.db
              .prepare("SELECT id FROM courses WHERE id=?")
              .get(courseId) || state.courses.some((c) => c.id === courseId),
            "permission",
          );
        }
        const next = applyCommand(state, command, this.clock());
        if (command.type === "profile")
          this.db
            .prepare("UPDATE users SET nickname=?,language=? WHERE id=?")
            .run(next.profile!.nickname, next.profile!.language, uid);
        if (["course", "courseOrder", "removeCourse"].includes(command.type)) {
          this.db.prepare("DELETE FROM user_courses WHERE user_id=?").run(uid);
          next.courses.forEach((c, i) => {
            this.db
              .prepare(
                "INSERT INTO courses VALUES(?,?) ON CONFLICT(id) DO UPDATE SET document=excluded.document",
              )
              .run(c.id, JSON.stringify(c));
            this.db
              .prepare("INSERT INTO user_courses VALUES(?,?,?,NULL)")
              .run(uid, c.id, i);
          });
        }
        next.rounds.forEach((r) => {
          if (state.rounds.find((x) => x.id === r.id) !== r) this.saveRound(r);
        });
      }
      return this.state(auth);
    });
  }
}
