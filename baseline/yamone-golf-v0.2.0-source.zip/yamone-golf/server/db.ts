import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
export function openDatabase(file: string) {
  if (file !== ":memory:") mkdirSync(dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
  CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,nickname TEXT NOT NULL,personal_code TEXT UNIQUE NOT NULL,language TEXT NOT NULL,created_at INTEGER NOT NULL,active_device_id TEXT);
  CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),token_hash TEXT UNIQUE NOT NULL,created_at INTEGER NOT NULL,revoked_at INTEGER);
  CREATE TABLE IF NOT EXISTS recovery_keys(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),created_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS recovery_emails(user_id TEXT PRIMARY KEY REFERENCES users(id),email TEXT NOT NULL,verified_at INTEGER NOT NULL);
  CREATE INDEX IF NOT EXISTS recovery_email_address ON recovery_emails(email);
  CREATE TABLE IF NOT EXISTS tickets(id TEXT PRIMARY KEY,purpose TEXT NOT NULL,user_id TEXT,email TEXT,token_hash TEXT NOT NULL,created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,used_at INTEGER,attempts INTEGER NOT NULL DEFAULT 0,issuer_device_id TEXT);
  CREATE INDEX IF NOT EXISTS ticket_lookup ON tickets(purpose,email,created_at);
  CREATE TABLE IF NOT EXISTS courses(id TEXT PRIMARY KEY,document TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS user_courses(user_id TEXT NOT NULL REFERENCES users(id),course_id TEXT NOT NULL REFERENCES courses(id),sort_order INTEGER NOT NULL,alias TEXT,PRIMARY KEY(user_id,course_id));
  CREATE TABLE IF NOT EXISTS rounds(id TEXT PRIMARY KEY,document TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS round_participants(round_id TEXT NOT NULL REFERENCES rounds(id),user_id TEXT NOT NULL REFERENCES users(id),PRIMARY KEY(round_id,user_id));
  CREATE TABLE IF NOT EXISTS round_codes(round_id TEXT PRIMARY KEY REFERENCES rounds(id),code TEXT UNIQUE NOT NULL);
  CREATE TABLE IF NOT EXISTS rate_limits(key TEXT PRIMARY KEY,window_start INTEGER NOT NULL,count INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS device_events(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,old_device_id TEXT,new_device_id TEXT,kind TEXT NOT NULL,created_at INTEGER NOT NULL);
  `);
  return db;
}
export function transaction<T>(db: DatabaseSync, fn: () => T): T {
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = fn();
    db.exec("COMMIT");
    return result;
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}
