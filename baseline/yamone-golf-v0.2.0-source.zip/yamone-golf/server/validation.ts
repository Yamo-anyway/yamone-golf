import { z } from "zod";
const id = z.string().min(1).max(80),
  name = z.string().trim().min(1).max(80),
  round = { roundId: id },
  player = { ...round, playerId: id };
export const language = z.enum(["ko", "en", "system"]);
export const email = z.string().trim().email().max(254);
export const secret = z.string().regex(/^[a-f0-9]{64}$/);
export const token = z.string().min(1).max(200);
export const commandSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("profile"),
    profile: z.object({ id, nickname: name, language }),
  }),
  z.object({
    type: z.literal("course"),
    course: z.object({
      id,
      name,
      location: z.string().max(120),
      segments: z
        .array(
          z.object({
            id,
            name,
            pars: z
              .array(
                z.union([
                  z.literal(3),
                  z.literal(4),
                  z.literal(5),
                  z.literal(6),
                  z.literal(7),
                ]),
              )
              .length(9),
          }),
        )
        .min(1)
        .max(9),
    }),
  }),
  z.object({
    type: z.literal("create"),
    id,
    courseId: id,
    segmentIds: z.array(id).min(1).max(2),
    players: z
      .array(z.object({ id, name, self: z.boolean() }))
      .min(1)
      .max(8),
  }),
  z.object({
    type: z.literal("targets"),
    ...round,
    targets: z.array(id).max(8),
  }),
  z.object({ type: z.literal("addPlayer"), ...round, id, name }),
  z.object({ type: z.literal("renamePlayer"), ...player, name }),
  z.object({ type: z.literal("linkSelf"), ...player }),
  z.object({ type: z.literal("unlinkPlayer"), ...player, name }),
  z.object({ type: z.literal("deletePlayer"), ...player }),
  z.object({
    type: z.literal("scores"),
    ...round,
    changes: z
      .array(
        z.object({
          playerId: id,
          hole: z.number().int().min(0).max(17),
          value: z.number().int().min(1).max(99).nullable(),
          expectedVersion: z.number().int().min(0),
        }),
      )
      .min(1)
      .max(144),
  }),
  z.object({ type: z.literal("end"), ...round }),
  z.object({ type: z.literal("receive"), ...round }),
  z.object({ type: z.literal("join"), code: token }),
  z.object({ type: z.literal("invite"), ...round, personalCode: token }),
  z.object({ type: z.literal("acceptInvite"), invitationId: id }),
  z.object({ type: z.literal("cancelInvite"), invitationId: id }),
  z.object({ type: z.literal("courseOrder"), ids: z.array(id).max(1000) }),
  z.object({ type: z.literal("removeCourse"), courseId: id }),
  z.object({
    type: z.literal("delegateEnd"),
    ...round,
    userId: id,
    enabled: z.boolean(),
  }),
  z.object({ type: z.literal("sendRecord"), ...player }),
  z.object({ type: z.literal("cancelDelivery"), ...round, deliveryId: id }),
  z.object({ type: z.literal("deleteReceipt"), ...round }),
]);
