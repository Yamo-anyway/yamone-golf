# Yamone Golf v0.2.0

닉네임만 입력해 시작하는 골프 공동 기록 앱입니다. 닉네임 중복을 허용하며 **서버가 만든 `user_id`**로 사용자를 구분합니다. 일반 이메일·소셜 로그인은 사용하지 않습니다.

이번 버전은 Expo SDK 57 모바일 앱과 Node.js 24/SQLite API를 연결한 개발 소스입니다. 사용자 생성, 기기 이전·복구, 공동 기록, 서버 시간·권한 검사까지 구현했습니다. 출시용 배포나 APK는 포함하지 않습니다.

최종 기준은 [사용자 전달사항](docs/HANDOFF-2026-09-22.md)이며, 초기 PDF/HTML과 충돌하면 전달사항이 우선합니다. 구현 범위와 미완료 항목은 [개발 현황](docs/DEVELOPMENT.md)에 명시했습니다.

## 웹으로 실행

Node.js 24.19 이상을 사용합니다. Node 내장 SQLite를 사용하므로 오래된 Node 버전에서는 실행되지 않습니다.

```bash
cd yamone-golf
npm ci
npm run export:web
npm run server
```

브라우저에서 `http://localhost:8080`을 엽니다. SQLite DB는 `var/yamone.sqlite`에 생성되며 서버를 다시 시작해도 유지됩니다. 서버를 켜 두면 앱이 꺼져 있어도 1분 간격으로 6시간 무변경 라운드를 종료합니다. 종료 시각은 실제 마지막 변경 시각+6시간입니다.

## 모바일 개발 빌드

`.env.example`을 참고하여 `EXPO_PUBLIC_API_URL`에 휴대폰에서 접근할 API 주소를 설정합니다. 휴대폰의 `localhost`는 개발 컴퓨터가 아닙니다. 서버를 외부에서 접근하려면 적절한 `HOST`, 방화벽, HTTPS 주소도 설정해야 합니다.

```bash
npm start
npx eas-cli@latest build --platform android --profile development
```

새 native 모듈을 포함하므로 development build를 사용합니다. `eas.json`에는 테스트 APK용 `preview` 프로필도 있습니다. Expo 프로젝트 연결·빌드 자격증명은 사용자 환경에서 설정해야 합니다. 이 작업에서는 EAS 빌드·업로드·출시를 실행하지 않았습니다.

## 첫 사용

1. 닉네임 입력 → 시작. 서버가 사용자를 만들고 개인 코드·QR 및 별도 복구 키를 발급합니다.
2. 복구 키를 앱 밖에 보관합니다. 내 정보에서 복구 이메일도 인증·등록할 수 있습니다.
3. 내 골프장 등록 → 라운드 생성 → 입력 대상 선택 → 홀별 공통 저장.
4. 동반자는 홈 초대 카드 또는 라운드 참여 코드로 들어옵니다. 라운드 참여자와 실제 플레이어 자리는 별개입니다.
5. 종료 후 플레이어가 전체 라운드 기록을 받습니다. 개인 통계에는 본인 완주 18홀만 사용합니다.
6. 새 기기에서는 기존 기록 가져오기 → 이전 코드 / 등록된 복구 이메일 / 복구 키를 사용합니다.

기기 이전 코드는 내 정보에서 이메일·1/3/5일 유효기간으로 발급합니다. 발급만으로 기존 기기가 정지하지 않습니다. 새 기기에서 성공적으로 사용하면 같은 `user_id`가 이어지고 기존 인증이 폐기됩니다.

앱 삭제는 서버 기록 삭제가 아닙니다. 복구 수단이 모두 없으면 공식 복구를 제공하지 않습니다. 사용자 데이터 삭제 기능은 정책 확정 전까지 제공하지 않습니다.

## 이메일 서버

`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `MAIL_FROM`을 서버 환경 변수로 설정합니다. SMTP 설정이 없거나 발송에 실패하면 오류를 표시합니다. 실제 코드가 화면이나 서버 로그로 대신 출력되는 개발 우회 기능은 없습니다.

자동 테스트는 메모리 메일 어댑터만 사용하며 외부 이메일을 발송하지 않습니다. 실제 SMTP 수신, 스팸 필터, 발신 도메인 설정은 운영 환경에서 검증해야 합니다.

## 검증

```bash
npm run typecheck
npm run lint
npm test
npm run export:web
npx playwright install chromium
npm run test:ui
npm run export:android
```

`test:ui`는 별도의 임시 API/DB를 8099 포트로 실행해 브라우저 두 기기를 검증합니다. `BROWSER_EXECUTABLE`로 설치된 Chromium을 지정할 수 있습니다. Android export는 Hermes 번들 검사이며 APK 설치 검증과 다릅니다.

- [개발 현황과 남은 결정](docs/DEVELOPMENT.md)
- [API와 데이터 구조](docs/API.md)
- [검증 기록](docs/VALIDATION.md)

v0.1의 로컬 기록은 자동으로 서버 사용자에게 귀속시키지 않습니다. 기존 로컬 저장 데이터는 그대로 두며, 검증된 마이그레이션은 별도 작업입니다.
