import { test } from "node:test";
import assert from "node:assert/strict";
import { beforeCommand, configureAds } from "../src/data/ads";
import { Command } from "../src/domain/model";
test("only the four placements call ads; inventory failure resolves so API can still run", async () => {
  const seen: string[] = [];
  configureAds(async (placement) => {
    seen.push(placement);
    throw Error("no inventory");
  });
  const commands: Command[] = [
    { type: "create", id: "r", courseId: "c", segmentIds: ["s"], players: [] },
    { type: "join", code: "x" },
    { type: "acceptInvite", invitationId: "i" },
    { type: "end", roundId: "r" },
    { type: "receive", roundId: "r" },
    { type: "scores", roundId: "r", changes: [] },
  ];
  for (const c of commands) await beforeCommand(c);
  assert.deepEqual(seen, ["create", "join", "join", "end", "receive"]);
});
