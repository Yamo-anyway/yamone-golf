import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { readFile, mkdir } from "node:fs/promises";
import path from "node:path";
import { chromium, Page } from "playwright";
import { createApp } from "../server/http";
import { MailMessage } from "../server/identity";
async function main() {
  const root = process.cwd(),
    base = "http://127.0.0.1:8099",
    out: MailMessage[] = [],
    errors: string[] = [];
  const app = createApp({
    mailer: {
      send: async (m) => {
        out.push(m);
      },
    },
    origins: [base],
    staticRoot: path.join(root, "dist"),
    rateLimit: false,
  });
  await new Promise<void>((r) => app.server.listen(8099, "127.0.0.1", r));
  const browser = await chromium.launch({
    headless: true,
    ...(process.env.BROWSER_EXECUTABLE
      ? {
          executablePath: process.env.BROWSER_EXECUTABLE,
          args: ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"],
        }
      : {}),
  });
  const page = await browser.newPage({
    viewport: { width: 390, height: 844 },
    locale: "ko-KR",
  });
  const qa = path.join(root, "qa/v0.2.0");
  await mkdir(qa, { recursive: true });
  async function setup(p: Page) {
    p.on("pageerror", (e) => errors.push(e.message));
    if (process.env.QA_FONT_ROOT) {
      await p.route("**/qa-fonts/**", async (route) => {
        const file = new URL(route.request().url()).pathname.slice(
          "/qa-fonts/".length,
        );
        await route.fulfill({
          body: await readFile(path.join(process.env.QA_FONT_ROOT!, file)),
          contentType: file.endsWith(".css") ? "text/css" : "font/woff2",
        });
      });
    }
  }
  async function snapshot(p: Page, name: string) {
    await p.waitForTimeout(350);
    if (process.env.QA_FONT_ROOT) {
      await p.addStyleTag({ url: base + "/qa-fonts/400.css" });
      await p.addStyleTag({ url: base + "/qa-fonts/700.css" });
      await p.addStyleTag({
        content:
          '#root div:not([style*="Feather"]),#root input{font-family:"Noto Sans KR",sans-serif}',
      });
      await p.evaluate(() => document.fonts.ready);
    }
    await p.screenshot({ path: path.join(qa, name + ".png") });
  }
  async function state(p = page) {
    const response = await p.request.get(base + "/api/state");
    assert.equal(response.status(), 200);
    return (await response.json()).state;
  }
  async function waitUntil(fn: () => Promise<boolean>) {
    for (let i = 0; i < 100; i++) {
      if (await fn()) return;
      await new Promise((r) => setTimeout(r, 50));
    }
    throw Error("State did not converge");
  }
  try {
    await setup(page);
    await page.goto(base);
    await page.getByTestId("nickname").waitFor();
    await snapshot(page, "01-nickname-start");
    await page.getByTestId("nickname").fill("야모");
    await page.getByTestId("begin").click();
    await page.getByTestId("key-saved").waitFor();
    const firstKey = await page.getByText(/^YMGF-/).innerText();
    assert.match(firstKey, /YMGF-/);
    await page.getByTestId("key-saved").click();
    await page.getByTestId("new-round").waitFor();
    const original = (await state()).profile;
    assert.ok(original.personalCode);
    assert.equal(
      await page.evaluate(() => localStorage.getItem("@yamone-golf/state-v1")),
      null,
    );
    await page.getByRole("button", { name: "내 골프장", exact: true }).click();
    await page.getByTestId("add-course").click();
    await page.getByTestId("course-name").fill("야모네 컨트리클럽");
    await page.getByTestId("save-course").click();
    await page
      .getByRole("button", { name: "야모네 컨트리클럽", exact: true })
      .waitFor();
    await page.getByRole("button", { name: "뒤로", exact: true }).click();
    await page.getByTestId("new-round").click();
    await page.getByTestId("start-round").click();
    await page.getByTestId("enter-scores").waitFor();
    const round = (await state()).rounds[0],
      rid = round.id,
      pid = round.players[0].id;
    await page.getByRole("button", { name: "관리", exact: true }).click();
    const firstHandle = page.getByTestId("drag-player-" + pid),
      secondHandle = page.getByTestId("drag-player-" + round.players[1].id);
    await firstHandle.waitFor();
    const a = await firstHandle.boundingBox(),
      b = await secondHandle.boundingBox();
    assert.ok(a && b);
    await page.mouse.move(a.x + a.width / 2, a.y + a.height / 2);
    await page.mouse.down();
    await page.mouse.move(b.x + b.width / 2, b.y + b.height / 2, { steps: 12 });
    await page.mouse.up();
    await waitUntil(
      async () =>
        (await state()).rounds[0].participants.find(
          (p: any) => p.userId === original.id,
        ).targets[0] === round.players[1].id,
    );
    await page.getByRole("button", { name: "뒤로", exact: true }).click();
    await page.getByTestId("enter-scores").click();
    await page.getByTestId("save-scores").waitFor();
    assert.equal(
      await page
        .getByTestId("hole-1")
        .evaluate((el) => getComputedStyle(el).backgroundColor),
      "rgb(23, 63, 52)",
    );
    await page.getByTestId("plus-" + pid).click();
    await page.getByTestId("hole-2").click();
    await page.getByTestId("dialog-cancel").click();
    assert.equal(
      await page
        .getByTestId("hole-1")
        .evaluate((el) => getComputedStyle(el).backgroundColor),
      "rgb(23, 63, 52)",
    );
    await page.getByTestId("hole-2").click();
    await page.getByTestId("dialog-confirm").click();
    await waitUntil(
      async () => (await state()).rounds[0].players[0].scores[0].value === 5,
    );
    assert.equal(
      await page
        .getByTestId("hole-2")
        .evaluate((el) => getComputedStyle(el).backgroundColor),
      "rgb(23, 63, 52)",
    );
    await page.getByTestId("plus-" + pid).click();
    await page.getByTestId("hole-3").click();
    await page.getByTestId("dialog-discard").click();
    assert.equal((await state()).rounds[0].players[0].scores[1].value, null);
    await page.getByTestId("plus-" + pid).click();
    await snapshot(page, "02-score-draft");
    // A full reload preserves the unsaved local draft. No server value is claimed as saved.
    page.once("dialog", (d) => d.accept());
    await page.reload();
    await page.getByTestId("save-scores").waitFor();
    assert.equal(
      await page
        .getByTestId("hole-3")
        .evaluate((el) => getComputedStyle(el).backgroundColor),
      "rgb(23, 63, 52)",
    );
    await page.getByTestId("save-scores").click();
    await waitUntil(
      async () => (await state()).rounds[0].players[0].scores[2].value === 5,
    );
    for (let hole = 1; hole <= 18; hole++) {
      await page.getByTestId("hole-" + hole).click();
      await page.getByTestId("save-scores").click();
      await waitUntil(async () =>
        (await state()).rounds[0].players.every(
          (p: any) => p.scores[hole - 1].value !== null,
        ),
      );
    }

    // A different participant changes the same cell while confirmation is open.
    const otherSecret = randomBytes(32).toString("hex");
    app.identity.register("공동 기록자", otherSecret, "ko");
    const other = app.identity.authenticate(otherSecret);
    app.store.command(other, { type: "join", code: round.joinCode });
    app.store.command(other, { type: "targets", roundId: rid, targets: [pid] });
    await page.getByTestId("hole-1").click();
    await page.getByTestId("plus-" + pid).click();
    await page.getByTestId("save-scores").click();
    await page.getByTestId("dialog-confirm").waitFor();
    const before = app.store.round(rid).players[0].scores[0];
    app.store.command(other, {
      type: "scores",
      roundId: rid,
      changes: [
        { playerId: pid, hole: 0, value: 7, expectedVersion: before.version },
      ],
    });
    await page.getByTestId("dialog-confirm").click();
    await page.getByText(/7 → 6/).waitFor();
    await page.getByTestId("dialog-confirm").click();
    await waitUntil(
      async () => (await state()).rounds[0].players[0].scores[0].value === 6,
    );
    // Offline save keeps the local draft and never shows success for an uncommitted value.
    await page.getByTestId("hole-18").click();
    await page.getByTestId("plus-" + pid).click();
    await page.context().setOffline(true);
    await page.getByTestId("save-scores").click();
    await page.getByTestId("dialog-confirm").click();
    assert.equal(app.store.round(rid).players[0].scores[17].value, 4);
    await page.context().setOffline(false);
    await page.getByTestId("save-scores").click();
    await page.getByTestId("dialog-confirm").click();
    await waitUntil(
      async () => (await state()).rounds[0].players[0].scores[17].value === 5,
    );
    await page
      .getByRole("button", { name: "전체 스코어카드", exact: true })
      .click();
    await snapshot(page, "03-scorecard");
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth > innerWidth,
      ),
      false,
    );
    await page.goto(base + "/score?id=" + rid);
    await page.getByTestId("plus-" + pid).click();
    page.once("dialog", (d) => d.accept());
    await page.goto(base + "/round?id=" + rid);
    await page.getByTestId("end-round").click();
    await page.getByTestId("dialog-discard").click();
    await page.getByTestId("dialog-confirm").click();
    await page.getByTestId("receive-record").waitFor();
    await page.getByTestId("receive-record").click();
    await waitUntil(
      async () => (await state()).rounds[0].receipts.length === 1,
    );
    await page.goto(base + "/profile");
    await page
      .getByRole("button", { name: "기기 이전", exact: true })
      .waitFor();
    await snapshot(page, "04-profile-code-qr");
    await page
      .getByRole("button", { name: "복구 이메일", exact: true })
      .click();
    await page
      .getByRole("textbox", { name: "이메일", exact: true })
      .fill("golf@example.com");
    await page.getByRole("button", { name: "코드 발송", exact: true }).click();
    await page.getByRole("textbox", { name: "인증 코드", exact: true }).fill(
      await (async () => {
        await waitUntil(async () => out.length > 0);
        assert.equal(out.at(-1)!.language, "ko");
        return out.at(-1)!.code;
      })(),
    );
    await page.getByRole("button", { name: "인증", exact: true }).click();
    await waitUntil(
      async () => (await state()).profile.recoveryEmail === "golf@example.com",
    );
    await page.goto(base + "/transfer");
    await page
      .getByRole("textbox", { name: "이메일", exact: true })
      .fill("golf@example.com");
    await page.getByRole("button", { name: "5 일", exact: true }).click();
    await page.getByRole("button", { name: "코드 발송", exact: true }).click();
    await page.getByText(/이메일을 확인해주세요/).waitFor();
    const transfer = out.at(-1)!.code;
    await snapshot(page, "05-transfer");
    const second = await browser.newPage({
      viewport: { width: 390, height: 844 },
      locale: "ko-KR",
    });
    await setup(second);
    await second.goto(base);
    await second
      .getByRole("button", { name: "기존 기록 가져오기", exact: true })
      .click();
    await second.getByTestId("recovery-email").fill("golf@example.com");
    await second.getByTestId("recovery-code").fill(transfer);
    await second
      .getByRole("button", { name: "기존 기록 가져오기", exact: true })
      .last()
      .click();
    await second.getByTestId("new-round").waitFor();
    assert.equal((await state(second)).profile.id, original.id);
    assert.equal((await state(second)).rounds[0].id, rid);
    assert.equal((await state(second)).rounds[0].receipts.length, 1);
    await page.reload();
    await page
      .getByText("이 사용자는 다른 기기로 이전되었습니다.", { exact: true })
      .waitFor();
    await snapshot(page, "06-old-device-blocked");
    await second.goto(base + "/records");
    await snapshot(second, "07-recovered-records");
    const english = await browser.newPage({
      viewport: { width: 320, height: 780 },
      locale: "ja-JP",
    });
    await setup(english);
    await english.goto(base);
    await english.getByTestId("nickname").waitFor();
    assert.ok(
      await english
        .getByRole("button", { name: "Start with this name", exact: true })
        .isVisible(),
    );
    await snapshot(english, "08-english-fallback-320");
    assert.deepEqual(errors, []);
    console.log(
      "UI PASS: nickname bootstrap, one-time recovery key, course and 18-hole round, all three unsaved choices, draft after reload, receipt, verified email, five-day transfer, preserved user ID and records, revoked old device, KO/EN fallback.",
    );
  } catch (error) {
    await page.screenshot({ path: path.join(qa, "failure.png") });
    console.error("PAGE", await page.locator("body").innerText());
    console.error("ERRORS", errors);
    throw error;
  } finally {
    await browser.close();
    await new Promise<void>((r) => app.server.close(() => r()));
  }
}
main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
