import test from "node:test";
import assert from "node:assert/strict";
import {
  applyCommand,
  expireRounds,
  personalStats,
  scoreSummary,
  RuleError,
  hasReceipt,
} from "../src/domain/engine";
import {
  EMPTY_STATE,
  State,
  Command,
  DAY,
  SIX_HOURS,
  ScoreChange,
} from "../src/domain/model";
import { LocalRepository, stateSchema } from "../src/data/repository";
import { resolveLanguage } from "../src/ui/i18n";
import { messages as ko } from "../src/ui/locales/ko";
import { messages as en } from "../src/ui/locales/en";
const NOW = 1_800_000_000_000;
function run(s: State, c: Command, now = NOW) {
  return applyCommand(s, c, now);
}
function setup(holes = 18, self = true): State {
  let s = run(EMPTY_STATE, {
    type: "profile",
    profile: { id: "u1", nickname: "야모", language: "system" },
  });
  s = run(s, {
    type: "course",
    course: {
      id: "c1",
      name: "Test club",
      location: "Seoul",
      segments: [
        { id: "a", name: "OUT", pars: [4, 4, 3, 5, 4, 4, 3, 5, 4] },
        { id: "b", name: "IN", pars: [4, 4, 3, 5, 4, 4, 3, 5, 4] },
      ],
    },
  });
  return run(s, {
    type: "create",
    id: "r1",
    courseId: "c1",
    segmentIds: holes === 18 ? ["a", "b"] : ["a"],
    players: [
      { id: "p1", name: "야모", self },
      { id: "p2", name: "동반자", self: false },
    ],
  });
}
function cell(
  playerId = "p1",
  hole = 0,
  value: number | null = 4,
  expectedVersion = 0,
): ScoreChange {
  return { playerId, hole, value, expectedVersion };
}
function save(s: State, changes: ScoreChange[], at = NOW) {
  return run(s, { type: "scores", roundId: "r1", changes }, at);
}
const throws = (fn: () => unknown, code: string) =>
  assert.throws(fn, (e: unknown) => e instanceof RuleError && e.code === code);
function fill(s: State, ownOnly = false) {
  return save(
    s,
    s.rounds[0].players
      .filter((_, i) => !ownOnly || i === 0)
      .flatMap((p) =>
        s.rounds[0].holes.map((h, i) =>
          cell(p.id, i, h.par, p.scores[i].version),
        ),
      ),
  );
}

test("creation separates participant and players; one active round only", () => {
  const s = setup(18, false);
  assert.equal(s.rounds[0].participants[0].userId, "u1");
  assert.equal(s.rounds[0].players.filter((p) => p.userId).length, 0);
  throws(
    () =>
      run(s, {
        type: "create",
        id: "r2",
        courseId: "c1",
        segmentIds: ["a"],
        players: [{ id: "p3", name: "A", self: false }],
      }),
    "active",
  );
});
test("course edits never change existing round snapshots", () => {
  const s = setup();
  const before = JSON.stringify(s.rounds[0]);
  const c = s.courses[0];
  const next = run(s, {
    type: "course",
    course: {
      ...c,
      name: "Renamed",
      segments: c.segments.map((x) => ({ ...x, pars: x.pars.map(() => 5) })),
    },
  });
  assert.equal(JSON.stringify(next.rounds[0]), before);
  assert.equal(next.courses[0].name, "Renamed");
});
test("9-hole course may be selected twice to play 18", () => {
  let s = setup();
  s = run(s, { type: "end", roundId: "r1" });
  s = run(s, {
    type: "create",
    id: "r2",
    courseId: "c1",
    segmentIds: ["a", "a"],
    players: [{ id: "p3", name: "A", self: true }],
  });
  assert.equal(s.rounds[0].holes.length, 18);
  assert.equal(s.rounds[0].holes[9].number, 10);
  assert.equal(s.rounds[0].holes[9].sourceHole, 1);
});
test("adding a ninth player is rejected", () => {
  let s = setup();
  for (let i = 3; i <= 8; i++)
    s = run(s, {
      type: "addPlayer",
      roundId: "r1",
      id: `p${i}`,
      name: `P${i}`,
    });
  throws(
    () => run(s, { type: "addPlayer", roundId: "r1", id: "p9", name: "P9" }),
    "players",
  );
});
test("duplicate user slot link is rejected", () =>
  throws(
    () => run(setup(), { type: "linkSelf", roundId: "r1", playerId: "p2" }),
    "duplicate",
  ));
test("unselected players cannot be scored and target order is retained", () => {
  let s = setup();
  s = run(s, { type: "targets", roundId: "r1", targets: ["p2"] });
  throws(() => save(s, [cell()]), "permission");
  s = run(s, { type: "targets", roundId: "r1", targets: ["p2", "p1"] });
  assert.deepEqual(s.rounds[0].participants[0].targets, ["p2", "p1"]);
});
test("invalid score does not partially save a hole", () => {
  const s = setup();
  throws(() => save(s, [cell(), cell("p2", 0, 0)]), "score");
  assert.equal(s.rounds[0].players[0].scores[0].value, null);
});
test("score edit and deletion preserve versioned audit; null is not zero", () => {
  let s = save(setup(), [cell()]);
  s = save(s, [cell("p1", 0, 5, 1)]);
  s = save(s, [cell("p1", 0, null, 2)]);
  assert.equal(s.rounds[0].players[0].scores[0].value, null);
  assert.deepEqual(
    s.rounds[0].audit.map((a) => [a.before, a.after]),
    [
      [null, 4],
      [4, 5],
      [5, null],
    ],
  );
  assert.equal(s.rounds[0].players[0].scores[0].version, 3);
});
test("stale same-value writes are idempotent; stale different values conflict", () => {
  const s = save(setup(), [cell()]);
  assert.equal(save(s, [cell()]), s);
  throws(() => save(s, [cell("p1", 0, 5, 0)]), "conflict");
  assert.equal(s.rounds[0].audit.length, 1);
});
test("conflicting cells prevent the entire batch from saving", () => {
  const s = save(setup(), [cell()]);
  throws(() => save(s, [cell("p2"), cell("p1", 0, 6)]), "conflict");
  assert.equal(s.rounds[0].players[1].scores[0].value, null);
});
test("partial-round relative score includes played-hole par only", () => {
  const s = save(setup(), [cell("p1", 0, 5)]);
  assert.deepEqual(scoreSummary(s.rounds[0].players[0], s.rounds[0]), {
    strokes: 5,
    par: 4,
    played: 1,
    relative: 1,
  });
});
test("manual completion distinguishes full and incomplete rounds", () => {
  assert.equal(
    run(setup(), { type: "end", roundId: "r1" }).rounds[0].status,
    "incomplete",
  );
  assert.equal(
    run(fill(setup()), { type: "end", roundId: "r1" }).rounds[0].status,
    "complete",
  );
});
test("automatic end happens at exactly six hours and retains deadline after restart", () => {
  const s = setup();
  assert.equal(expireRounds(s, NOW + SIX_HOURS - 1), s);
  const e = expireRounds(s, NOW + SIX_HOURS + DAY);
  assert.equal(e.rounds[0].status, "incomplete");
  assert.equal(e.rounds[0].endedAt, NOW + SIX_HOURS);
  assert.equal(e.rounds[0].autoEnded, true);
});
test("real updates reset inactivity but no-op writes do not", () => {
  const s = save(setup(), [cell()], NOW + 1000);
  assert.equal(s.rounds[0].lastActivityAt, NOW + 1000);
  assert.equal(
    save(s, [cell()], NOW + 2000).rounds[0].lastActivityAt,
    NOW + 1000,
  );
});
test("after ending, own scores require receipt and other players remain locked", () => {
  let s = run(setup(), { type: "end", roundId: "r1" });
  throws(() => save(s, [cell()]), "permission");
  s = run(s, { type: "receive", roundId: "r1" });
  s = save(s, [cell()]);
  assert.equal(s.rounds[0].players[0].scores[0].value, 4);
  throws(() => save(s, [cell("p2")]), "permission");
});
test("24-hour lock boundary is exact and receiving does not reset it", () => {
  let s = run(setup(), { type: "end", roundId: "r1" });
  s = run(s, { type: "receive", roundId: "r1" }, NOW + DAY - 1);
  s = save(s, [cell()], NOW + DAY - 1);
  throws(() => save(s, [cell("p1", 0, 5, 1)], NOW + DAY), "locked");
});
test("receipt is unique and retains entire round", () => {
  let s = run(fill(setup()), { type: "end", roundId: "r1" });
  s = run(s, { type: "receive", roundId: "r1" });
  assert.equal(run(s, { type: "receive", roundId: "r1" }), s);
  assert.equal(s.rounds[0].receipts.length, 1);
  assert.equal(s.rounds[0].players.length, 2);
  assert.ok(hasReceipt(s.rounds[0], "u1"));
});
test("recorders cannot receive personal records", () => {
  const s = run(setup(18, false), { type: "end", roundId: "r1" });
  throws(() => run(s, { type: "receive", roundId: "r1" }), "notPlayer");
});
test("stats exclude 9 holes and unfinished own scores, and require receipt", () => {
  for (const holes of [9, 18]) {
    let s = run(holes === 9 ? fill(setup(9)) : setup(), {
      type: "end",
      roundId: "r1",
    });
    s = run(s, { type: "receive", roundId: "r1" });
    assert.equal(personalStats(s).count, 0);
  }
  const s = run(fill(setup()), { type: "end", roundId: "r1" });
  assert.equal(personalStats(s).count, 0);
});
test("complete own 18 holes count even when a companion has missing scores", () => {
  let s = run(fill(setup(), true), { type: "end", roundId: "r1" });
  s = run(s, { type: "receive", roundId: "r1" });
  assert.equal(personalStats(s).count, 1);
  assert.equal(personalStats(s).best, 72);
});
test("stored schema rejects truncated arrays and invalid data", () => {
  assert.equal(stateSchema.safeParse(setup()).success, true);
  const s = setup();
  s.rounds[0].players[0].scores.pop();
  assert.equal(stateSchema.safeParse(s).success, false);
});
test("language is Korean only for ko locales; explicit overrides work", () => {
  assert.equal(resolveLanguage("system", "ko-KR"), "ko");
  for (const locale of ["en-US", "ja-JP", "fr-CA", "zh-TW"])
    assert.equal(resolveLanguage("system", locale), "en");
  assert.equal(resolveLanguage("en", "ko-KR"), "en");
  assert.equal(resolveLanguage("ko", "en-US"), "ko");
  assert.deepEqual(Object.keys(ko).sort(), Object.keys(en).sort());
  for (const key of Object.keys(ko) as (keyof typeof ko)[])
    assert.ok(ko[key] && en[key]);
});
test("repository survives restart, serializes writes, and preserves session", async () => {
  let data: string | null = JSON.stringify(setup());
  const store = {
    getItem: async () => data,
    setItem: async (_k: string, v: string) => {
      data = v;
    },
  };
  const repo = new LocalRepository(store, () => NOW);
  await repo.load();
  await Promise.all([
    repo.dispatch({ type: "scores", roundId: "r1", changes: [cell()] }),
    repo.dispatch({ type: "scores", roundId: "r1", changes: [cell("p2")] }),
  ]);
  const loaded = await new LocalRepository(store, () => NOW).load();
  assert.equal(loaded.rounds[0].audit.length, 2);
  assert.equal(loaded.session, true);
});
test("failed persistence never reports a committed score and retry succeeds", async () => {
  let data = JSON.stringify(setup()),
    fail = true;
  const repo = new LocalRepository(
    {
      getItem: async () => data,
      setItem: async (_k, v) => {
        if (fail) throw new Error("disk full");
        data = v;
      },
    },
    () => NOW,
  );
  await repo.load();
  await assert.rejects(
    repo.dispatch({ type: "scores", roundId: "r1", changes: [cell()] }),
  );
  assert.equal(JSON.parse(data).rounds[0].players[0].scores[0].value, null);
  fail = false;
  const s = await repo.dispatch({
    type: "scores",
    roundId: "r1",
    changes: [cell()],
  });
  assert.equal(s.rounds[0].players[0].scores[0].version, 1);
});
test("corrupt saved records are preserved, never silently reset", async () => {
  let writes = 0;
  const repo = new LocalRepository({
    getItem: async () => "{bad",
    setItem: async () => {
      writes++;
    },
  });
  await assert.rejects(repo.load(), /storageCorrupt/);
  assert.equal(writes, 0);
});
