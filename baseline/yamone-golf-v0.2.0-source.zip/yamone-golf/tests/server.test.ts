import { test } from "node:test";
import assert from "node:assert/strict";
import { randomBytes, randomUUID } from "node:crypto";
import { createApp } from "../server/http";
import { DAY, SIX_HOURS } from "../src/domain/model";
import { personalStats } from "../src/domain/engine";
const secret = () => randomBytes(32).toString("hex");
function fixture() {
  let now = 1800000000000;
  const app = createApp({
    mailer: { send: async () => {} },
    clock: () => now,
    rateLimit: false,
  });
  const a = secret(),
    b = secret();
  app.identity.register("A", a, "ko");
  app.identity.register("B", b, "en");
  const A = app.identity.authenticate(a),
    B = app.identity.authenticate(b);
  const cmd = (auth: typeof A, c: any) => app.store.command(auth, c);
  const courseId = randomUUID(),
    seg = randomUUID();
  cmd(A, {
    type: "course",
    course: {
      id: courseId,
      name: "Test Golf",
      location: "",
      segments: [{ id: seg, name: "OUT", pars: Array(9).fill(4) }],
    },
  });
  const roundId = randomUUID(),
    p1 = randomUUID(),
    p2 = randomUUID();
  cmd(A, {
    type: "create",
    id: roundId,
    courseId,
    segmentIds: [seg, seg],
    players: [
      { id: p1, name: "A", self: true },
      { id: p2, name: "Guest", self: false },
    ],
  });
  return {
    ...app,
    a,
    b,
    A,
    B,
    cmd,
    courseId,
    seg,
    roundId,
    p1,
    p2,
    advance: (ms: number) => (now += ms),
    close: () => app.server.emit("close"),
  };
}
test("shared round has one source, personal targets and one ongoing round per user", () => {
  const f = fixture();
  try {
    const original = f.store.round(f.roundId);
    f.cmd(f.B, { type: "join", code: original.joinCode });
    f.cmd(f.B, { type: "targets", roundId: f.roundId, targets: [f.p2, f.p1] });
    assert.deepEqual(
      f.store
        .state(f.A)
        .rounds[0].participants.find((p) => p.userId === f.A.user.id)!.targets,
      [f.p1, f.p2],
    );
    assert.throws(
      () =>
        f.cmd(f.B, {
          type: "create",
          id: randomUUID(),
          courseId: f.courseId,
          segmentIds: [f.seg],
          players: [{ id: randomUUID(), name: "B", self: true }],
        }),
      /active/,
    );
    const changes = [{ playerId: f.p1, hole: 0, value: 4, expectedVersion: 0 }];
    f.cmd(f.A, { type: "scores", roundId: f.roundId, changes });
    f.cmd(f.B, { type: "scores", roundId: f.roundId, changes });
    assert.throws(
      () =>
        f.cmd(f.B, {
          type: "scores",
          roundId: f.roundId,
          changes: [{ ...changes[0], value: 5 }],
        }),
      /conflict/,
    );
    f.cmd(f.B, {
      type: "scores",
      roundId: f.roundId,
      changes: [{ ...changes[0], value: 5, expectedVersion: 1 }],
    });
    assert.equal(f.store.state(f.A).rounds[0].players[0].scores[0].value, 5);
    assert.throws(
      () =>
        f.cmd(f.A, {
          type: "scores",
          roundId: f.roundId,
          changes: [{ ...changes[0], value: 6, expectedVersion: 1 }],
        }),
      /conflict/,
    );
  } finally {
    f.close();
  }
});
test("uninvited users cannot read or mutate rounds; invite cancel is independent of participation", () => {
  const f = fixture();
  try {
    assert.equal(f.store.state(f.B).rounds.length, 0);
    assert.throws(
      () =>
        f.cmd(f.B, {
          type: "scores",
          roundId: f.roundId,
          changes: [{ playerId: f.p1, hole: 0, value: 1, expectedVersion: 0 }],
        }),
      /round/,
    );
    f.cmd(f.A, {
      type: "invite",
      roundId: f.roundId,
      personalCode: f.B.user.personal_code,
    });
    const inv = f.store.state(f.B).invitations![0];
    f.cmd(f.B, { type: "cancelInvite", invitationId: inv.id });
    assert.equal(f.store.state(f.B).invitations!.length, 0);
    assert.equal(f.store.state(f.B).rounds.length, 0);
    f.cmd(f.A, {
      type: "invite",
      roundId: f.roundId,
      personalCode: f.B.user.personal_code,
    });
    f.cmd(f.B, {
      type: "acceptInvite",
      invitationId: f.store.state(f.B).invitations![0].id,
    });
    assert.equal(f.store.state(f.B).rounds.length, 1);
  } finally {
    f.close();
  }
});
test("server ends fully scored round after six hours, preserving completed player state", () => {
  const f = fixture();
  try {
    f.cmd(f.A, {
      type: "scores",
      roundId: f.roundId,
      changes: [f.p1, f.p2].flatMap((playerId) =>
        Array.from({ length: 18 }, (_, hole) => ({
          playerId,
          hole,
          value: 4,
          expectedVersion: 0,
        })),
      ),
    });
    f.advance(SIX_HOURS);
    f.store.sweep();
    const r = f.store.round(f.roundId);
    assert.equal(r.status, "complete");
    assert.equal(r.autoEnded, true);
    assert.equal(
      r.players[0].scores.filter((s) => s.value !== null).length,
      18,
    );
  } finally {
    f.close();
  }
});
test("end permissions, own receipt and 24h deadline are checked on server", () => {
  const f = fixture();
  try {
    f.cmd(f.B, { type: "join", code: f.store.round(f.roundId).joinCode });
    f.cmd(f.B, { type: "linkSelf", roundId: f.roundId, playerId: f.p2 });
    assert.throws(
      () => f.cmd(f.B, { type: "end", roundId: f.roundId }),
      /permission/,
    );
    f.cmd(f.A, {
      type: "delegateEnd",
      roundId: f.roundId,
      userId: f.B.user.id,
      enabled: true,
    });
    f.cmd(f.B, { type: "end", roundId: f.roundId });
    const c = {
      type: "scores",
      roundId: f.roundId,
      changes: [{ playerId: f.p1, hole: 0, value: 4, expectedVersion: 0 }],
    };
    assert.throws(() => f.cmd(f.A, c), /permission/);
    f.cmd(f.A, { type: "receive", roundId: f.roundId });
    f.cmd(f.A, c);
    f.cmd(f.B, { type: "receive", roundId: f.roundId });
    assert.throws(
      () =>
        f.cmd(f.B, {
          ...c,
          changes: [{ ...c.changes[0], value: 5, expectedVersion: 1 }],
        }),
      /permission/,
    );
    f.advance(DAY);
    assert.throws(
      () =>
        f.cmd(f.A, {
          ...c,
          changes: [{ ...c.changes[0], value: 5, expectedVersion: 1 }],
        }),
      /locked/,
    );
  } finally {
    f.close();
  }
});
test("deleted personal receipt never resurrects old delivery; new send allows fresh receipt", () => {
  const f = fixture();
  try {
    f.cmd(f.A, {
      type: "scores",
      roundId: f.roundId,
      changes: Array.from({ length: 18 }, (_, hole) => ({
        playerId: f.p1,
        hole,
        value: 4,
        expectedVersion: 0,
      })),
    });
    f.cmd(f.A, { type: "end", roundId: f.roundId });
    f.cmd(f.A, { type: "sendRecord", roundId: f.roundId, playerId: f.p1 });
    f.cmd(f.A, { type: "receive", roundId: f.roundId });
    assert.equal(personalStats(f.store.state(f.A)).count, 1);
    const old = f.store.round(f.roundId).deliveries![0].id;
    f.cmd(f.A, { type: "deleteReceipt", roundId: f.roundId });
    assert.equal(personalStats(f.store.state(f.A)).count, 0);
    assert.equal(f.store.round(f.roundId).deliveries![0].status, "received");
    assert.throws(
      () => f.cmd(f.A, { type: "receive", roundId: f.roundId }),
      /noDelivery/,
    );
    f.cmd(f.A, { type: "sendRecord", roundId: f.roundId, playerId: f.p1 });
    assert.notEqual(f.store.round(f.roundId).deliveries![1].id, old);
    f.cmd(f.A, { type: "receive", roundId: f.roundId });
    assert.equal(personalStats(f.store.state(f.A)).count, 1);
    assert.equal(f.store.state(f.A).rounds[0].players.length, 2);
  } finally {
    f.close();
  }
});
test("unlink keeps slot and scores; deletion with effects is blocked; courses remain after removal", () => {
  const f = fixture();
  try {
    f.cmd(f.A, {
      type: "scores",
      roundId: f.roundId,
      changes: [{ playerId: f.p1, hole: 0, value: 4, expectedVersion: 0 }],
    });
    f.cmd(f.A, {
      type: "unlinkPlayer",
      roundId: f.roundId,
      playerId: f.p1,
      name: "Temp",
    });
    const p = f.store.round(f.roundId).players[0];
    assert.equal(p.userId, null);
    assert.equal(p.scores[0].value, 4);
    f.cmd(f.A, {
      type: "renamePlayer",
      roundId: f.roundId,
      playerId: f.p1,
      name: "Rename",
    });
    assert.throws(
      () =>
        f.cmd(f.A, {
          type: "deletePlayer",
          roundId: f.roundId,
          playerId: f.p1,
        }),
      /impact/,
    );
    f.cmd(f.A, { type: "deletePlayer", roundId: f.roundId, playerId: f.p2 });
    assert.equal(f.store.round(f.roundId).players.length, 1);
    f.cmd(f.A, { type: "removeCourse", courseId: f.courseId });
    assert.equal(f.store.state(f.A).courses.length, 0);
    assert.ok(
      f.db.prepare("SELECT id FROM courses WHERE id=?").get(f.courseId),
    );
    assert.equal(f.store.round(f.roundId).courseName, "Test Golf");
  } finally {
    f.close();
  }
});
test("device recovery retains courses, rounds and target order; old device fails every command", () => {
  const f = fixture();
  try {
    const key = f.identity.rotateRecoveryKey(f.A).recoveryKey;
    const newSecret = secret();
    f.identity.recoverKey(key, newSecret);
    const next = f.identity.authenticate(newSecret);
    assert.equal(f.store.state(next).rounds[0].id, f.roundId);
    assert.equal(f.store.state(next).courses[0].id, f.courseId);
    assert.throws(
      () => f.cmd(f.A, { type: "end", roundId: f.roundId }),
      /deviceMoved/,
    );
  } finally {
    f.close();
  }
});
test("HTTP API rejects forged IDs, untrusted cookie mutations and malformed values", async () => {
  const app = createApp({
    mailer: { send: async () => {} },
    origins: ["http://test.local"],
    rateLimit: false,
  });
  await new Promise<void>((r) => app.server.listen(0, "127.0.0.1", r));
  try {
    const address = app.server.address() as { port: number },
      base = `http://127.0.0.1:${address.port}/api/`;
    const s = secret();
    const response = await fetch(base + "users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nickname: "Golf", secret: s, language: "ko" }),
    });
    assert.equal(response.status, 200);
    const cookie = response.headers.get("set-cookie")!.split(";")[0];
    assert.match(response.headers.get("set-cookie")!, /HttpOnly/);
    const result = (await response.json()) as any;
    const post = async (c: any, headers: Record<string, string>) =>
      fetch(base + "command", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...headers },
        body: JSON.stringify(c),
      });
    const profile = {
      type: "profile",
      profile: { ...result.profile, id: randomUUID(), nickname: "Changed" },
    };
    const forbidden = await post(profile, { Cookie: cookie });
    assert.equal(forbidden.status, 403);
    const ok = await post(profile, {
      Cookie: cookie,
      Origin: "http://test.local",
    });
    assert.equal(ok.status, 200);
    const changed = (await ok.json()) as any;
    assert.equal(changed.state.profile.id, result.profile.id);
    const hostile = await post(profile, {
      Cookie: cookie,
      Origin: "http://evil.local",
    });
    assert.equal(hostile.status, 403);
    const malformed = await post(
      {
        type: "scores",
        roundId: "x",
        changes: [{ playerId: "p", hole: 0, value: 0, expectedVersion: 0 }],
      },
      { Authorization: `Bearer ${s}` },
    );
    assert.equal(malformed.status, 400);
  } finally {
    await new Promise<void>((r) => app.server.close(() => r()));
  }
});

test("background timer closes round while no app makes a request", async () => {
  let now = 1800000000000;
  const app = createApp({
    mailer: { send: async () => {} },
    clock: () => now,
    sweepMs: 10,
  });
  await new Promise<void>((r) => app.server.listen(0, "127.0.0.1", r));
  try {
    const token = secret();
    app.identity.register("Timer", token, "ko");
    const auth = app.identity.authenticate(token);
    const c = {
      id: randomUUID(),
      name: "C",
      location: "",
      segments: [{ id: randomUUID(), name: "OUT", pars: Array(9).fill(4) }],
    };
    app.store.command(auth, { type: "course", course: c });
    const rid = randomUUID();
    app.store.command(auth, {
      type: "create",
      id: rid,
      courseId: c.id,
      segmentIds: [c.segments[0].id],
      players: [{ id: randomUUID(), name: "Timer", self: true }],
    });
    now += SIX_HOURS;
    await new Promise((r) => setTimeout(r, 30));
    assert.equal(app.store.round(rid).autoEnded, true);
  } finally {
    await new Promise<void>((r) => app.server.close(() => r()));
  }
});

test("fresh delivery to an existing receipt is consumed without duplicating the receipt", () => {
  const f = fixture();
  try {
    f.cmd(f.A, { type: "end", roundId: f.roundId });
    f.cmd(f.A, { type: "receive", roundId: f.roundId });
    f.cmd(f.A, { type: "sendRecord", roundId: f.roundId, playerId: f.p1 });
    f.cmd(f.A, { type: "receive", roundId: f.roundId });
    const r = f.store.round(f.roundId);
    assert.equal(r.receipts.length, 1);
    assert.equal(r.deliveries![0].status, "received");
  } finally {
    f.close();
  }
});
