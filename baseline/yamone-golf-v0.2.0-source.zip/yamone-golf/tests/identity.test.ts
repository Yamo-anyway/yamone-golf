import { test } from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { openDatabase } from "../server/db";
import { Identity, MailMessage, hash, cleanCode } from "../server/identity";
import { DAY } from "../src/domain/model";
const secret = () => randomBytes(32).toString("hex");
function fixture() {
  let now = 100000;
  const out: MailMessage[] = [],
    db = openDatabase(":memory:");
  const identity = new Identity(
    db,
    {
      send: async (m) => {
        out.push(m);
      },
    },
    () => now,
  );
  const a = secret(),
    user = identity.register("골퍼", a, "ko");
  return { identity, db, out, a, user, advance: (ms: number) => (now += ms) };
}
test("duplicate nicknames receive distinct server UUIDs; only secret authenticates", () => {
  const f = fixture();
  try {
    const other = f.identity.register("골퍼", secret(), "ko");
    assert.notEqual(other.profile.id, f.user.profile.id);
    assert.match(f.user.profile.id, /^[a-f0-9-]{36}$/);
    assert.throws(() => f.identity.authenticate(f.user.profile.id));
    assert.throws(() => f.identity.authenticate(f.user.profile.personalCode!));
    assert.equal(
      f.identity.register("changed", f.a, "en").profile.id,
      f.user.profile.id,
    );
  } finally {
    f.db.close();
  }
});
test("transfer issue keeps old device active; successful claim atomically preserves user ID and revokes old", async () => {
  const f = fixture();
  try {
    const old = f.identity.authenticate(f.a);
    await f.identity.sendTransfer(old, "x@example.com", 3);
    assert.equal(f.identity.authenticate(f.a).user.id, f.user.profile.id);
    const b = secret(),
      result = f.identity.claimTransfer("x@example.com", f.out[0].code, b);
    assert.equal(result.profile.id, f.user.profile.id);
    assert.equal(result.profile.personalCode, f.user.profile.personalCode);
    assert.throws(() => f.identity.authenticate(f.a), /deviceMoved/);
    assert.equal(f.identity.authenticate(b).user.id, f.user.profile.id);
    assert.throws(
      () => f.identity.claimTransfer("x@example.com", f.out[0].code, secret()),
      /invalidCode/,
    );
  } finally {
    f.db.close();
  }
});
for (const days of [1, 3, 5] as const)
  test(`transfer expiry ${days} days uses server clock`, async () => {
    const f = fixture();
    try {
      await f.identity.sendTransfer(
        f.identity.authenticate(f.a),
        "x@example.com",
        days,
      );
      f.advance(days * DAY);
      assert.throws(
        () =>
          f.identity.claimTransfer("x@example.com", f.out[0].code, secret()),
        /invalidCode/,
      );
      assert.doesNotThrow(() => f.identity.authenticate(f.a));
    } finally {
      f.db.close();
    }
  });
test("replacement transfer invalidates old; five failed attempts block code", async () => {
  const f = fixture();
  try {
    const auth = f.identity.authenticate(f.a);
    await f.identity.sendTransfer(auth, "x@example.com", 1);
    await f.identity.sendTransfer(auth, "x@example.com", 5);
    assert.throws(
      () => f.identity.claimTransfer("x@example.com", f.out[0].code, secret()),
      /invalidCode/,
    );
    for (let i = 0; i < 4; i++)
      assert.throws(
        () => f.identity.claimTransfer("x@example.com", "wrong", secret()),
        /invalidCode/,
      );
    assert.throws(
      () => f.identity.claimTransfer("x@example.com", f.out[1].code, secret()),
      /invalidCode/,
    );
  } finally {
    f.db.close();
  }
});
test("mail failure cannot produce valid claim or deactivate old device", async () => {
  const f = fixture();
  try {
    let captured = "";
    f.identity.mailer = {
      send: async (m) => {
        captured = m.code;
        throw Error("smtp");
      },
    };
    await assert.rejects(
      f.identity.sendTransfer(f.identity.authenticate(f.a), "x@example.com", 1),
      /mailUnavailable/,
    );
    assert.throws(
      () => f.identity.claimTransfer("x@example.com", captured, secret()),
      /invalidCode/,
    );
    assert.doesNotThrow(() => f.identity.authenticate(f.a));
  } finally {
    f.db.close();
  }
});
test("unverified email cannot recover; possession proof precedes account list; same email supports duplicate nicknames", async () => {
  const f = fixture();
  try {
    await f.identity.requestEmailRecovery("none@example.com", "ko");
    assert.equal(f.out.length, 0);
    const a = f.identity.authenticate(f.a);
    await f.identity.requestEmailVerification(a, "x@example.com");
    await f.identity.requestEmailRecovery("x@example.com", "ko");
    assert.equal(f.out.length, 1);
    f.identity.verifyEmail(a, "x@example.com", f.out[0].code);
    const b = secret();
    f.identity.register("골퍼", b, "en");
    const second = f.identity.authenticate(b);
    await f.identity.requestEmailVerification(second, "x@example.com");
    f.identity.verifyEmail(second, "x@example.com", f.out.at(-1)!.code);
    await f.identity.requestEmailRecovery("x@example.com", "ko");
    const proof = f.identity.verifyEmailRecovery(
      "x@example.com",
      f.out.at(-1)!.code,
    );
    assert.equal(proof.accounts.length, 2);
    const newDevice = secret();
    const result = f.identity.claimEmail(
      "x@example.com",
      proof.grant,
      f.user.profile.id,
      newDevice,
    );
    assert.equal(result.profile.id, f.user.profile.id);
    assert.throws(() => f.identity.authenticate(f.a), /deviceMoved/);
    assert.doesNotThrow(() => f.identity.authenticate(b));
    assert.throws(
      () =>
        f.identity.claimEmail(
          "x@example.com",
          proof.grant,
          f.user.profile.id,
          secret(),
        ),
      /invalidCode/,
    );
  } finally {
    f.db.close();
  }
});
test("recovery key is hashed, rotates on use, revokes old device and pending transfers", async () => {
  const f = fixture();
  try {
    assert.equal(
      f.db.prepare("SELECT token_hash FROM recovery_keys").get()!.token_hash,
      hash(cleanCode(f.user.recoveryKey!)),
    );
    await f.identity.sendTransfer(
      f.identity.authenticate(f.a),
      "x@example.com",
      5,
    );
    const b = secret(),
      recovered = f.identity.recoverKey(f.user.recoveryKey!, b);
    assert.equal(recovered.profile.id, f.user.profile.id);
    assert.notEqual(recovered.recoveryKey, f.user.recoveryKey);
    assert.throws(
      () => f.identity.recoverKey(f.user.recoveryKey!, secret()),
      /invalidCode/,
    );
    assert.throws(() => f.identity.authenticate(f.a), /deviceMoved/);
    assert.throws(
      () => f.identity.claimTransfer("x@example.com", f.out[0].code, secret()),
      /invalidCode/,
    );
  } finally {
    f.db.close();
  }
});
test("revoked device cannot re-register or issue transfer/key; key rotation invalidates prior key", () => {
  const f = fixture();
  try {
    const auth = f.identity.authenticate(f.a),
      newKey = f.identity.rotateRecoveryKey(auth).recoveryKey;
    assert.throws(
      () => f.identity.recoverKey(f.user.recoveryKey!, secret()),
      /invalidCode/,
    );
    f.identity.recoverKey(newKey, secret());
    assert.throws(() => f.identity.register("same", f.a, "en"), /deviceMoved/);
    assert.throws(() => f.identity.rotateRecoveryKey(auth), /deviceMoved/);
  } finally {
    f.db.close();
  }
});
