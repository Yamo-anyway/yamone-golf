// Long-lived web credentials are HttpOnly cookies. A pending secret is retained only until bootstrap is acknowledged.
const key = "yamone.pending.device";
export async function getSecret() {
  return sessionStorage.getItem(key);
}
export async function prepareSecret() {
  const old = await getSecret();
  if (old) return old;
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  const value = Array.from(bytes, (x) => x.toString(16).padStart(2, "0")).join(
    "",
  );
  sessionStorage.setItem(key, value);
  return value;
}
export async function resetSecret() {
  sessionStorage.removeItem(key);
}
export async function credentialAccepted() {
  sessionStorage.removeItem(key);
}
