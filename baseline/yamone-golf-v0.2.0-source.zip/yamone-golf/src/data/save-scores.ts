import { api } from "./api";
import { Draft } from "./drafts";
import { Command, State, ScoreChange } from "../domain/model";
import { RuleError } from "../domain/engine";
export type ScoreDifference = {
  name: string;
  before: number | null;
  after: number | null;
};
// Reused by the score editor and the final round-ending draft check.
export async function saveScoreDraft(
  roundId: string,
  hole: number,
  draft: Draft,
  options: {
    deleting?: boolean;
    confirm: (changes: ScoreDifference[]) => Promise<boolean>;
    commit: (command: Command) => Promise<State | undefined>;
  },
) {
  while (true) {
    const fresh = (await api.state()).state.rounds.find(
      (r) => r.id === roundId,
    );
    if (!fresh) throw new RuleError("round");
    const changes: ScoreChange[] = Object.entries(draft).map(([id, cell]) => {
      const player = fresh.players.find((p) => p.id === id);
      if (!player || !player.scores[hole]) throw new RuleError("player");
      return {
        playerId: id,
        hole,
        value: options.deleting ? null : cell.value,
        expectedVersion: player.scores[hole].version,
      };
    });
    const differences = changes.flatMap((c) => {
      const p = fresh.players.find((p) => p.id === c.playerId)!,
        before = p.scores[hole].value;
      return before !== null && before !== c.value
        ? [{ name: p.name, before, after: c.value }]
        : [];
    });
    if (differences.length && !(await options.confirm(differences)))
      return undefined;
    try {
      return await options.commit({ type: "scores", roundId, changes });
    } catch (e) {
      if (e instanceof RuleError && e.code === "conflict") continue;
      throw e;
    }
  }
}
