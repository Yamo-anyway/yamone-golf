import AsyncStorage from "@react-native-async-storage/async-storage";
export type Draft = Record<
  string,
  { value: number; original: number | null; version: number }
>;
export type ScoreDraft = { hole: number; draft: Draft; dirty: boolean };
let writes = Promise.resolve();
const key = (user: string, round: string) => `yamone.draft.v2:${user}:${round}`;
export const drafts = {
  load: async (user: string, round: string): Promise<ScoreDraft | null> => {
    await writes;
    const raw = await AsyncStorage.getItem(key(user, round));
    if (!raw) return null;
    try {
      const value = JSON.parse(raw);
      if (
        !Number.isInteger(value.hole) ||
        value.hole < 0 ||
        value.hole > 17 ||
        typeof value.dirty !== "boolean" ||
        !value.draft
      )
        return null;
      for (const cell of Object.values(value.draft) as any[])
        if (
          !Number.isInteger(cell.value) ||
          cell.value < 1 ||
          cell.value > 99 ||
          !Number.isInteger(cell.version)
        )
          return null;
      return value;
    } catch {
      return null;
    }
  },
  save: (user: string, round: string, value: ScoreDraft) => {
    const task = writes.then(() =>
      AsyncStorage.setItem(key(user, round), JSON.stringify(value)),
    );
    writes = task.catch(() => {});
    return task;
  },
};
