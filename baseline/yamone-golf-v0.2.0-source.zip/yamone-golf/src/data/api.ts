import { Platform } from "react-native";
import {
  getSecret,
  prepareSecret,
  resetSecret,
  credentialAccepted,
} from "./credentials";
import { RuleError } from "../domain/engine";
import { Command, State, Profile, Language } from "../domain/model";
const base =
  process.env.EXPO_PUBLIC_API_URL ??
  (Platform.OS === "web" ? "" : "http://localhost:8080");
export type IdentityResult = { profile: Profile; recoveryKey?: string | null };
export async function request<T>(path: string, input?: unknown): Promise<T> {
  const device = await getSecret();
  let response: Response;
  try {
    response = await fetch(base + "/api/" + path, {
      method: input === undefined ? "GET" : "POST",
      credentials: "include",
      headers: {
        ...(input !== undefined ? { "Content-Type": "application/json" } : {}),
        ...(device ? { Authorization: `Bearer ${device}` } : {}),
      },
      body: input === undefined ? undefined : JSON.stringify(input),
      signal: AbortSignal.timeout(15000),
    });
  } catch {
    throw new RuleError("network");
  }
  let data;
  try {
    data = await response.json();
  } catch {
    throw new RuleError("network");
  }
  if (!response.ok) throw new RuleError(data.error ?? "server", data.details);
  return data as T;
}
export const api = {
  state: async () => {
    const result = await request<{ state: State; serverTime: number }>("state");
    await credentialAccepted();
    return result;
  },
  command: (c: Command) =>
    request<{ state: State; serverTime: number }>("command", c),
  register: async (nickname: string, language: Language) => {
    const result = await request<IdentityResult>("users", {
      nickname,
      language,
      secret: await prepareSecret(),
    });
    await credentialAccepted();
    return result;
  },
  claim: async (path: string, input: Record<string, unknown>) => {
    const result = await request<IdentityResult>(path, {
      ...input,
      secret: await prepareSecret(),
    });
    await credentialAccepted();
    return result;
  },
  reset: async () => {
    await request("device/reset", {});
    await resetSecret();
  },
  request,
};
