import * as SecureStore from "expo-secure-store";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Crypto from "expo-crypto";
const key = "yamone.device.secret",
  marker = "yamone.installation.v2";
async function initialize() {
  if (!(await AsyncStorage.getItem(marker))) {
    await SecureStore.deleteItemAsync(key);
    await AsyncStorage.setItem(marker, "1");
  }
}
export async function getSecret() {
  await initialize();
  return await SecureStore.getItemAsync(key);
}
export async function prepareSecret() {
  const existing = await getSecret();
  if (existing) return existing;
  const bytes = await Crypto.getRandomBytesAsync(32);
  const value = Array.from(bytes, (x) => x.toString(16).padStart(2, "0")).join(
    "",
  );
  await SecureStore.setItemAsync(key, value, {
    keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK_THIS_DEVICE_ONLY,
  });
  return value;
}
export async function resetSecret() {
  await SecureStore.deleteItemAsync(key);
}
export async function credentialAccepted() {
  /* Native secret was durably written before the request. */
}
