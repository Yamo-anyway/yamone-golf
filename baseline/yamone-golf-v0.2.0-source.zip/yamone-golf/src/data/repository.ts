import { z } from "zod";
import { State, EMPTY_STATE, Command } from "../domain/model";
import { applyCommand, expireRounds } from "../domain/engine";

const id = z.string().min(1);
const timestamp = z.number().finite().nonnegative();
const score = z.object({
  value: z.number().int().min(1).max(99).nullable(),
  version: z.number().int().nonnegative(),
});
const par = z.union([
  z.literal(3),
  z.literal(4),
  z.literal(5),
  z.literal(6),
  z.literal(7),
]);
const roundSchema = z
  .object({
    id,
    courseId: id,
    courseName: z.string(),
    location: z.string(),
    creatorId: id,
    holes: z
      .array(
        z.object({
          number: z.number().int(),
          sourceSegmentId: id,
          sourceHole: z.number().int(),
          segmentName: z.string(),
          par,
        }),
      )
      .refine((h) => h.length === 9 || h.length === 18),
    players: z
      .array(
        z.object({
          id,
          name: z.string(),
          userId: id.nullable(),
          scores: z.array(score),
        }),
      )
      .min(1)
      .max(8),
    participants: z.array(
      z.object({ userId: id, canEnd: z.boolean(), targets: z.array(id) }),
    ),
    status: z.enum(["active", "complete", "incomplete"]),
    createdAt: timestamp,
    lastActivityAt: timestamp,
    endedAt: timestamp.nullable(),
    autoEnded: z.boolean(),
    receipts: z.array(z.object({ userId: id, receivedAt: timestamp })),
    audit: z.array(
      z.object({
        playerId: id,
        hole: z.number().int(),
        before: score.shape.value,
        after: score.shape.value,
        actorId: id,
        at: timestamp,
        version: z.number().int(),
      }),
    ),
  })
  .refine(
    (r) =>
      r.players.every((p) => p.scores.length === r.holes.length) &&
      (r.status === "active" ? r.endedAt === null : r.endedAt !== null),
  );
export const stateSchema = z
  .object({
    schemaVersion: z.literal(1),
    profile: z
      .object({
        id,
        nickname: z.string().min(1).max(32),
        language: z.enum(["system", "ko", "en"]),
      })
      .nullable(),
    session: z.boolean(),
    courses: z.array(
      z.object({
        id,
        name: z.string(),
        location: z.string(),
        updatedAt: timestamp,
        segments: z
          .array(
            z.object({ id, name: z.string(), pars: z.array(par).length(9) }),
          )
          .min(1)
          .max(9),
      }),
    ),
    rounds: z.array(roundSchema),
  })
  .refine((s) => !s.session || s.profile !== null);
export const STORAGE_KEY = "@yamone-golf/state-v1";
export interface KeyValueStore {
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
}
/** Commands are serialized and UI state is published only after durable storage succeeds. */
export class LocalRepository {
  private state: State = EMPTY_STATE;
  private queue: Promise<unknown> = Promise.resolve();
  constructor(
    private storage: KeyValueStore,
    private now: () => number = Date.now,
  ) {}
  async load(): Promise<State> {
    const raw = await this.storage.getItem(STORAGE_KEY);
    let state: State = EMPTY_STATE;
    if (raw !== null) {
      try {
        state = stateSchema.parse(JSON.parse(raw)) as State;
      } catch {
        throw new Error("storageCorrupt");
      }
    }
    const updated = expireRounds(state, this.now());
    if (updated !== state)
      await this.storage.setItem(STORAGE_KEY, JSON.stringify(updated));
    this.state = updated;
    return updated;
  }
  dispatch(command: Command): Promise<State> {
    const operation = this.queue.then(async () => {
      const next = applyCommand(this.state, command, this.now());
      if (next !== this.state) {
        await this.storage.setItem(STORAGE_KEY, JSON.stringify(next));
        this.state = next;
      }
      return this.state;
    });
    this.queue = operation.catch(() => {});
    return operation;
  }
}
