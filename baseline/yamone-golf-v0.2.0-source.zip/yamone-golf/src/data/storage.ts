import AsyncStorage from "@react-native-async-storage/async-storage";
import { LocalRepository } from "./repository";
export const repository = new LocalRepository(AsyncStorage);
