import { Command } from "../domain/model";
export type AdPlacement = "create" | "join" | "end" | "receive";
let provider: ((placement: AdPlacement) => Promise<void>) | undefined;
export function configureAds(show: (placement: AdPlacement) => Promise<void>) {
  provider = show;
}
export async function beforeCommand(c: Command) {
  const placement = c.type === "acceptInvite" ? "join" : c.type;
  if (!["create", "join", "end", "receive"].includes(placement) || !provider)
    return;
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    await Promise.race([
      provider(placement as AdPlacement),
      new Promise<void>((resolve) => {
        timer = setTimeout(resolve, 12000);
      }),
    ]);
  } catch {
    /* Ad inventory and loading failures never block the requested action. */
  } finally {
    clearTimeout(timer);
  }
}
