import React, { useEffect } from "react";
import {
  View,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  BackHandler,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  useNavigation,
  usePreventRemove,
  useIsFocused,
} from "expo-router/react-navigation";
import { useApp, Route } from "./context";
import { MessageKey } from "./i18n";
import { Row, Txt, Icon, C, Badge, Info, Button } from "./components";
import { Welcome } from "./identity-screens";
const tabs: {
  name: Route["name"];
  label: MessageKey;
  icon: React.ComponentProps<typeof Icon>["name"];
}[] = [
  { name: "home", label: "home", icon: "home" },
  { name: "rounds", label: "rounds", icon: "flag" },
  { name: "records", label: "records", icon: "bar-chart-2" },
  { name: "profile", label: "profile", icon: "user" },
];
export function Screen({
  name,
  children,
}: {
  name: Route["name"];
  children: React.ReactNode;
}) {
  const { state, t, go, back, dirty, guard, moved, resetDevice, offline } =
    useApp();
  const navigation = useNavigation(),
    focused = useIsFocused();
  usePreventRemove(focused && dirty, ({ data }) =>
    guard(() => navigation.dispatch(data.action)),
  );
  useEffect(() => {
    if (!focused) return;
    const listener = BackHandler.addEventListener("hardwareBackPress", () => {
      if (name === "home" && !dirty) return false;
      back();
      return true;
    });
    return () => listener.remove();
  }, [focused, name, dirty, back]);
  const top = tabs.some((x) => x.name === name);
  return (
    <View style={{ flex: 1, backgroundColor: "#E9EDE6", alignItems: "center" }}>
      <SafeAreaView
        style={{
          flex: 1,
          width: "100%",
          maxWidth: 540,
          backgroundColor: C.paper,
        }}
      >
        <Row
          style={{
            paddingHorizontal: 20,
            paddingVertical: 13,
            minHeight: 60,
            borderBottomWidth: 1,
            borderColor: C.line,
          }}
        >
          {state.session && !top ? (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={t("back")}
              onPress={back}
              style={{ padding: 8 }}
            >
              <Icon name="arrow-left" />
            </Pressable>
          ) : (
            <Icon name="flag" />
          )}
          <Txt
            style={{
              flex: 1,
              fontWeight: "800",
              fontSize: 19,
              letterSpacing: 2,
            }}
          >
            YAMONE <Txt style={{ fontSize: 12, fontWeight: "400" }}>GOLF</Txt>
          </Txt>
          <Badge tone="muted">v0.2.0</Badge>
        </Row>
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <ScrollView
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{ padding: 20, paddingBottom: 32, gap: 18 }}
          >
            {moved ? (
              <>
                <Info>{t("moved")}</Info>
                <Button
                  label={t("newUser")}
                  onPress={() => {
                    void resetDevice();
                  }}
                />
              </>
            ) : !state.session ? (
              <Welcome />
            ) : (
              <>
                {offline && <Info>{t("offlineDraft")}</Info>}
                {children}
              </>
            )}
          </ScrollView>
        </KeyboardAvoidingView>
        {state.session && top && (
          <Row
            style={{
              gap: 0,
              paddingVertical: 8,
              borderTopWidth: 1,
              borderColor: C.line,
              backgroundColor: C.white,
            }}
          >
            {tabs.map((tab) => (
              <Pressable
                key={tab.name}
                testID={`tab-${tab.name}`}
                accessibilityRole="tab"
                accessibilityLabel={t(tab.label)}
                accessibilityState={{ selected: name === tab.name }}
                onPress={() => go({ name: tab.name })}
                style={{
                  flex: 1,
                  alignItems: "center",
                  gap: 4,
                  paddingVertical: 7,
                  minHeight: 54,
                }}
              >
                <Icon
                  name={tab.icon}
                  color={name === tab.name ? C.green : C.muted}
                />
                <Txt
                  style={{
                    fontSize: 10,
                    fontWeight: name === tab.name ? "800" : "500",
                  }}
                >
                  {t(tab.label)}
                </Txt>
              </Pressable>
            ))}
          </Row>
        )}
      </SafeAreaView>
    </View>
  );
}
