import React, {
  useCallback,
  useLayoutEffect,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { View, Modal, ScrollView, AppState, Platform } from "react-native";
import { useRouter } from "expo-router";
import { useLocales } from "expo-localization";
import { StatusBar } from "expo-status-bar";
import { Command, EMPTY_STATE, State } from "../domain/model";
import { api } from "../data/api";
import { beforeCommand } from "../data/ads";
import { RuleError } from "../domain/engine";
import { AppContext, Dialog, Route } from "./context";
import { translator, resolveLanguage, errorText } from "./i18n";
import { Button, Txt, Info, C } from "./components";
export function AppProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter(),
    locales = useLocales();
  const [state, setState] = useState<State>(EMPTY_STATE),
    [ready, setReady] = useState(false),
    [initialError, setInitialError] = useState(""),
    [busy, setBusy] = useState(false),
    [offline, setOffline] = useState(false),
    [moved, setMoved] = useState(false),
    [dialog, setDialog] = useState<Dialog | null>(null),
    [notice, setNotice] = useState(""),
    [key, setKey] = useState(""),
    [now, setNow] = useState(() => Date.now()),
    [dirty, setDirtyState] = useState(false);
  const dirtyRef = useRef(false),
    saveRef = useRef<(() => Promise<boolean>) | undefined>(undefined),
    discardRef = useRef<(() => void) | undefined>(undefined),
    pending = useRef(false),
    sequence = useRef(0),
    stateRef = useRef(state);
  useLayoutEffect(() => {
    stateRef.current = state;
  }, [state]);
  const lang = resolveLanguage(
    state.profile?.language ?? "system",
    locales[0]?.languageTag ?? "en",
  );
  const t = useMemo(() => translator(lang), [lang]);
  const setDirty = useCallback(
    (value: boolean, save?: () => Promise<boolean>, discard?: () => void) => {
      discardRef.current = discard;
      dirtyRef.current = value;
      saveRef.current = save;
      setDirtyState(value);
    },
    [],
  );
  const handleAuth = useCallback(
    (e: unknown) => {
      if (e instanceof RuleError && e.code === "deviceMoved") {
        setMoved(true);
        setState(EMPTY_STATE);
        setDirty(false);
        return true;
      }
      return false;
    },
    [setDirty],
  );
  const refresh = useCallback(async () => {
    const seq = ++sequence.current;
    try {
      const result = await api.state();
      if (seq === sequence.current) {
        setState(result.state);
        setNow(result.serverTime);
        setOffline(false);
        setReady(true);
        setInitialError("");
        setMoved(false);
      }
    } catch (e) {
      if (seq !== sequence.current) return;
      if (handleAuth(e)) {
        setReady(true);
        return;
      }
      if (e instanceof RuleError && e.code === "unauthorized") {
        setState(EMPTY_STATE);
        setReady(true);
        return;
      }
      setOffline(true);
      if (!stateRef.current.session) {
        setInitialError("connection");
        setReady(true);
      }
    }
  }, [handleAuth]);
  useEffect(() => {
    void Promise.resolve().then(refresh);
  }, [refresh]);
  useEffect(() => {
    if (!state.session) return;
    const tick = () => {
      if (!pending.current) void refresh();
    };
    const timer = setInterval(tick, 4000),
      sub = AppState.addEventListener("change", (s) => {
        if (s === "active") tick();
      });
    return () => {
      clearInterval(timer);
      sub.remove();
    };
  }, [state.session, refresh]);
  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(""), 3500);
    return () => clearTimeout(timer);
  }, [notice]);
  useEffect(() => {
    if (Platform.OS !== "web") return;
    const handler = (e: BeforeUnloadEvent) => {
      if (dirtyRef.current) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, []);
  const action = async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    if (pending.current) return undefined;
    pending.current = true;
    sequence.current++;
    setBusy(true);
    try {
      return await fn();
    } catch (e) {
      if (!handleAuth(e))
        setDialog({
          title: "Yamone Golf",
          body: errorText(e instanceof RuleError ? e.code : "network", lang),
        });
      return undefined;
    } finally {
      pending.current = false;
      setBusy(false);
    }
  };
  const commit = async (c: Command, propagate = false) => {
    if (pending.current) return undefined;
    pending.current = true;
    sequence.current++;
    setBusy(true);
    try {
      await beforeCommand(c);
      const result = await api.command(c);
      setState(result.state);
      setNow(result.serverTime);
      setOffline(false);
      return result.state;
    } catch (e) {
      handleAuth(e);
      if (propagate) throw e;
      setDialog({
        title: "Yamone Golf",
        body: errorText(e instanceof RuleError ? e.code : "network", lang),
      });
      return undefined;
    } finally {
      pending.current = false;
      setBusy(false);
    }
  };
  const guard = (next: () => void) => {
    if (!dirtyRef.current) {
      next();
      return;
    }
    setDialog({
      title: t("unsaved"),
      body: t("unsaved"),
      confirmLabel: saveRef.current ? t("saveMove") : t("discardMove"),
      cancelLabel: t("keepEditing"),
      action: async () => {
        if (saveRef.current) {
          if (await saveRef.current()) {
            setDirty(false);
            next();
          }
        } else {
          discardRef.current?.();
          setDirty(false);
          next();
        }
      },
      ...(saveRef.current
        ? {
            secondaryLabel: t("discardMove"),
            secondary: () => {
              discardRef.current?.();
              setDirty(false);
              next();
            },
          }
        : {}),
    });
  };
  const go = (r: Route) =>
    guard(() => {
      setNotice("");
      const href = {
        pathname: r.name === "home" ? "/" : `/${r.name}`,
        params: r.id ? { id: r.id } : {},
      };
      if (["home", "rounds", "records", "profile"].includes(r.name))
        router.replace(href);
      else router.push(href);
    });
  const back = () =>
    guard(() => {
      setNotice("");
      if (router.canGoBack()) router.back();
      else router.replace("/");
    });
  const confirm = (d: Dialog) =>
    new Promise<boolean>((resolve) =>
      setDialog({
        ...d,
        action: () => resolve(true),
        onCancel: () => resolve(false),
      }),
    );
  const resetDevice = async () => {
    await action(async () => {
      await api.reset();
      setMoved(false);
      setState(EMPTY_STATE);
      setDirty(false);
      router.replace("/");
    });
  };
  const closeDialog = () => {
    dialog?.onCancel?.();
    setDialog(null);
  };
  return (
    <AppContext.Provider
      value={{
        state,
        t,
        lang,
        busy,
        now,
        dirty,
        offline,
        moved,
        go,
        back,
        commit,
        toast: setNotice,
        ask: setDialog,
        confirm,
        setDirty,
        guard,
        action,
        refresh,
        showKey: setKey,
        resetDevice,
      }}
    >
      <StatusBar style="dark" />
      {!ready ? (
        <View style={{ flex: 1, justifyContent: "center", padding: 24 }}>
          <Txt>{t("loading")}</Txt>
        </View>
      ) : initialError ? (
        <View
          style={{ flex: 1, justifyContent: "center", padding: 24, gap: 20 }}
        >
          <Info>{t("connection")}</Info>
          <Button
            label={t("retry")}
            onPress={() => {
              void refresh();
            }}
          />
        </View>
      ) : (
        children
      )}
      {!!notice && (
        <View
          pointerEvents="none"
          style={{
            position: "absolute",
            bottom: 95,
            left: 25,
            right: 25,
            padding: 16,
            borderRadius: 12,
            backgroundColor: C.green,
          }}
        >
          <Txt style={{ color: C.white, textAlign: "center" }}>{notice}</Txt>
        </View>
      )}
      <Modal
        visible={!!dialog || !!key}
        transparent
        animationType="fade"
        onRequestClose={() => {
          if (!key) closeDialog();
        }}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "#132B2566",
            alignItems: "center",
            justifyContent: "center",
            padding: 22,
          }}
        >
          <View
            accessibilityViewIsModal
            style={{
              backgroundColor: C.white,
              width: "100%",
              maxWidth: 430,
              borderRadius: 22,
              padding: 24,
              gap: 18,
              maxHeight: "85%",
            }}
          >
            <Txt style={{ fontSize: 20, fontWeight: "800" }}>
              {key ? t("recoveryKey") : dialog?.title}
            </Txt>
            <ScrollView>
              <Txt selectable style={{ lineHeight: 24, color: C.muted }}>
                {key ? `${key}\n\n${t("recoveryKeyHint")}` : dialog?.body}
              </Txt>
            </ScrollView>
            {key ? (
              <Button
                testID="key-saved"
                label={t("keySaved")}
                onPress={() => setKey("")}
              />
            ) : (
              <>
                <Button
                  testID="dialog-confirm"
                  label={dialog?.confirmLabel ?? t("confirm")}
                  variant={dialog?.destructive ? "danger" : "primary"}
                  onPress={() => {
                    const fn = dialog?.action;
                    setDialog(null);
                    void fn?.();
                  }}
                />
                {dialog?.secondary && (
                  <Button
                    testID="dialog-discard"
                    variant="outline"
                    label={dialog.secondaryLabel!}
                    onPress={() => {
                      const fn = dialog.secondary;
                      setDialog(null);
                      void fn?.();
                    }}
                  />
                )}
                {dialog?.action && (
                  <Button
                    testID="dialog-cancel"
                    variant="outline"
                    label={dialog.cancelLabel ?? t("cancel")}
                    onPress={closeDialog}
                  />
                )}
              </>
            )}
          </View>
        </View>
      </Modal>
    </AppContext.Provider>
  );
}
