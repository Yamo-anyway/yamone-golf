import React, { useState, useEffect, useRef } from "react";
import { View, Pressable } from "react-native";
import * as Crypto from "expo-crypto";
import { Round } from "../domain/model";
import {
  complete,
  editable,
  hasReceipt,
  isLocked,
  scoreSummary,
  RuleError,
} from "../domain/engine";
import {
  Button,
  Card,
  Row,
  Txt,
  Field,
  Heading,
  Info,
  Empty,
  C,
  Icon,
  Badge,
} from "./components";
import { useApp, useDirty } from "./context";
import { saveScoreDraft } from "../data/save-scores";
import { drafts, Draft, ScoreDraft } from "../data/drafts";
import { errorText } from "./i18n";
import { RoundSharing, RecordDeliveries } from "./social-screens";
import { DragHandle, moveByDistance } from "./reorder";
export const relative = (n: number) =>
  n === 0 ? "E" : n > 0 ? `+${n}` : String(n);
export function RoundCard({ round: r }: { round: Round }) {
  const { t, go, lang } = useApp();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={r.courseName}
      onPress={() => go({ name: "round", id: r.id })}
    >
      <Card>
        <Row style={{ justifyContent: "space-between" }}>
          <Badge
            tone={
              r.status === "active"
                ? "green"
                : r.status === "incomplete"
                  ? "amber"
                  : "muted"
            }
          >
            {t(r.status)}
          </Badge>
          <Txt style={{ color: C.muted, fontSize: 11 }}>
            {new Date(r.createdAt).toLocaleDateString(
              lang === "ko" ? "ko-KR" : "en-US",
            )}
          </Txt>
        </Row>
        <Txt style={{ fontSize: 19, fontWeight: "700" }}>{r.courseName}</Txt>
        <Row>
          <Txt style={{ fontSize: 12, color: C.muted, flex: 1 }}>
            {r.holes.length} {t("holes")} · {r.players.length} {t("people")} ·
            PAR {r.holes.reduce((a, h) => a + h.par, 0)}
          </Txt>
          <Icon name="arrow-up-right" size={19} />
        </Row>
      </Card>
    </Pressable>
  );
}
export function RoundScreen({ id }: { id: string }) {
  const { state, t, go, commit, busy, ask, now, toast, confirm, lang } =
    useApp();
  const r = state.rounds.find((r) => r.id === id)!;
  const userId = state.profile!.id;
  const own = r.players.find((p) => p.userId === userId);
  const received = hasReceipt(r, userId);
  const played = r.players.reduce((a, p) => a + scoreSummary(p, r).played, 0);
  const total = r.players.length * r.holes.length;
  const allComplete = r.players.every(complete);
  const confirmEnd = () =>
    ask({
      title: t("endTitle"),
      body: (allComplete ? "" : t("missing") + "\n\n") + t("endBody"),
      confirmLabel: t(allComplete ? "endRound" : "endAnyway"),
      action: async () => {
        await commit({ type: "end", roundId: id });
      },
    });
  const end = async () => {
    try {
      const pending = await drafts.load(userId, id);
      if (!pending?.dirty) {
        confirmEnd();
        return;
      }
      const discard = async () => {
        await drafts.save(userId, id, { ...pending, dirty: false });
        confirmEnd();
      };
      ask({
        title: t("unsaved"),
        body: t("unsaved"),
        confirmLabel: t("saveMove"),
        cancelLabel: t("keepEditing"),
        onCancel: () => go({ name: "score", id }),
        secondaryLabel: t("discardMove"),
        secondary: discard,
        action: async () => {
          try {
            const next = await saveScoreDraft(id, pending.hole, pending.draft, {
              confirm: (changes) =>
                confirm({
                  title: t("confirmChange"),
                  body: changes
                    .map((c) => `${c.name}: ${c.before} → ${c.after}`)
                    .join("\n"),
                }),
              commit: (c) => commit(c, true),
            });
            if (next) {
              await drafts.save(userId, id, { ...pending, dirty: false });
              confirmEnd();
            }
          } catch (e) {
            ask({
              title: t("score"),
              body: errorText(
                e instanceof RuleError ? e.code : "network",
                lang,
              ),
            });
          }
        },
      });
    } catch {
      ask({ title: t("unsaved"), body: t("storageFailure") });
    }
  };
  const receive = async () => {
    if (await commit({ type: "receive", roundId: id })) toast(t("received"));
  };
  return (
    <>
      <Row style={{ justifyContent: "space-between" }}>
        <Badge tone={r.status === "incomplete" ? "amber" : "green"}>
          {t(r.status)}
        </Badge>
        <Txt style={{ fontSize: 12, color: C.muted }}>
          {r.holes.length} {t("holes")} · PAR{" "}
          {r.holes.reduce((s, h) => s + h.par, 0)}
        </Txt>
      </Row>
      <Heading
        title={r.courseName}
        subtitle={`${r.holes[0].segmentName}${r.holes.length === 18 ? " / " + r.holes[9].segmentName : ""}${r.location ? " · " + r.location : ""}`}
      />
      <Card style={{ backgroundColor: C.green, borderColor: C.green }}>
        <Row style={{ justifyContent: "space-between" }}>
          <Txt style={{ color: C.mint, fontSize: 13 }}>{t("progress")}</Txt>
          <Txt style={{ color: C.white, fontWeight: "800", fontSize: 21 }}>
            {played}
            <Txt style={{ color: "#BCD1C4", fontSize: 13 }}> / {total}</Txt>
          </Txt>
        </Row>
        <View
          style={{ height: 6, backgroundColor: "#396052", borderRadius: 3 }}
        >
          <View
            style={{
              width: `${(played / total) * 100}%`,
              height: 6,
              backgroundColor: C.lime,
              borderRadius: 3,
            }}
          />
        </View>
        <Txt style={{ color: "#BCD1C4", fontSize: 12 }}>
          {r.players.length} {t("people")} · {r.holes.length} {t("holes")}
        </Txt>
      </Card>
      {r.autoEnded && <Info>{t("autoEnded")}</Info>}
      <RoundSharing id={id} />
      {r.status === "active" ? (
        <Button
          testID="enter-scores"
          icon="edit-3"
          label={t("enter")}
          onPress={() => go({ name: "score", id })}
        />
      ) : own &&
        ((!received && !r.receipts.some((x) => x.userId === userId)) ||
          r.deliveries?.some(
            (d) => d.userId === userId && d.status === "pending",
          )) ? (
        <>
          <Info>{t("receiveHint")}</Info>
          <Button
            testID="receive-record"
            label={t("receive")}
            icon="download"
            disabled={busy}
            onPress={receive}
          />
        </>
      ) : (
        received && (
          <Info>{isLocked(r, now) ? t("lock") : t("recordRule")}</Info>
        )
      )}
      <Row style={{ justifyContent: "space-between" }}>
        <Txt style={{ fontSize: 18, fontWeight: "700" }}>{t("players")}</Txt>
        {
          <Button
            compact
            variant="outline"
            label={t("more")}
            onPress={() => go({ name: "targets", id })}
          />
        }
      </Row>
      <Card style={{ gap: 0, paddingVertical: 5 }}>
        {ranked(r).map(({ player: p, rank }, i) => {
          const summary = scoreSummary(p, r);
          return (
            <View
              key={p.id}
              style={{
                paddingVertical: 14,
                borderBottomWidth: i < r.players.length - 1 ? 1 : 0,
                borderColor: C.line,
              }}
            >
              <Row>
                <View
                  style={{
                    width: 35,
                    height: 35,
                    borderRadius: 12,
                    backgroundColor: p.userId === userId ? C.mint : C.paper,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Txt style={{ fontWeight: "700" }}>{rank ?? "—"}</Txt>
                </View>
                <View style={{ flex: 1 }}>
                  <Row style={{ gap: 6 }}>
                    <Txt
                      numberOfLines={1}
                      style={{ fontWeight: "700", flexShrink: 1 }}
                    >
                      {p.name}
                    </Txt>
                    {p.userId === userId && <Badge>{t("me")}</Badge>}
                  </Row>
                  <Txt style={{ fontSize: 11, color: C.muted }}>
                    {summary.played}/{r.holes.length} {t("holes")}
                  </Txt>
                </View>
                <Txt style={{ fontSize: 22, fontWeight: "800" }}>
                  {summary.played ? summary.strokes : "—"}
                </Txt>
                <Txt
                  style={{
                    width: 34,
                    textAlign: "right",
                    color: summary.relative < 0 ? C.red : C.muted,
                    fontSize: 12,
                  }}
                >
                  {summary.played ? relative(summary.relative) : "—"}
                </Txt>
              </Row>
            </View>
          );
        })}
      </Card>
      <Button
        icon="grid"
        variant="outline"
        label={t("scorecard")}
        onPress={() => go({ name: "scorecard", id })}
      />
      {r.status !== "active" && own && received && !isLocked(r, now) && (
        <Button
          variant="secondary"
          label={t("ownEdit")}
          onPress={() => go({ name: "score", id })}
        />
      )}
      {r.status === "active" &&
        r.participants.some((p) => p.userId === userId && p.canEnd) && (
          <Button
            testID="end-round"
            variant="outline"
            label={t("endRound")}
            onPress={end}
            disabled={busy}
          />
        )}
      <RecordDeliveries id={id} />
      {r.status !== "active" && (
        <Card>
          <Row>
            <Icon name="award" />
            <Txt style={{ fontWeight: "700", flex: 1 }}>{t("peoria")}</Txt>
            <Badge tone="muted">{t("policyPending")}</Badge>
          </Row>
        </Card>
      )}
    </>
  );
}

export function TargetsScreen({ id }: { id: string }) {
  const { state, t, commit, busy, confirm } = useApp();
  const positions = useRef<Record<string, { y: number; height: number }>>({});
  const r = state.rounds.find((r) => r.id === id)!;
  const targets = r.participants.find(
    (p) => p.userId === state.profile!.id,
  )!.targets;
  const [name, setName] = useState("");
  const [renaming, setRenaming] = useState<string | null>(null);
  const [newName, setNewName] = useState("");
  useDirty(!!name || !!renaming, undefined, () => {
    setName("");
    setRenaming(null);
  });
  const move = (playerId: string, direction: number) => {
    const i = targets.indexOf(playerId),
      other = i + direction;
    if (other < 0 || other >= targets.length) return;
    const next = [...targets];
    [next[i], next[other]] = [next[other], next[i]];
    void commit({ type: "targets", roundId: id, targets: next });
  };
  const ordered = [
    ...targets.map((id) => r.players.find((p) => p.id === id)!),
    ...r.players.filter((p) => !targets.includes(p.id)),
  ];
  return (
    <>
      <Heading title={t("targets")} subtitle={t("targetsHint")} />
      {ordered.map((p, index) => (
        <View
          key={p.id}
          onLayout={(e) => {
            positions.current[p.id] = e.nativeEvent.layout;
          }}
          style={{ gap: 10 }}
        >
          {(index === 0 || index === targets.length) && (
            <Txt style={{ fontWeight: "700" }}>
              {t(index < targets.length ? "selected" : "unselected")}
            </Txt>
          )}
          <Card>
            <Row>
              <Pressable
                accessibilityRole="checkbox"
                accessibilityLabel={p.name}
                accessibilityState={{ checked: targets.includes(p.id) }}
                disabled={busy || r.status !== "active"}
                onPress={() =>
                  commit({
                    type: "targets",
                    roundId: id,
                    targets: targets.includes(p.id)
                      ? targets.filter((x) => x !== p.id)
                      : [...targets, p.id],
                  })
                }
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 12,
                  backgroundColor: targets.includes(p.id) ? C.green : C.paper,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Icon
                  name={targets.includes(p.id) ? "check" : "plus"}
                  color={targets.includes(p.id) ? C.white : C.muted}
                />
              </Pressable>
              <View style={{ flex: 1 }}>
                <Txt style={{ fontWeight: "700" }}>{p.name}</Txt>
                <Txt style={{ fontSize: 11, color: C.muted }}>
                  {t(p.userId ? "me" : "guest")}
                </Txt>
              </View>
              {targets.includes(p.id) && (
                <Row style={{ gap: 2 }}>
                  <DragHandle
                    testID={`drag-player-${p.id}`}
                    disabled={busy || r.status !== "active"}
                    onDrop={(dy) => {
                      void commit({
                        type: "targets",
                        roundId: id,
                        targets: moveByDistance(
                          targets,
                          p.id,
                          dy,
                          positions.current,
                        ),
                      });
                    }}
                  />
                  {[-1, 1].map((d) => (
                    <Pressable
                      key={d}
                      accessibilityRole="button"
                      accessibilityLabel={`${p.name} ${t(d < 0 ? "up" : "down")}`}
                      disabled={
                        busy ||
                        targets.indexOf(p.id) + d < 0 ||
                        targets.indexOf(p.id) + d >= targets.length
                      }
                      onPress={() => move(p.id, d)}
                      style={{ padding: 10, minHeight: 40 }}
                    >
                      <Icon
                        name={d < 0 ? "arrow-up" : "arrow-down"}
                        size={17}
                      />
                    </Pressable>
                  ))}
                </Row>
              )}
            </Row>
            {!p.userId && (
              <Row style={{ flexWrap: "wrap" }}>
                <Button
                  compact
                  variant="outline"
                  label={t("nameEdit")}
                  onPress={() => {
                    setRenaming(p.id);
                    setNewName(p.name);
                  }}
                />
                {r.status === "active" &&
                  !r.players.some((p) => p.userId === state.profile!.id) && (
                    <Button
                      compact
                      variant="secondary"
                      label={t("linkSelf")}
                      onPress={() => {
                        void commit({
                          type: "linkSelf",
                          roundId: id,
                          playerId: p.id,
                        });
                      }}
                    />
                  )}
              </Row>
            )}
            {r.status === "active" && (
              <Row style={{ flexWrap: "wrap" }}>
                {p.userId &&
                (p.userId === state.profile!.id ||
                  r.creatorId === state.profile!.id) ? (
                  <Button
                    compact
                    variant="outline"
                    label={t("unlink")}
                    disabled={busy}
                    onPress={() => {
                      setRenaming("unlink:" + p.id);
                      setNewName(p.name);
                    }}
                  />
                ) : (
                  !p.userId && (
                    <Button
                      compact
                      variant="outline"
                      label={t("deletePlayer")}
                      disabled={busy}
                      onPress={async () => {
                        if (
                          await confirm({
                            title: t("deletePlayer"),
                            body: t("deletePlayerHint"),
                            destructive: true,
                          })
                        )
                          await commit({
                            type: "deletePlayer",
                            roundId: id,
                            playerId: p.id,
                          });
                      }}
                    />
                  )
                )}
              </Row>
            )}
            {(renaming === p.id || renaming === "unlink:" + p.id) && (
              <>
                <Field
                  label={t("name")}
                  value={newName}
                  onChangeText={setNewName}
                  maxLength={32}
                />
                <Row>
                  <Button
                    compact
                    label={t("save")}
                    disabled={busy || !newName.trim()}
                    onPress={async () => {
                      if (
                        await commit({
                          type: renaming?.startsWith("unlink:")
                            ? "unlinkPlayer"
                            : "renamePlayer",
                          roundId: id,
                          playerId: p.id,
                          name: newName,
                        })
                      )
                        setRenaming(null);
                    }}
                  />
                  <Button
                    compact
                    variant="outline"
                    label={t("cancel")}
                    onPress={() => setRenaming(null)}
                  />
                </Row>
              </>
            )}
          </Card>
        </View>
      ))}
      {r.status === "active" && r.players.length < 8 && (
        <Card>
          <Field
            label={t("addPlayer")}
            value={name}
            onChangeText={setName}
            maxLength={32}
          />
          <Button
            label={t("addPlayer")}
            disabled={busy || !name.trim()}
            variant="secondary"
            onPress={async () => {
              if (
                await commit({
                  type: "addPlayer",
                  roundId: id,
                  id: Crypto.randomUUID(),
                  name,
                })
              )
                setName("");
            }}
          />
        </Card>
      )}
    </>
  );
}

export function ScoreScreen({ id }: { id: string }) {
  const {
    state,
    t,
    go,
    commit,
    busy,
    ask,
    now,
    toast,
    setDirty,
    guard,
    confirm,
    lang,
  } = useApp();
  const r = state.rounds.find((r) => r.id === id)!;
  const user = state.profile!.id;
  const targetIds =
    r.status === "active"
      ? r.participants.find((p) => p.userId === user)!.targets
      : r.players.filter((p) => p.userId === user).map((p) => p.id);
  const players = targetIds
    .map((id) => r.players.find((p) => p.id === id)!)
    .filter(Boolean);
  const [hole, setHole] = useState(() => {
    const first = r.holes.findIndex((_, i) =>
      players.some((p) => p.scores[i].value === null),
    );
    return first < 0 ? 0 : first;
  });
  const makeDraft = (index: number): Draft =>
    Object.fromEntries(
      players.map((p) => [
        p.id,
        {
          value: p.scores[index].value ?? r.holes[index].par,
          original: p.scores[index].value,
          version: p.scores[index].version,
        },
      ]),
    );
  const [storedDraft, setDraft] = useState<Draft>(() => makeDraft(hole)),
    [dirty, mark] = useState(false),
    [hydrated, setHydrated] = useState(false);
  const draft = dirty ? storedDraft : makeDraft(hole);
  const persist = (value: ScoreDraft) => {
    void drafts.save(user, id, value).catch(() => toast(t("storageFailure")));
  };
  useEffect(() => {
    let mounted = true;
    void drafts
      .load(user, id)
      .then((saved) => {
        if (!mounted) return;
        if (saved && saved.hole < r.holes.length) {
          setHole(saved.hole);
          if (saved.dirty) {
            setDraft(saved.draft);
            mark(true);
          }
        }
        setHydrated(true);
      })
      .catch(() => {
        if (mounted) {
          setHydrated(true);
          toast(t("storageFailure"));
        }
      });
    return () => {
      mounted = false;
    };
  }, [id, user, r.holes.length, t, toast]);
  const reset = () => {
    const next = { hole, draft: makeDraft(hole), dirty: false };
    setDraft(next.draft);
    mark(false);
    setDirty(false);
    persist(next);
  };
  const canEdit =
    hydrated &&
    players.length > 0 &&
    players.every((p) => editable(r, user, p, now)) &&
    Object.keys(draft).every((id) => players.some((p) => p.id === id));
  const inFlight = useRef(false);
  const [saving, setSaving] = useState(false);
  const saveDraft = async (deleting = false): Promise<boolean> => {
    if (!canEdit || inFlight.current) return false;
    inFlight.current = true;
    setSaving(true);
    try {
      const next = await saveScoreDraft(id, hole, draft, {
        deleting,
        confirm: (changes) =>
          confirm({
            title: t("confirmChange"),
            body:
              t("confirmChangeBody") +
              "\n\n" +
              changes
                .map(
                  (c) =>
                    `${c.name}: ${c.before} → ${c.after ?? t("unselected")}`,
                )
                .join("\n"),
            confirmLabel: t(deleting ? "deleteHole" : "saveHole"),
          }),
        commit: (c) => commit(c, true),
      });
      if (!next) return false;
      const saved = next.rounds.find((r) => r.id === id)!;
      const nextDraft: Draft = Object.fromEntries(
        Object.keys(draft).map((id) => {
          const cell = saved.players.find((p) => p.id === id)!.scores[hole];
          return [
            id,
            {
              value: cell.value ?? saved.holes[hole].par,
              original: cell.value,
              version: cell.version,
            },
          ];
        }),
      );
      setDraft(nextDraft);
      mark(false);
      setDirty(false);
      await drafts.save(user, id, { hole, draft: nextDraft, dirty: false });
      toast(t("saved"));
      return true;
    } catch (e) {
      ask({
        title: t("score"),
        body: errorText(e instanceof RuleError ? e.code : "network", lang),
      });
      return false;
    } finally {
      inFlight.current = false;
      setSaving(false);
    }
  };
  useDirty(dirty, () => saveDraft(), reset);
  const goHole = (next: number) =>
    guard(() => {
      toast("");
      const value = { hole: next, draft: makeDraft(next), dirty: false };
      setHole(next);
      setDraft(value.draft);
      mark(false);
      setDirty(false);
      persist(value);
    });
  const save = () => {
    void saveDraft();
  };
  const remove = () =>
    ask({
      title: t("deleteTitle"),
      body: t("deleteBody"),
      confirmLabel: t("deleteHole"),
      destructive: true,
      action: async () => {
        await saveDraft(true);
      },
    });
  if (!players.length)
    return (
      <>
        <Empty title={t("noTargets")} />
        <Button
          label={t("changeTargets")}
          onPress={() => go({ name: "targets", id })}
        />
      </>
    );
  return (
    <>
      <Row style={{ justifyContent: "space-between" }}>
        <Txt numberOfLines={1} style={{ fontWeight: "700", flex: 1 }}>
          {r.courseName}
        </Txt>
        <Badge>
          {r.holes.length} {t("holes")}
        </Badge>
      </Row>
      <View style={{ gap: 5 }}>
        {[0, ...(r.holes.length === 18 ? [9] : [])].map((start) => (
          <View key={start} style={{ gap: 4 }}>
            <Txt style={{ fontSize: 11, color: C.muted }}>
              {t(start === 0 ? "front" : "backNine")}
            </Txt>
            <Row style={{ gap: 3 }}>
              {r.holes.slice(start, start + 9).map((h, i) => {
                const index = start + i;
                const filled = players.every(
                  (p) => p.scores[index].value !== null,
                );
                return (
                  <Pressable
                    key={index}
                    testID={`hole-${index + 1}`}
                    accessibilityRole="button"
                    accessibilityLabel={`Hole ${index + 1}`}
                    accessibilityState={{ selected: hole === index }}
                    disabled={saving}
                    onPress={() => goHole(index)}
                    style={{
                      flex: 1,
                      minHeight: 44,
                      backgroundColor:
                        hole === index ? C.green : filled ? C.mint : C.white,
                      borderRadius: 10,
                      alignItems: "center",
                      justifyContent: "center",
                      gap: 1,
                    }}
                  >
                    <Txt
                      style={{
                        color: hole === index ? C.white : C.ink,
                        fontWeight: "700",
                        fontSize: 13,
                      }}
                    >
                      {index + 1}
                    </Txt>
                    <View
                      style={{
                        height: 3,
                        width: 3,
                        borderRadius: 2,
                        backgroundColor: filled
                          ? hole === index
                            ? C.lime
                            : C.green
                          : "transparent",
                      }}
                    />
                  </Pressable>
                );
              })}
            </Row>
          </View>
        ))}
      </View>
      <Card style={{ backgroundColor: C.mint, borderWidth: 0, padding: 15 }}>
        <Row style={{ justifyContent: "space-between" }}>
          <View>
            <Txt
              style={{
                color: C.green2,
                fontSize: 11,
                fontWeight: "700",
                letterSpacing: 1,
              }}
            >
              {r.holes[hole].segmentName} · {hole + 1} {t("holes")}
            </Txt>
            <Txt style={{ fontSize: 31, fontWeight: "800", lineHeight: 39 }}>
              PAR {r.holes[hole].par}
            </Txt>
          </View>
          <Icon name="flag" size={32} />
        </Row>
      </Card>
      <Row style={{ gap: 7 }}>
        <View style={{ flex: 1.3 }}>
          <Button
            testID="save-scores"
            compact
            label={t(
              busy
                ? "saving"
                : players.some((p) => p.scores[hole].value !== null)
                  ? "editHole"
                  : "saveHole",
            )}
            disabled={busy || saving || !canEdit}
            onPress={save}
          />
        </View>
        <View style={{ flex: 1 }}>
          <Button
            compact
            label={t("cancel")}
            variant="secondary"
            disabled={busy || saving}
            onPress={reset}
          />
        </View>
        {players.some((p) => p.scores[hole].value !== null) && (
          <View style={{ flex: 1 }}>
            <Button
              compact
              label={t("deleteHole")}
              variant="danger"
              disabled={
                busy ||
                !canEdit ||
                !players.some((p) => p.scores[hole].value !== null)
              }
              onPress={remove}
            />
          </View>
        )}
      </Row>
      <Txt style={{ fontSize: 11, color: C.muted }}>{t("holeScope")}</Txt>
      {!canEdit && (
        <Info>{isLocked(r, now) ? t("lock") : t("recordRule")}</Info>
      )}
      {players.map((p) => {
        const d = draft[p.id] ?? {
          value: p.scores[hole].value ?? r.holes[hole].par,
          original: p.scores[hole].value,
          version: p.scores[hole].version,
        };
        return (
          <Card key={p.id} style={{ padding: 14, gap: 8 }}>
            <Row style={{ gap: 6 }}>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Txt numberOfLines={1} style={{ fontWeight: "700" }}>
                  {p.name}
                </Txt>
                <Txt style={{ fontSize: 10, color: C.muted }}>
                  {dirty && d.value !== (d.original ?? r.holes[hole].par)
                    ? t("draft")
                    : d.original === null
                      ? t("defaultPar")
                      : `${t("savedScore")} · ${d.original}`}
                </Txt>
              </View>
              <Row style={{ gap: 4 }}>
                {[-1, 0, 1].map((delta) =>
                  delta === 0 ? (
                    <View
                      key={delta}
                      style={{ width: 46, alignItems: "center" }}
                    >
                      <Txt
                        style={{
                          fontSize: 27,
                          fontWeight: "800",
                          lineHeight: 30,
                          color: d.value < r.holes[hole].par ? C.red : C.ink,
                        }}
                      >
                        {d.value}
                      </Txt>
                      <Txt
                        style={{ fontSize: 10, color: C.muted, lineHeight: 12 }}
                      >
                        {relative(d.value - r.holes[hole].par)}
                      </Txt>
                    </View>
                  ) : (
                    <Pressable
                      key={delta}
                      testID={`${delta > 0 ? "plus" : "minus"}-${p.id}`}
                      accessibilityRole="button"
                      accessibilityLabel={`${p.name} ${delta > 0 ? "+1" : "−1"}`}
                      disabled={
                        !canEdit ||
                        busy ||
                        saving ||
                        d.value + delta < 1 ||
                        d.value + delta > 99
                      }
                      onPress={() => {
                        toast("");
                        mark(true);
                        const next = {
                          ...draft,
                          [p.id]: { ...d, value: d.value + delta },
                        };
                        setDraft(next);
                        persist({ hole, draft: next, dirty: true });
                      }}
                      style={{
                        width: 44,
                        height: 46,
                        backgroundColor: C.paper,
                        borderRadius: 12,
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Icon name={delta > 0 ? "plus" : "minus"} size={21} />
                    </Pressable>
                  ),
                )}
              </Row>
            </Row>
          </Card>
        );
      })}
      <Row>
        <View style={{ flex: 1 }}>
          <Button
            compact
            variant="outline"
            label={t("previous")}
            disabled={saving || hole === 0}
            onPress={() => goHole(hole - 1)}
          />
        </View>
        <View style={{ flex: 1 }}>
          <Button
            compact
            variant="outline"
            label={t("next")}
            disabled={saving || hole === r.holes.length - 1}
            onPress={() => goHole(hole + 1)}
          />
        </View>
      </Row>
      <Button
        variant="outline"
        label={t("scorecard")}
        icon="grid"
        onPress={() => go({ name: "scorecard", id })}
      />
      {r.status === "active" && (
        <Button
          compact
          variant="outline"
          label={t("changeTargets")}
          onPress={() => go({ name: "targets", id })}
        />
      )}
    </>
  );
}

function ScoreMark({ value, par }: { value: number | null; par: number }) {
  const delta = value === null ? 0 : value - par;
  return (
    <View
      style={{
        width: 25,
        height: 25,
        alignItems: "center",
        justifyContent: "center",
        borderWidth: value !== null && delta !== 0 ? 1 : 0,
        borderColor: delta < 0 ? C.red : C.blue,
        borderRadius: delta < 0 ? 13 : 3,
      }}
    >
      {value !== null && delta >= 2 && (
        <View
          style={{
            position: "absolute",
            inset: 2,
            borderWidth: 1,
            borderRadius: 1,
            borderColor: C.blue,
          }}
        />
      )}
      <Txt
        style={{
          fontSize: 12,
          fontWeight: "700",
          color:
            value === null
              ? C.muted
              : delta < 0
                ? C.red
                : delta > 0
                  ? C.blue
                  : C.ink,
        }}
      >
        {value ?? "–"}
      </Txt>
    </View>
  );
}
export function ScorecardScreen({ id }: { id: string }) {
  const { state, t } = useApp();
  const r = state.rounds.find((r) => r.id === id)!;
  return (
    <>
      <Heading title={t("scorecard")} subtitle={r.courseName} />
      <Info>{t("scoreLegend")}</Info>
      {ranked(r).map(({ player: p, rank }) => (
        <Card key={p.id} style={{ padding: 12, gap: 10 }}>
          <Row style={{ justifyContent: "space-between" }}>
            <Row style={{ flex: 1 }}>
              <Badge>{rank ?? "—"}</Badge>
              <Txt
                numberOfLines={1}
                style={{ fontWeight: "700", flexShrink: 1 }}
              >
                {p.name}
              </Txt>
              {p.userId === state.profile!.id && <Badge>{t("me")}</Badge>}
            </Row>
            <Txt style={{ fontSize: 20, fontWeight: "800" }}>
              {scoreSummary(p, r).played ? scoreSummary(p, r).strokes : "—"}{" "}
              <Txt style={{ fontSize: 12, color: C.muted }}>
                {scoreSummary(p, r).played
                  ? relative(scoreSummary(p, r).relative)
                  : ""}
              </Txt>
            </Txt>
          </Row>
          {[0, ...(r.holes.length === 18 ? [9] : [])].map((start) => (
            <View key={start} style={{ gap: 4 }}>
              <Row style={{ justifyContent: "space-between" }}>
                <Txt style={{ fontSize: 10, color: C.muted }}>
                  {t(start === 0 ? "front" : "backNine")} ·{" "}
                  {r.holes[start].segmentName}
                </Txt>
                <Txt style={{ fontSize: 10, color: C.muted }}>
                  {p.scores
                    .slice(start, start + 9)
                    .some((s) => s.value !== null)
                    ? p.scores
                        .slice(start, start + 9)
                        .reduce((s, h) => s + (h.value ?? 0), 0)
                    : "—"}
                </Txt>
              </Row>
              <Row
                style={{
                  gap: 0,
                  backgroundColor: C.paper,
                  borderRadius: 6,
                  paddingVertical: 3,
                }}
              >
                {r.holes.slice(start, start + 9).map((h) => (
                  <View
                    key={h.number}
                    style={{ flex: 1, alignItems: "center" }}
                  >
                    <Txt
                      style={{ fontSize: 10, color: C.muted, lineHeight: 15 }}
                    >
                      {h.number}
                    </Txt>
                    <Txt
                      style={{
                        fontSize: 10,
                        fontWeight: "700",
                        lineHeight: 15,
                      }}
                    >
                      {h.par}
                    </Txt>
                  </View>
                ))}
              </Row>
              <Row style={{ gap: 0, paddingVertical: 2 }}>
                {p.scores.slice(start, start + 9).map((s, i) => (
                  <View key={i} style={{ flex: 1, alignItems: "center" }}>
                    <ScoreMark value={s.value} par={r.holes[start + i].par} />
                  </View>
                ))}
              </Row>
            </View>
          ))}
        </Card>
      ))}
    </>
  );
}

export function ranked(r: Round) {
  const sorted = [...r.players].sort((a, b) => {
    const x = scoreSummary(a, r),
      y = scoreSummary(b, r);
    return (
      (x.played ? x.strokes : Infinity) - (y.played ? y.strokes : Infinity)
    );
  });
  return sorted.map((player, i) => {
    const score = scoreSummary(player, r);
    return {
      player,
      rank: score.played
        ? sorted.findIndex(
            (p) => scoreSummary(p, r).strokes === score.strokes,
          ) + 1
        : null,
    };
  });
}
