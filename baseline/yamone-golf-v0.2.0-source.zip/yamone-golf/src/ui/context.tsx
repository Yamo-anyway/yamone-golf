import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useLayoutEffect,
} from "react";
import { useIsFocused } from "expo-router/react-navigation";
import { Command, State } from "../domain/model";
import { Translate } from "./i18n";
export type Route = {
  name:
    | "home"
    | "rounds"
    | "records"
    | "profile"
    | "courses"
    | "course"
    | "create"
    | "round"
    | "targets"
    | "score"
    | "scorecard"
    | "transfer"
    | "recovery-email"
    | "join";
  id?: string;
};
export type Dialog = {
  title: string;
  body: string;
  confirmLabel?: string;
  cancelLabel?: string;
  destructive?: boolean;
  action?: () => void | Promise<void>;
  secondaryLabel?: string;
  secondary?: () => void | Promise<void>;
  onCancel?: () => void;
};
export type AppContextValue = {
  state: State;
  t: Translate;
  lang: "ko" | "en";
  busy: boolean;
  now: number;
  dirty: boolean;
  offline: boolean;
  moved: boolean;
  go: (r: Route) => void;
  back: () => void;
  commit: (c: Command, propagate?: boolean) => Promise<State | undefined>;
  toast: (s: string) => void;
  ask: (d: Dialog) => void;
  confirm: (d: Dialog) => Promise<boolean>;
  setDirty: (
    dirty: boolean,
    save?: () => Promise<boolean>,
    discard?: () => void,
  ) => void;
  guard: (action: () => void) => void;
  action: <T>(fn: () => Promise<T>) => Promise<T | undefined>;
  refresh: () => Promise<void>;
  showKey: (key: string) => void;
  resetDevice: () => Promise<void>;
};
export const AppContext = createContext<AppContextValue>(null!);
export const useApp = () => useContext(AppContext);
export function useDirty(
  dirty: boolean,
  save?: () => Promise<boolean>,
  discard?: () => void,
) {
  const { setDirty } = useApp();
  const focused = useIsFocused();
  const ref = useRef(save),
    discardRef = useRef(discard);
  useLayoutEffect(() => {
    ref.current = save;
    discardRef.current = discard;
  }, [save, discard]);
  const hasSave = !!save;
  useEffect(() => {
    if (!focused) return;
    setDirty(dirty, hasSave ? () => ref.current!() : undefined, () =>
      discardRef.current?.(),
    );
    return () => setDirty(false);
  }, [dirty, focused, setDirty, hasSave]);
}
