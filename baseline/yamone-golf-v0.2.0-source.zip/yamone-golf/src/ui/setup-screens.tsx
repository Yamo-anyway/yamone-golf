import React, { useState, useRef } from "react";
import { View, Switch, Pressable } from "react-native";
import * as Crypto from "expo-crypto";
import { Par, Segment } from "../domain/model";
import {
  Button,
  Card,
  Row,
  Txt,
  Field,
  Pill,
  Heading,
  Info,
  Empty,
  C,
  Icon,
  Badge,
} from "./components";
import { useApp, useDirty } from "./context";
import { DragHandle, moveByDistance } from "./reorder";

export function CoursesScreen() {
  const { state, t, go, commit, busy, confirm } = useApp();
  const positions = useRef<Record<string, { y: number; height: number }>>({});
  const reorder = (ids: string[]) => {
    void commit({ type: "courseOrder", ids });
  };
  const [query, setQuery] = useState("");
  const courses = state.courses.filter((c) =>
    (c.name + " " + c.location).toLowerCase().includes(query.toLowerCase()),
  );
  return (
    <>
      <Heading title={t("courses")} />
      <Field
        label={t("selectCourse")}
        value={query}
        onChangeText={setQuery}
        placeholder={t("courseName")}
      />
      {!state.courses.length && (
        <Empty title={t("noCourses")} body={t("noCoursesSub")} />
      )}
      {courses.map((c) => (
        <View
          key={c.id}
          onLayout={(e) => {
            positions.current[c.id] = e.nativeEvent.layout;
          }}
        >
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={c.name}
            onPress={() => go({ name: "course", id: c.id })}
          >
            <Card>
              <Row>
                <View
                  style={{
                    width: 44,
                    height: 44,
                    backgroundColor: C.mint,
                    borderRadius: 14,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Icon name="flag" />
                </View>
                <View style={{ flex: 1 }}>
                  <Txt style={{ fontSize: 17, fontWeight: "700" }}>
                    {c.name}
                  </Txt>
                  <Txt style={{ fontSize: 12, color: C.muted }}>
                    {c.location || "—"} · {c.segments.length * 9} {t("holes")}
                  </Txt>
                </View>
                <Icon name="chevron-right" />
              </Row>
              <Txt style={{ fontSize: 12, color: C.muted }}>
                {c.segments.map((s) => s.name).join(" / ")}
              </Txt>
            </Card>
          </Pressable>
          <Row>
            <DragHandle
              testID={`drag-course-${c.id}`}
              disabled={busy || !!query}
              onDrop={(dy) =>
                reorder(
                  moveByDistance(
                    state.courses.map((c) => c.id),
                    c.id,
                    dy,
                    positions.current,
                  ),
                )
              }
            />
            {[-1, 1].map((d) => (
              <Button
                key={d}
                compact
                variant="outline"
                label={t(d < 0 ? "up" : "down")}
                disabled={
                  busy ||
                  state.courses.findIndex((x) => x.id === c.id) + d < 0 ||
                  state.courses.findIndex((x) => x.id === c.id) + d >=
                    state.courses.length
                }
                onPress={() => {
                  const ids = state.courses.map((c) => c.id),
                    i = ids.indexOf(c.id);
                  [ids[i], ids[i + d]] = [ids[i + d], ids[i]];
                  reorder(ids);
                }}
              />
            ))}
          </Row>
          <Button
            compact
            variant="outline"
            label={t("removeCourse")}
            disabled={busy}
            onPress={async () => {
              if (
                await confirm({
                  title: t("removeCourse"),
                  body: t("removeCourseHint"),
                })
              )
                await commit({ type: "removeCourse", courseId: c.id });
            }}
          />
        </View>
      ))}
      <Button
        label={t("newCourse")}
        icon="plus"
        onPress={() => go({ name: "course" })}
        testID="add-course"
      />
    </>
  );
}
export function CourseEditor({ id }: { id?: string }) {
  const { state, t, commit, back, busy, toast, setDirty } = useApp();
  const source = state.courses.find((c) => c.id === id);
  const [name, setName] = useState(source?.name ?? "");
  const [location, setLocation] = useState(source?.location ?? "");
  const make = (i: number): Segment => ({
    id: Crypto.randomUUID(),
    name: i === 0 ? "OUT" : i === 1 ? "IN" : String.fromCharCode(65 + i),
    pars: Array(9).fill(4),
  });
  const [segments, setSegments] = useState<Segment[]>(
    source?.segments.map((s) => ({ ...s, pars: [...s.pars] })) ?? [
      make(0),
      make(1),
    ],
  );
  const [selected, setSelected] = useState(0);
  const [dirty, mark] = useState(false);

  const edit = (fn: () => void) => {
    mark(true);
    fn();
  };
  const count = (n: number) =>
    edit(() => {
      setSegments((old) =>
        Array.from({ length: n }, (_, i) => old[i] ?? make(i)),
      );
      setSelected((v) => Math.min(v, n - 1));
    });
  const parChange = (hole: number, par: Par) =>
    edit(() =>
      setSegments((old) =>
        old.map((s, i) =>
          i === selected
            ? { ...s, pars: s.pars.map((p, j) => (j === hole ? par : p)) }
            : s,
        ),
      ),
    );
  const save = async (leave = true) => {
    const result = await commit({
      type: "course",
      course: {
        id: source?.id ?? Crypto.randomUUID(),
        name,
        location,
        segments,
      },
    });
    if (result) {
      mark(false);
      setDirty(false);
      toast(t("saved"));
      if (leave) back();
      return true;
    }
    return false;
  };
  useDirty(dirty, () => save(false));
  return (
    <>
      <Heading title={t(source ? "editCourse" : "newCourse")} />
      <Field
        testID="course-name"
        label={t("courseName")}
        value={name}
        onChangeText={(v) => edit(() => setName(v))}
        placeholder="Yamone Country Club"
      />
      <Field
        label={t("location")}
        value={location}
        maxLength={120}
        onChangeText={(v) => edit(() => setLocation(v))}
      />
      <Txt style={{ fontWeight: "700" }}>{t("segments")}</Txt>
      <Row style={{ flexWrap: "wrap" }}>
        {[1, 2, 3, 4, 9].map((n) => (
          <Pill
            key={n}
            label={`${n * 9} ${t("holes")}`}
            selected={segments.length === n}
            onPress={() => count(n)}
          />
        ))}
      </Row>
      <Card>
        <Row style={{ flexWrap: "wrap" }}>
          {segments.map((s, i) => (
            <Pill
              key={s.id}
              label={s.name}
              selected={selected === i}
              onPress={() => setSelected(i)}
            />
          ))}
        </Row>
        <Field
          label={t("segmentName")}
          value={segments[selected].name}
          maxLength={32}
          onChangeText={(v) =>
            edit(() =>
              setSegments((old) =>
                old.map((s, i) => (i === selected ? { ...s, name: v } : s)),
              ),
            )
          }
        />
        <Row style={{ justifyContent: "space-between" }}>
          <Txt style={{ fontWeight: "700" }}>{t("pars")}</Txt>
          <Badge>
            PAR {segments[selected].pars.reduce((s, p) => s + p, 0)}
          </Badge>
        </Row>
        {segments[selected].pars.map((par, i) => (
          <Row key={i} style={{ gap: 6 }}>
            <Txt style={{ width: 30, color: C.muted, fontWeight: "700" }}>
              {String(i + 1).padStart(2, "0")}
            </Txt>
            {([3, 4, 5, 6, 7] as Par[]).map((p) => (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Hole ${i + 1} Par ${p}`}
                accessibilityState={{ selected: p === par }}
                key={p}
                onPress={() => parChange(i, p)}
                style={{
                  flex: 1,
                  minHeight: 40,
                  alignItems: "center",
                  justifyContent: "center",
                  borderRadius: 9,
                  backgroundColor: p === par ? C.green : C.paper,
                }}
              >
                <Txt
                  style={{
                    color: p === par ? C.white : C.muted,
                    fontWeight: "600",
                  }}
                >
                  {p}
                </Txt>
              </Pressable>
            ))}
          </Row>
        ))}
      </Card>
      <Button
        testID="save-course"
        label={t(busy ? "saving" : "save")}
        disabled={busy || !name.trim() || segments.some((s) => !s.name.trim())}
        onPress={() => {
          void save();
        }}
      />
    </>
  );
}
export function CreateRoundScreen() {
  const { state, t, commit, go, busy, setDirty } = useApp();
  const [courseId, setCourse] = useState(state.courses[0]?.id ?? "");
  const [holes, setHoles] = useState(18);
  const [front, setFront] = useState(0);
  const [back, setBack] = useState(1);
  const [count, setCount] = useState(4);
  const [self, setSelf] = useState(true);
  const [names, setNames] = useState<string[]>(Array(8).fill(""));
  const [dirty, mark] = useState(false);
  useDirty(dirty);
  const course = state.courses.find((c) => c.id === courseId);
  const active = state.rounds.find((r) => r.status === "active");
  const set = (fn: () => void) => {
    mark(true);
    fn();
  };
  if (active)
    return (
      <>
        <Info>{t("active")}</Info>
        <Button
          label={t("continue")}
          onPress={() => go({ name: "round", id: active.id })}
        />
      </>
    );
  if (!course)
    return (
      <>
        <Empty title={t("noCourses")} body={t("noCoursesSub")} />
        <Button label={t("newCourse")} onPress={() => go({ name: "course" })} />
      </>
    );
  const create = async () => {
    const id = Crypto.randomUUID();
    const result = await commit({
      type: "create",
      id,
      courseId,
      segmentIds:
        holes === 9
          ? [course.segments[front].id]
          : [
              course.segments[front].id,
              course.segments[Math.min(back, course.segments.length - 1)].id,
            ],
      players: Array.from({ length: count }, (_, i) => ({
        id: Crypto.randomUUID(),
        name:
          self && i === 0
            ? state.profile!.nickname
            : names[i].trim() || `${t("player")} ${i + 1}`,
        self: self && i === 0,
      })),
    });
    if (result) {
      mark(false);
      setDirty(false);
      go({ name: "round", id });
    }
  };
  return (
    <>
      <Heading title={t("newRound")} subtitle={t("noActiveSub")} />
      <Txt style={{ fontWeight: "700" }}>{t("selectCourse")}</Txt>
      {state.courses.map((c) => (
        <Pill
          key={c.id}
          label={c.name}
          selected={courseId === c.id}
          onPress={() =>
            set(() => {
              setCourse(c.id);
              setFront(0);
              setBack(Math.min(1, c.segments.length - 1));
            })
          }
        />
      ))}
      <Card>
        <Txt style={{ fontWeight: "700" }}>{t("holeCount")}</Txt>
        <Row>
          {[9, 18].map((n) => (
            <Pill
              key={n}
              label={`${n} ${t("holes")}`}
              selected={holes === n}
              onPress={() => set(() => setHoles(n))}
            />
          ))}
        </Row>
        <Txt style={{ fontSize: 12, color: C.muted }}>{t("front")}</Txt>
        <Row style={{ flexWrap: "wrap" }}>
          {course.segments.map((s, i) => (
            <Pill
              key={s.id}
              label={s.name}
              selected={front === i}
              onPress={() => set(() => setFront(i))}
            />
          ))}
        </Row>
        {holes === 18 && (
          <>
            <Txt style={{ fontSize: 12, color: C.muted }}>{t("backNine")}</Txt>
            <Row style={{ flexWrap: "wrap" }}>
              {course.segments.map((s, i) => (
                <Pill
                  key={s.id}
                  label={s.name}
                  selected={Math.min(back, course.segments.length - 1) === i}
                  onPress={() => set(() => setBack(i))}
                />
              ))}
            </Row>
          </>
        )}
      </Card>
      <Card>
        <Row style={{ justifyContent: "space-between" }}>
          <Txt style={{ fontWeight: "700" }}>{t("players")}</Txt>
          <Badge>
            {count} {t("people")}
          </Badge>
        </Row>
        <Row style={{ flexWrap: "wrap", gap: 6 }}>
          {Array.from({ length: 8 }, (_, i) => i + 1).map((n) => (
            <Pill
              key={n}
              label={String(n)}
              selected={count === n}
              onPress={() => set(() => setCount(n))}
            />
          ))}
        </Row>
        <Row>
          <View style={{ flex: 1 }}>
            <Txt style={{ fontWeight: "700" }}>{t("self")}</Txt>
            <Txt style={{ fontSize: 11, color: C.muted }}>{t("selfHint")}</Txt>
          </View>
          <Switch
            testID="playing-self"
            accessibilityLabel={t("self")}
            value={self}
            onValueChange={(v) => set(() => setSelf(v))}
            trackColor={{ true: C.green, false: C.line }}
          />
        </Row>
        {Array.from({ length: count }, (_, i) =>
          self && i === 0 ? (
            <Row key={i}>
              <Badge>{t("me")}</Badge>
              <Txt style={{ fontWeight: "700" }}>{state.profile!.nickname}</Txt>
            </Row>
          ) : (
            <Field
              key={i}
              label={`${t("player")} ${i + 1}`}
              value={names[i]}
              maxLength={32}
              placeholder={`${t("player")} ${i + 1}`}
              onChangeText={(v) =>
                set(() =>
                  setNames((old) => old.map((s, j) => (j === i ? v : s))),
                )
              }
            />
          ),
        )}
      </Card>
      <Info>{t("snapshot")}</Info>
      <Button
        testID="start-round"
        label={t(busy ? "saving" : "create")}
        disabled={busy}
        icon="flag"
        onPress={create}
      />
    </>
  );
}
