import React from "react";
import {
  View,
  Text,
  Pressable,
  TextInput,
  StyleSheet,
  ViewStyle,
  TextStyle,
} from "react-native";
import Feather from "@expo/vector-icons/Feather";
export const C = {
  paper: "#F6F7F2",
  white: "#FFFFFF",
  ink: "#1F302A",
  muted: "#6C7B72",
  green: "#173F34",
  green2: "#235B49",
  mint: "#DBEFE2",
  lime: "#D9ED9C",
  line: "#E2E8DF",
  red: "#AE483C",
  blue: "#3B637D",
  sand: "#F6ECCD",
};
export function Icon({
  name,
  size = 20,
  color = C.green,
}: {
  name: React.ComponentProps<typeof Feather>["name"];
  size?: number;
  color?: string;
}) {
  return <Feather name={name} size={size} color={color} />;
}
export function Txt({
  children,
  style,
  numberOfLines,
  selectable,
}: {
  children: React.ReactNode;
  style?: TextStyle | TextStyle[];
  numberOfLines?: number;
  selectable?: boolean;
}) {
  return (
    <Text
      selectable={selectable}
      numberOfLines={numberOfLines}
      style={[s.text, style]}
    >
      {children}
    </Text>
  );
}
export function Button({
  label,
  onPress,
  variant = "primary",
  disabled = false,
  icon,
  testID,
  compact = false,
}: {
  label: string;
  onPress: () => void;
  variant?: "primary" | "secondary" | "outline" | "danger";
  disabled?: boolean;
  icon?: React.ComponentProps<typeof Feather>["name"];
  testID?: string;
  compact?: boolean;
}) {
  const bg =
    variant === "primary"
      ? C.green
      : variant === "secondary"
        ? C.mint
        : variant === "danger"
          ? "#F8E8E3"
          : C.white;
  const color =
    variant === "primary" ? C.white : variant === "danger" ? C.red : C.green;
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        s.button,
        {
          backgroundColor: bg,
          opacity: disabled ? 0.4 : pressed ? 0.75 : 1,
          borderWidth: variant === "outline" ? 1 : 0,
          borderColor: C.line,
        },
        compact && { minHeight: 42, paddingHorizontal: 12, paddingVertical: 8 },
      ]}
    >
      {icon && <Icon name={icon} color={color} size={18} />}
      <Txt
        style={{
          color,
          fontWeight: "700",
          fontSize: compact ? 13 : 15,
          textAlign: "center",
        }}
      >
        {label}
      </Txt>
    </Pressable>
  );
}
export function Card({
  children,
  style,
}: {
  children: React.ReactNode;
  style?: ViewStyle | ViewStyle[];
}) {
  return <View style={[s.card, style]}>{children}</View>;
}
export function Row({
  children,
  style,
}: {
  children: React.ReactNode;
  style?: ViewStyle | ViewStyle[];
}) {
  return <View style={[s.row, style]}>{children}</View>;
}
export function Badge({
  children,
  tone = "green",
}: {
  children: React.ReactNode;
  tone?: "green" | "muted" | "amber";
}) {
  return (
    <View
      style={{
        backgroundColor:
          tone === "green" ? C.mint : tone === "amber" ? C.sand : "#EBEFE8",
        paddingHorizontal: 9,
        paddingVertical: 5,
        borderRadius: 8,
        alignSelf: "flex-start",
      }}
    >
      <Txt
        style={{
          fontSize: 11,
          fontWeight: "700",
          color: tone === "amber" ? "#806225" : C.green,
        }}
      >
        {children}
      </Txt>
    </View>
  );
}
export function Field({
  label,
  value,
  onChangeText,
  placeholder,
  maxLength = 80,
  testID,
}: {
  label: string;
  value: string;
  onChangeText: (s: string) => void;
  placeholder?: string;
  maxLength?: number;
  testID?: string;
}) {
  return (
    <View style={{ gap: 8 }}>
      <Txt style={{ fontSize: 13, fontWeight: "600" }}>{label}</Txt>
      <TextInput
        testID={testID}
        accessibilityLabel={label}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#96A097"
        maxLength={maxLength}
        style={s.input}
        autoCapitalize="sentences"
      />
    </View>
  );
}
export function Pill({
  label,
  selected,
  onPress,
  testID,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
  testID?: string;
}) {
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ selected }}
      onPress={onPress}
      style={[
        s.pill,
        selected && { backgroundColor: C.green, borderColor: C.green },
      ]}
    >
      <Txt
        style={{
          color: selected ? C.white : C.muted,
          fontSize: 13,
          fontWeight: "600",
        }}
      >
        {label}
      </Txt>
    </Pressable>
  );
}
export function Info({ children }: { children: React.ReactNode }) {
  return (
    <View style={s.info}>
      <Icon name="info" size={16} />
      <Txt style={{ flex: 1, color: C.muted, fontSize: 12, lineHeight: 19 }}>
        {children}
      </Txt>
    </View>
  );
}
export function Heading({
  title,
  subtitle,
}: {
  title: string;
  subtitle?: string;
}) {
  return (
    <View style={{ gap: 7, marginVertical: 4 }}>
      <Txt style={{ fontSize: 25, fontWeight: "800", letterSpacing: -0.6 }}>
        {title}
      </Txt>
      {subtitle && (
        <Txt style={{ color: C.muted, lineHeight: 21, fontSize: 13 }}>
          {subtitle}
        </Txt>
      )}
    </View>
  );
}
export function Empty({
  title,
  body,
  icon = "flag",
}: {
  title: string;
  body?: string;
  icon?: React.ComponentProps<typeof Feather>["name"];
}) {
  return (
    <View style={{ alignItems: "center", paddingVertical: 32, gap: 14 }}>
      <View
        style={{
          backgroundColor: C.mint,
          width: 58,
          height: 58,
          borderRadius: 20,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Icon name={icon} size={25} />
      </View>
      <Txt style={{ fontWeight: "700", textAlign: "center", fontSize: 17 }}>
        {title}
      </Txt>
      {body && (
        <Txt
          style={{
            color: C.muted,
            fontSize: 13,
            lineHeight: 21,
            textAlign: "center",
          }}
        >
          {body}
        </Txt>
      )}
    </View>
  );
}
export const s = StyleSheet.create({
  text: { color: C.ink, fontSize: 14, lineHeight: 21 },
  row: { flexDirection: "row", alignItems: "center", gap: 10 },
  card: {
    padding: 18,
    backgroundColor: C.white,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: C.line,
    gap: 14,
  },
  button: {
    minHeight: 50,
    borderRadius: 13,
    paddingHorizontal: 18,
    paddingVertical: 13,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 8,
  },
  input: {
    backgroundColor: C.white,
    color: C.ink,
    fontSize: 16,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 12,
    padding: 14,
    minHeight: 50,
  },
  pill: {
    paddingHorizontal: 14,
    paddingVertical: 11,
    minHeight: 44,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: C.line,
    backgroundColor: C.white,
    justifyContent: "center",
  },
  info: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 9,
    padding: 14,
    backgroundColor: "#EDF2E9",
    borderRadius: 12,
  },
});
