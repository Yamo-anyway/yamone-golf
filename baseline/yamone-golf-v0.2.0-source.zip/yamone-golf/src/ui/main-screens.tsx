import React from "react";
import { View } from "react-native";
import { hasReceipt, personalStats } from "../domain/engine";
import { useApp } from "./context";
import {
  Button,
  Card,
  Row,
  Txt,
  Heading,
  Info,
  Empty,
  C,
  Icon,
} from "./components";
import { RoundCard } from "./round-screens";
import { Invitations } from "./social-screens";
export function Home() {
  const { state, t, go } = useApp();
  const active = state.rounds.find((r) => r.status === "active");
  const stats = personalStats(state);
  return (
    <>
      <View style={{ gap: 6, marginTop: 6 }}>
        <Txt style={{ fontSize: 12, color: C.green2, fontWeight: "600" }}>
          {state.profile!.nickname}
        </Txt>
        <Heading title={t("greeting")} subtitle={t("greetSub")} />
      </View>
      <Card
        style={{
          backgroundColor: C.green,
          borderColor: C.green,
          padding: 22,
          gap: 18,
        }}
      >
        <Row>
          <View style={{ flex: 1 }}>
            <Txt
              style={{
                color: C.lime,
                fontSize: 11,
                fontWeight: "700",
                letterSpacing: 1.8,
              }}
            >
              YOUR NEXT ROUND
            </Txt>
            <Txt
              style={{
                color: C.white,
                fontWeight: "800",
                fontSize: 23,
                lineHeight: 31,
                marginTop: 12,
              }}
            >
              {active ? active.courseName : t("noActive")}
            </Txt>
            <Txt style={{ color: "#BDD0C4", fontSize: 12, marginTop: 8 }}>
              {active
                ? `${active.holes.length} ${t("holes")} · ${active.players.length} ${t("people")}`
                : t("noActiveSub")}
            </Txt>
          </View>
          <Icon name="flag" color={C.lime} size={37} />
        </Row>
        <Button
          testID="new-round"
          label={t(active ? "continue" : "newRound")}
          icon={active ? "edit-3" : "plus"}
          variant="secondary"
          onPress={() =>
            go(active ? { name: "round", id: active.id } : { name: "create" })
          }
        />
      </Card>
      <Row>
        <View style={{ flex: 1 }}>
          <Button
            icon="map-pin"
            variant="outline"
            label={t("courses")}
            onPress={() => go({ name: "courses" })}
          />
        </View>
      </Row>
      <Card>
        <Txt style={{ fontWeight: "700", fontSize: 16 }}>{t("statistic")}</Txt>
        <Row style={{ justifyContent: "space-around" }}>
          {[
            [t("roundCount"), stats.count],
            [t("best"), stats.best ?? "—"],
            [t("average"), stats.average?.toFixed(1) ?? "—"],
          ].map(([label, value]) => (
            <View key={String(label)} style={{ alignItems: "center", gap: 6 }}>
              <Txt style={{ fontSize: 26, fontWeight: "800", lineHeight: 33 }}>
                {value}
              </Txt>
              <Txt style={{ fontSize: 11, color: C.muted }}>{label}</Txt>
            </View>
          ))}
        </Row>
        <Txt style={{ fontSize: 10, color: C.muted, textAlign: "center" }}>
          {t("statsHint")}
        </Txt>
      </Card>
      <Invitations />
    </>
  );
}
export function Rounds() {
  const { state, t, go } = useApp();
  const rounds = state.rounds.filter((r) => !hasReceipt(r, state.profile!.id));
  return (
    <>
      <Heading title={t("rounds")} />
      {!rounds.length && <Empty title={t("empty")} />}
      <Button
        label={t("newRound")}
        disabled={state.rounds.some((r) => r.status === "active")}
        icon="plus"
        onPress={() => go({ name: "create" })}
      />
      {rounds.map((r) => (
        <RoundCard key={r.id} round={r} />
      ))}
      <Button
        label={t("join")}
        variant="outline"
        onPress={() => go({ name: "join" })}
      />
    </>
  );
}
export function Records() {
  const { state, t } = useApp();
  const records = state.rounds.filter((r) => hasReceipt(r, state.profile!.id));
  const stats = personalStats(state);
  return (
    <>
      <Heading title={t("records")} />
      {records.length > 0 && (
        <Card>
          <Row style={{ justifyContent: "space-between" }}>
            <Txt>{t("best")}</Txt>
            <Txt style={{ fontSize: 23, fontWeight: "800" }}>
              {stats.best ?? "—"}
            </Txt>
          </Row>
          <Row style={{ justifyContent: "space-between" }}>
            <Txt>{t("average")}</Txt>
            <Txt style={{ fontWeight: "700" }}>
              {stats.average?.toFixed(1) ?? "—"}
            </Txt>
          </Row>
          <Info>{t("statsHint")}</Info>
        </Card>
      )}
      {!records.length && (
        <Empty
          icon="book-open"
          title={t("noRecords")}
          body={t("noRecordsSub")}
        />
      )}{" "}
      {records.map((r) => (
        <RoundCard key={r.id} round={r} />
      ))}
    </>
  );
}
