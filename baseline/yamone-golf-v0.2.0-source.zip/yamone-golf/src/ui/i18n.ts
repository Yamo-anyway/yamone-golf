import { Language } from "../domain/model";
import * as ko from "./locales/ko";
import * as en from "./locales/en";
export type MessageKey = keyof typeof ko.messages;
export type Translate = (key: MessageKey) => string;
export const resolveLanguage = (
  preference: Language,
  device: string,
): "ko" | "en" =>
  preference === "system"
    ? /^ko(?:-|_|$)/i.test(device)
      ? "ko"
      : "en"
    : preference;
export const translator =
  (lang: "ko" | "en"): Translate =>
  (key) =>
    (lang === "ko" ? ko : en).messages[key];
export const errorText = (code: string, lang: "ko" | "en") =>
  (lang === "ko" ? ko : en).errors[code] ??
  (lang === "ko"
    ? "입력과 라운드 상태를 확인해주세요."
    : "Check your input and round status.");
