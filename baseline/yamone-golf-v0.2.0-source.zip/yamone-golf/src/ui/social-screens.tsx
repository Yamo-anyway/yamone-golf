import React, { useState } from "react";
import { useApp } from "./context";
import { Button, Card, Txt, Heading, Field, Info } from "./components";
export function Invitations() {
  const { state, t, commit, busy, go } = useApp();
  return (
    <>
      {(state.invitations ?? []).map((inv) => (
        <Card key={inv.id}>
          <Txt>{t("invitation")}</Txt>
          <Heading title={inv.courseName} />
          <Button
            label={t("acceptInvite")}
            disabled={busy || state.rounds.some((r) => r.status === "active")}
            onPress={async () => {
              if (await commit({ type: "acceptInvite", invitationId: inv.id }))
                go({ name: "round", id: inv.roundId });
            }}
          />
          <Button
            label={t("cancelInvite")}
            variant="outline"
            disabled={busy}
            onPress={() => {
              void commit({ type: "cancelInvite", invitationId: inv.id });
            }}
          />
        </Card>
      ))}
    </>
  );
}
export function JoinScreen() {
  const { state, t, commit, busy, go } = useApp();
  const [code, setCode] = useState("");
  const active = state.rounds.some((r) => r.status === "active");
  return (
    <>
      <Heading title={t("join")} />
      {active ? (
        <Info>{t("endTitle")}</Info>
      ) : (
        <>
          <Field
            label={t("joinCode")}
            value={code}
            onChangeText={setCode}
            maxLength={32}
          />
          <Button
            label={t("acceptInvite")}
            disabled={busy || !code.trim()}
            onPress={async () => {
              const next = await commit({ type: "join", code });
              const r = next?.rounds.find(
                (r) => r.joinCode === code.trim().toUpperCase(),
              );
              if (r) go({ name: "round", id: r.id });
            }}
          />
        </>
      )}
    </>
  );
}
export function RoundSharing({ id }: { id: string }) {
  const { state, t, commit, busy, toast } = useApp();
  const r = state.rounds.find((r) => r.id === id)!;
  const [code, setCode] = useState("");
  if (r.status !== "active") return null;
  return (
    <Card>
      <Txt>{t("joinCode")}</Txt>
      <Txt selectable style={{ fontWeight: "700" }}>
        {r.joinCode}
      </Txt>
      <Field label={t("personalCode")} value={code} onChangeText={setCode} />
      <Button
        label={t("invite")}
        disabled={busy || !code.trim()}
        onPress={async () => {
          if (
            await commit({ type: "invite", roundId: id, personalCode: code })
          ) {
            setCode("");
            toast(t("saved"));
          }
        }}
      />
      {r.creatorId === state.profile!.id &&
        r.participants
          .filter((p) => p.userId !== r.creatorId)
          .map((p) => (
            <Button
              key={p.userId}
              label={`${t(p.canEnd ? "revokeDelegate" : "delegate")} · ${r.players.find((x) => x.userId === p.userId)?.name ?? p.userId.slice(0, 8)}`}
              variant="outline"
              disabled={busy}
              onPress={() => {
                void commit({
                  type: "delegateEnd",
                  roundId: id,
                  userId: p.userId,
                  enabled: !p.canEnd,
                });
              }}
            />
          ))}
    </Card>
  );
}
export function RecordDeliveries({ id }: { id: string }) {
  const { state, t, commit, busy, confirm } = useApp();
  const r = state.rounds.find((r) => r.id === id)!;
  if (r.status === "active") return null;
  return (
    <>
      <Card>
        <Heading title={t("sendRecord")} />
        {r.players
          .filter((p) => p.userId)
          .map((p) => (
            <Button
              key={p.id}
              label={`${p.name} · ${t("sendRecord")}`}
              disabled={
                busy ||
                (r.deliveries ?? []).some(
                  (d) => d.playerId === p.id && d.status === "pending",
                )
              }
              variant="outline"
              onPress={() => {
                void commit({
                  type: "sendRecord",
                  roundId: id,
                  playerId: p.id,
                });
              }}
            />
          ))}
        {(r.deliveries ?? []).map((d) => (
          <Card key={d.id}>
            <Txt>
              {r.players.find((p) => p.id === d.playerId)?.name} ·{" "}
              {t(d.status === "received" ? "receivedStatus" : d.status)}
            </Txt>
            {d.status === "pending" &&
              (d.userId === state.profile!.id ||
                r.creatorId === state.profile!.id) && (
                <Button
                  compact
                  variant="outline"
                  label={t("cancel")}
                  disabled={busy}
                  onPress={() => {
                    void commit({
                      type: "cancelDelivery",
                      roundId: id,
                      deliveryId: d.id,
                    });
                  }}
                />
              )}
          </Card>
        ))}
      </Card>
      {r.receipts.some(
        (x) => x.userId === state.profile!.id && !x.deletedAt,
      ) && (
        <Button
          label={t("deleteRecord")}
          variant="outline"
          onPress={async () => {
            if (
              await confirm({
                title: t("deleteRecord"),
                body: t("deleteRecordHint"),
                destructive: true,
              })
            )
              await commit({ type: "deleteReceipt", roundId: id });
          }}
        />
      )}
    </>
  );
}
