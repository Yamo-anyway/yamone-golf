import React, { useMemo, useState } from "react";
import { View } from "react-native";
import Svg, { Path, Rect } from "react-native-svg";
import { create } from "qrcode/lib/core/qrcode";
import { api, IdentityResult } from "../data/api";
import { useApp, useDirty } from "./context";
import {
  Button,
  Card,
  Row,
  Txt,
  Field,
  Pill,
  Heading,
  Info,
  C,
  Badge,
} from "./components";
export function PersonalQR({ value }: { value: string }) {
  const matrix = useMemo(
    () => create(value, { errorCorrectionLevel: "M" }).modules,
    [value],
  );
  let path = "";
  for (let y = 0; y < matrix.size; y++)
    for (let x = 0; x < matrix.size; x++)
      if (matrix.get(y, x)) path += `M${x + 4} ${y + 4}h1v1h-1z`;
  return (
    <Svg
      accessibilityLabel="Personal QR"
      width={200}
      height={200}
      viewBox={`0 0 ${matrix.size + 8} ${matrix.size + 8}`}
    >
      <Rect width="100%" height="100%" fill="white" />
      <Path d={path} fill="#173F34" />
    </Svg>
  );
}
export function Welcome() {
  const { t, busy, action, refresh, showKey, lang } = useApp();
  const [mode, setMode] = useState<"new" | "transfer" | "email" | "key">("new"),
    [name, setName] = useState(""),
    [email, setEmail] = useState(""),
    [code, setCode] = useState(""),
    [key, setKey] = useState(""),
    [sent, setSent] = useState(false),
    [grant, setGrant] = useState(""),
    [accounts, setAccounts] = useState<
      { id: string; nickname: string; personal_code: string }[]
    >([]);
  const finish = async (fn: () => Promise<IdentityResult>) => {
    const result = await action(async () => {
      const r = await fn();
      await refresh();
      return r;
    });
    if (result?.recoveryKey) showKey(result.recoveryKey);
  };
  return (
    <>
      <Heading title={t("welcome")} subtitle={t("intro")} />
      <Row style={{ flexWrap: "wrap" }}>
        <Pill
          label={t("fresh")}
          selected={mode === "new"}
          onPress={() => setMode("new")}
        />
        <Pill
          label={t("restore")}
          selected={mode !== "new"}
          onPress={() => setMode("transfer")}
        />
      </Row>
      {mode === "new" ? (
        <>
          <Info>{t("localNote")}</Info>
          <Field
            testID="nickname"
            label={t("nickname")}
            value={name}
            onChangeText={setName}
            maxLength={16}
          />
          <Button
            testID="begin"
            label={t("begin")}
            disabled={busy || !name.trim()}
            onPress={() => {
              void finish(() => api.register(name, "system"));
            }}
          />
        </>
      ) : (
        <>
          <Row style={{ flexWrap: "wrap" }}>
            {(["transfer", "email", "key"] as const).map((m) => (
              <Pill
                key={m}
                label={t(
                  m === "transfer"
                    ? "transfer"
                    : m === "email"
                      ? "recoveryEmail"
                      : "recoveryKey",
                )}
                selected={mode === m}
                onPress={() => {
                  setMode(m);
                  setCode("");
                  setSent(false);
                  setGrant("");
                  setAccounts([]);
                }}
              />
            ))}
          </Row>
          {mode === "key" ? (
            <>
              <Field
                testID="recovery-key"
                label={t("recoveryKey")}
                value={key}
                onChangeText={setKey}
                maxLength={120}
              />
              <Button
                label={t("recover")}
                disabled={busy || !key.trim()}
                onPress={() => {
                  void finish(() => api.claim("recovery/key/claim", { key }));
                }}
              />
            </>
          ) : (
            <>
              <Field
                testID="recovery-email"
                label={t("email")}
                value={email}
                onChangeText={(v) => {
                  setEmail(v);
                  setGrant("");
                  setAccounts([]);
                  setSent(false);
                }}
                maxLength={254}
              />
              {mode === "email" && !grant && (
                <Button
                  label={t("sendCode")}
                  disabled={busy || !email.trim()}
                  onPress={async () => {
                    if (
                      await action(() =>
                        api.request("recovery/email/request", {
                          email,
                          language: lang,
                        }),
                      )
                    )
                      setSent(true);
                  }}
                />
              )}
              {sent && <Info>{t("recoverySent")}</Info>}
              {!grant && (
                <Field
                  testID="recovery-code"
                  label={t(mode === "transfer" ? "transferCode" : "code")}
                  value={code}
                  onChangeText={setCode}
                  maxLength={100}
                />
              )}
              {!grant && (
                <Button
                  label={t(mode === "transfer" ? "restore" : "verify")}
                  disabled={busy || !email.trim() || !code.trim()}
                  onPress={async () => {
                    if (mode === "transfer") {
                      await finish(() =>
                        api.claim("transfer/claim", { email, code }),
                      );
                      return;
                    }
                    const r = await action(() =>
                      api.request<{ grant: string; accounts: typeof accounts }>(
                        "recovery/email/verify",
                        { email, code },
                      ),
                    );
                    if (r) {
                      setGrant(r.grant);
                      setAccounts(r.accounts);
                    }
                  }}
                />
              )}
              {!!grant && (
                <>
                  <Heading title={t("pickAccount")} />
                  {accounts.map((a) => (
                    <Card key={a.id}>
                      <Txt style={{ fontWeight: "700" }}>{a.nickname}</Txt>
                      <Txt>{a.personal_code}</Txt>
                      <Button
                        label={t("recover")}
                        disabled={busy}
                        onPress={() => {
                          void finish(() =>
                            api.claim("recovery/email/claim", {
                              email,
                              grant,
                              userId: a.id,
                            }),
                          );
                        }}
                      />
                    </Card>
                  ))}
                </>
              )}
            </>
          )}
          <Info>{t("noRecovery")}</Info>
        </>
      )}
    </>
  );
}
export function ProfileScreen() {
  const { state, t, commit, busy, toast, go, action, showKey, confirm } =
    useApp();
  const p = state.profile!;
  const [name, setName] = useState(p.nickname);
  const save = async () => {
    const result = await commit({
      type: "profile",
      profile: { ...p, nickname: name },
    });
    if (result) {
      toast(t("saved"));
      return true;
    }
    return false;
  };
  useDirty(name.trim() !== p.nickname, save);
  return (
    <>
      <Heading title={t("profile")} />
      <Card>
        <Field
          label={t("nickname")}
          value={name}
          onChangeText={setName}
          maxLength={16}
        />
        <Button
          label={t("save")}
          disabled={busy || !name.trim() || name.trim() === p.nickname}
          onPress={() => {
            void save();
          }}
        />
      </Card>
      <Card>
        <Txt style={{ fontWeight: "700" }}>{t("personalCode")}</Txt>
        <Txt
          selectable
          style={{ fontSize: 23, fontWeight: "800", letterSpacing: 1 }}
        >
          {p.personalCode}
        </Txt>
        {p.personalQr && (
          <View style={{ alignItems: "center" }}>
            <PersonalQR value={p.personalQr} />
          </View>
        )}
        <Txt style={{ fontSize: 11, color: C.muted }}>{t("userId")}</Txt>
        <Txt selectable style={{ fontSize: 11 }}>
          {p.id}
        </Txt>
      </Card>
      <Button label={t("transfer")} onPress={() => go({ name: "transfer" })} />
      <Button
        label={t("recoveryEmail")}
        variant="outline"
        onPress={() => go({ name: "recovery-email" })}
      />
      <Button
        label={t("newKey")}
        variant="outline"
        onPress={async () => {
          if (!(await confirm({ title: t("newKey"), body: t("newKeyHint") })))
            return;
          const result = await action(() =>
            api.request<{ recoveryKey: string }>("recovery/key/rotate", {}),
          );
          if (result) showKey(result.recoveryKey);
        }}
        disabled={busy}
      />
      <Card>
        <Txt style={{ fontWeight: "700" }}>{t("language")}</Txt>
        <Row style={{ flexWrap: "wrap" }}>
          {(["system", "ko", "en"] as const).map((l) => (
            <Pill
              key={l}
              label={t(
                l === "system" ? "system" : l === "ko" ? "korean" : "english",
              )}
              selected={p.language === l}
              onPress={() => {
                void commit({
                  type: "profile",
                  profile: { ...p, language: l },
                });
              }}
            />
          ))}
        </Row>
        <Info>{t("languageHint")}</Info>
      </Card>
      <Button
        label={t("courses")}
        variant="outline"
        onPress={() => go({ name: "courses" })}
      />
    </>
  );
}
export function TransferScreen() {
  const { t, busy, action, lang } = useApp();
  const [email, setEmail] = useState(""),
    [days, setDays] = useState<1 | 3 | 5>(3),
    [expiry, setExpiry] = useState<number | null>(null);
  return (
    <>
      <Heading title={t("transfer")} />
      <Info>{t("transferHint")}</Info>
      <Field
        label={t("email")}
        value={email}
        onChangeText={setEmail}
        maxLength={254}
      />
      <Txt>{t("expires")}</Txt>
      <Row>
        {([1, 3, 5] as const).map((d) => (
          <Pill
            key={d}
            label={`${d} ${t("day")}`}
            selected={days === d}
            onPress={() => setDays(d)}
          />
        ))}
      </Row>
      <Button
        label={t("sendCode")}
        disabled={busy || !email.trim()}
        onPress={async () => {
          setExpiry(null);
          const r = await action(() =>
            api.request<{ expiresAt: number }>("transfer/issue", {
              email,
              days,
              language: lang,
            }),
          );
          if (r) setExpiry(r.expiresAt);
        }}
      />
      {expiry && (
        <Info>{t("mailSent") + "\n" + new Date(expiry).toLocaleString()}</Info>
      )}
    </>
  );
}
export function RecoveryEmailScreen() {
  const { state, t, busy, action, refresh, lang } = useApp();
  const [email, setEmail] = useState(state.profile?.recoveryEmail ?? ""),
    [code, setCode] = useState(""),
    [sent, setSent] = useState(false);
  return (
    <>
      <Heading title={t("recoveryEmail")} />
      {state.profile?.recoveryEmail && (
        <Card>
          <Badge>{t("verified")}</Badge>
          <Txt>{state.profile.recoveryEmail}</Txt>
        </Card>
      )}
      <Field
        label={t("email")}
        value={email}
        onChangeText={(v) => {
          setEmail(v);
          setSent(false);
        }}
        maxLength={254}
      />
      <Button
        label={t("sendCode")}
        disabled={busy || !email.trim()}
        onPress={async () => {
          if (
            await action(() =>
              api.request("recovery/email/register/request", {
                email,
                language: lang,
              }),
            )
          )
            setSent(true);
        }}
      />
      {sent && (
        <>
          <Info>{t("mailSent")}</Info>
          <Field label={t("code")} value={code} onChangeText={setCode} />
          <Button
            label={t("verify")}
            disabled={busy || !code.trim()}
            onPress={async () => {
              if (
                await action(() =>
                  api.request("recovery/email/register/verify", {
                    email,
                    code,
                  }),
                )
              ) {
                setSent(false);
                await refresh();
              }
            }}
          />
        </>
      )}
    </>
  );
}
