import React, { useMemo, useState } from "react";
import { View, PanResponder } from "react-native";
import { Icon, C } from "./components";
export function DragHandle({
  onDrop,
  testID,
  disabled = false,
}: {
  onDrop: (distance: number) => void;
  testID?: string;
  disabled?: boolean;
}) {
  const [dragging, setDragging] = useState(false);
  const responder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => !disabled,
        onPanResponderGrant: () => setDragging(true),
        onPanResponderRelease: (_, gesture) => {
          setDragging(false);
          onDrop(gesture.dy);
        },
        onPanResponderTerminate: () => setDragging(false),
        onPanResponderTerminationRequest: () => false,
      }),
    [onDrop, disabled],
  );
  return (
    <View
      testID={testID}
      {...responder.panHandlers}
      style={{
        padding: 12,
        backgroundColor: dragging ? C.mint : C.paper,
        borderRadius: 10,
        opacity: disabled ? 0.4 : 1,
      }}
    >
      <Icon name="menu" size={18} />
    </View>
  );
}
export function moveByDistance(
  ids: string[],
  id: string,
  dy: number,
  positions: Record<string, { y: number; height: number }>,
) {
  const from = ids.indexOf(id),
    start = positions[id];
  if (from < 0 || !start || Math.abs(dy) < 10) return ids;
  const center = start.y + start.height / 2 + dy;
  let to = from,
    best = Infinity;
  ids.forEach((other, i) => {
    const pos = positions[other];
    if (!pos) return;
    const distance = Math.abs(pos.y + pos.height / 2 - center);
    if (distance < best) {
      best = distance;
      to = i;
    }
  });
  const next = [...ids];
  next.splice(from, 1);
  next.splice(to, 0, id);
  return next;
}
