import React from "react";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { TransferScreen } from "../ui/identity-screens";
export default function Route() {
  const { state } = useApp();
  return <Screen name="transfer">{state.session && <TransferScreen />}</Screen>;
}
