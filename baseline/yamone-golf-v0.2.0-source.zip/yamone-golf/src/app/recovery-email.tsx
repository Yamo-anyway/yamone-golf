import React from "react";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { RecoveryEmailScreen } from "../ui/identity-screens";
export default function Route() {
  const { state } = useApp();
  return (
    <Screen name="recovery-email">
      {state.session && <RecoveryEmailScreen />}
    </Screen>
  );
}
