import React from "react";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { CreateRoundScreen } from "../ui/setup-screens";
export default function Route() {
  const { state } = useApp();
  return (
    <Screen name="create">{state.session && <CreateRoundScreen />}</Screen>
  );
}
