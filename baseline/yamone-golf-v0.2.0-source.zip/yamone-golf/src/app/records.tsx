import React from "react";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { Records } from "../ui/main-screens";
export default function Route() {
  const { state } = useApp();
  return <Screen name="records">{state.session && <Records />}</Screen>;
}
