import React from "react";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { ProfileScreen } from "../ui/identity-screens";
export default function Route() {
  const { state } = useApp();
  return <Screen name="profile">{state.session && <ProfileScreen />}</Screen>;
}
