import React from "react";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { JoinScreen } from "../ui/social-screens";
export default function Route() {
  const { state } = useApp();
  return <Screen name="join">{state.session && <JoinScreen />}</Screen>;
}
