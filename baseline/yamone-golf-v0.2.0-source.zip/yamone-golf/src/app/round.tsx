import React from "react";
import { useLocalSearchParams } from "expo-router";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { RoundScreen } from "../ui/round-screens";
export default function Route() {
  const { state } = useApp();
  const { id } = useLocalSearchParams<{ id: string }>();
  return (
    <Screen name="round">
      {state.session && id && state.rounds.some((r) => r.id === id) && (
        <RoundScreen key={id} id={id} />
      )}
    </Screen>
  );
}
