import React from "react";
import { useLocalSearchParams } from "expo-router";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { CourseEditor } from "../ui/setup-screens";
export default function Route() {
  const { state } = useApp();
  const { id } = useLocalSearchParams<{ id: string }>();
  return (
    <Screen name="course">
      {state.session && <CourseEditor key={id} id={id} />}
    </Screen>
  );
}
