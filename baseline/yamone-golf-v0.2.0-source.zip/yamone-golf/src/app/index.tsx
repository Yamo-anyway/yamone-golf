import React from "react";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { Home } from "../ui/main-screens";
export default function Route() {
  const { state } = useApp();
  return <Screen name="home">{state.session && <Home />}</Screen>;
}
