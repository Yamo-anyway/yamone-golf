import React from "react";
import { useLocalSearchParams } from "expo-router";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { ScorecardScreen } from "../ui/round-screens";
export default function Route() {
  const { state } = useApp();
  const { id } = useLocalSearchParams<{ id: string }>();
  return (
    <Screen name="scorecard">
      {state.session && id && state.rounds.some((r) => r.id === id) && (
        <ScorecardScreen key={id} id={id} />
      )}
    </Screen>
  );
}
