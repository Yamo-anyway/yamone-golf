import React from "react";
import { useLocalSearchParams } from "expo-router";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { ScoreScreen } from "../ui/round-screens";
export default function Route() {
  const { state } = useApp();
  const { id } = useLocalSearchParams<{ id: string }>();
  return (
    <Screen name="score">
      {state.session && id && state.rounds.some((r) => r.id === id) && (
        <ScoreScreen key={id} id={id} />
      )}
    </Screen>
  );
}
