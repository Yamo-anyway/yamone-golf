import React from "react";
import { Screen } from "../ui/screen";
import { useApp } from "../ui/context";
import { Rounds } from "../ui/main-screens";
export default function Route() {
  const { state } = useApp();
  return <Screen name="rounds">{state.session && <Rounds />}</Screen>;
}
