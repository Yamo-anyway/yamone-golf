export type Language = "system" | "ko" | "en";
export type Par = 3 | 4 | 5 | 6 | 7;
export type Profile = {
  id: string;
  nickname: string;
  language: Language;
  personalCode?: string;
  personalQr?: string;
  createdAt?: number;
  recoveryEmail?: string | null;
};
export type Segment = { id: string; name: string; pars: Par[] };
export type Course = {
  id: string;
  name: string;
  location: string;
  segments: Segment[];
  updatedAt: number;
};
export type Score = { value: number | null; version: number };
export type Player = {
  id: string;
  name: string;
  userId: string | null;
  scores: Score[];
};
export type Hole = {
  number: number;
  sourceSegmentId: string;
  sourceHole: number;
  segmentName: string;
  par: Par;
};
export type Participant = {
  userId: string;
  canEnd: boolean;
  targets: string[];
};
export type Audit = {
  playerId: string;
  hole: number;
  before: number | null;
  after: number | null;
  actorId: string;
  at: number;
  version: number;
};
export type Round = {
  id: string;
  courseId: string;
  courseName: string;
  location: string;
  holes: Hole[];
  creatorId: string;
  participants: Participant[];
  players: Player[];
  status: "active" | "complete" | "incomplete";
  createdAt: number;
  lastActivityAt: number;
  endedAt: number | null;
  autoEnded: boolean;
  receipts: { userId: string; receivedAt: number; deletedAt?: number | null }[];
  joinCode?: string;
  deliveries?: {
    id: string;
    playerId: string;
    userId: string;
    status: "pending" | "received" | "cancelled";
    createdAt: number;
  }[];
  audit: Audit[];
};
export type State = {
  schemaVersion: 1;
  profile: Profile | null;
  session: boolean;
  courses: Course[];
  rounds: Round[];
  invitations?: { id: string; roundId: string; courseName: string }[];
};
export type ScoreChange = {
  playerId: string;
  hole: number;
  value: number | null;
  expectedVersion: number;
};
export type Command =
  | { type: "profile"; profile: Profile }
  | { type: "session"; active: boolean }
  | { type: "course"; course: Omit<Course, "updatedAt"> }
  | {
      type: "create";
      id: string;
      courseId: string;
      segmentIds: string[];
      players: { id: string; name: string; self: boolean }[];
    }
  | { type: "targets"; roundId: string; targets: string[] }
  | { type: "addPlayer"; roundId: string; id: string; name: string }
  | { type: "renamePlayer"; roundId: string; playerId: string; name: string }
  | { type: "linkSelf"; roundId: string; playerId: string }
  | { type: "scores"; roundId: string; changes: ScoreChange[] }
  | { type: "end"; roundId: string }
  | { type: "receive"; roundId: string }
  | { type: "join"; code: string }
  | { type: "invite"; roundId: string; personalCode: string }
  | { type: "acceptInvite" | "cancelInvite"; invitationId: string }
  | { type: "courseOrder"; ids: string[] }
  | { type: "removeCourse"; courseId: string }
  | { type: "unlinkPlayer"; roundId: string; playerId: string; name: string }
  | { type: "deletePlayer"; roundId: string; playerId: string }
  | { type: "delegateEnd"; roundId: string; userId: string; enabled: boolean }
  | { type: "sendRecord"; roundId: string; playerId: string }
  | { type: "cancelDelivery"; roundId: string; deliveryId: string }
  | { type: "deleteReceipt"; roundId: string }
  | { type: "tick" };
export const EMPTY_STATE: State = {
  schemaVersion: 1,
  profile: null,
  session: false,
  courses: [],
  rounds: [],
};
export const SIX_HOURS = 6 * 60 * 60 * 1000;
export const DAY = 24 * 60 * 60 * 1000;
