import {
  Command,
  DAY,
  Hole,
  Player,
  Round,
  ScoreChange,
  SIX_HOURS,
  State,
} from "./model";

export class RuleError extends Error {
  constructor(
    public code: string,
    public details?: unknown,
  ) {
    super(code);
    this.name = "RuleError";
  }
}
function requireRule(condition: unknown, code: string): asserts condition {
  if (!condition) throw new RuleError(code);
}
const validName = (s: string, max = 32) =>
  s.trim().length > 0 && [...s.trim()].length <= max;
export const complete = (p: Player) => p.scores.every((s) => s.value !== null);
export const hasReceipt = (r: Round, userId: string) =>
  r.receipts.some((x) => x.userId === userId && !x.deletedAt);
export const isLocked = (r: Round, now: number) =>
  r.endedAt !== null && now >= r.endedAt + DAY;
export function scoreSummary(p: Player, r: Round) {
  let strokes = 0,
    par = 0,
    played = 0;
  p.scores.forEach((s, i) => {
    if (s.value !== null) {
      strokes += s.value;
      par += r.holes[i].par;
      played++;
    }
  });
  return { strokes, par, played, relative: strokes - par };
}
export function editable(
  r: Round,
  userId: string,
  p: Player,
  now: number,
): boolean {
  if (r.status === "active")
    return r.participants.some(
      (x) => x.userId === userId && x.targets.includes(p.id),
    );
  return p.userId === userId && hasReceipt(r, userId) && !isLocked(r, now);
}
export function expireRounds(state: State, now: number): State {
  let changed = false;
  const rounds = state.rounds.map((r) => {
    if (r.status !== "active" || now < r.lastActivityAt + SIX_HOURS) return r;
    changed = true;
    return {
      ...r,
      status: r.players.every(complete)
        ? ("complete" as const)
        : ("incomplete" as const),
      endedAt: r.lastActivityAt + SIX_HOURS,
      autoEnded: true,
    };
  });
  return changed ? { ...state, rounds } : state;
}
export function personalStats(state: State) {
  const userId = state.profile?.id;
  const entries = state.rounds.flatMap((r) => {
    if (
      !userId ||
      r.status === "active" ||
      r.holes.length !== 18 ||
      !hasReceipt(r, userId)
    )
      return [];
    const p = r.players.find((x) => x.userId === userId);
    return p && complete(p)
      ? [{ round: r, player: p, ...scoreSummary(p, r) }]
      : [];
  });
  return {
    count: entries.length,
    best: entries.length ? Math.min(...entries.map((e) => e.strokes)) : null,
    average: entries.length
      ? entries.reduce((s, e) => s + e.strokes, 0) / entries.length
      : null,
    entries,
  };
}

export function applyCommand(
  input: State,
  command: Command,
  now: number,
): State {
  const current = expireRounds(input, now);
  if (command.type === "tick") return current;
  if (command.type === "profile") {
    requireRule(validName(command.profile.nickname, 16), "name");
    requireRule(
      ["system", "ko", "en"].includes(command.profile.language),
      "invalid",
    );
    requireRule(
      !current.profile || current.profile.id === command.profile.id,
      "identity",
    );
    const profile = {
      ...command.profile,
      nickname: command.profile.nickname.trim(),
    };
    return {
      ...current,
      profile,
      session: true,
      rounds: current.rounds.map((r) => {
        if (
          !r.players.some(
            (p) => p.userId === profile.id && p.name !== profile.nickname,
          )
        )
          return r;
        return {
          ...r,
          lastActivityAt: r.status === "active" ? now : r.lastActivityAt,
          players: r.players.map((p) =>
            p.userId === profile.id ? { ...p, name: profile.nickname } : p,
          ),
        };
      }),
    };
  }
  if (command.type === "session") {
    requireRule(current.profile, "profile");
    return { ...current, session: command.active };
  }
  requireRule(current.profile && current.session, "profile");
  const actor = current.profile.id;
  if (command.type === "course") {
    const c = command.course;
    requireRule(validName(c.name, 80) && c.location.length <= 120, "name");
    requireRule(c.segments.length >= 1 && c.segments.length <= 9, "segments");
    requireRule(
      new Set(c.segments.map((s) => s.id)).size === c.segments.length,
      "invalid",
    );
    requireRule(
      c.segments.every(
        (s) =>
          validName(s.name) &&
          s.pars.length === 9 &&
          s.pars.every((p) => [3, 4, 5, 6, 7].includes(p)),
      ),
      "par",
    );
    const course = { ...c, name: c.name.trim(), updatedAt: now };
    return {
      ...current,
      courses: [...current.courses.filter((x) => x.id !== c.id), course],
    };
  }
  if (command.type === "create") {
    requireRule(
      !current.rounds.some(
        (r) =>
          r.status === "active" &&
          r.participants.some((p) => p.userId === actor),
      ),
      "active",
    );
    requireRule(!current.rounds.some((r) => r.id === command.id), "duplicate");
    const course = current.courses.find((c) => c.id === command.courseId);
    requireRule(course, "course");
    requireRule(
      command.segmentIds.length === 1 || command.segmentIds.length === 2,
      "segments",
    );
    requireRule(
      command.players.length >= 1 && command.players.length <= 8,
      "players",
    );
    requireRule(command.players.filter((p) => p.self).length <= 1, "duplicate");
    requireRule(
      new Set(command.players.map((p) => p.id)).size === command.players.length,
      "duplicate",
    );
    requireRule(
      command.players.every((p) => validName(p.name)),
      "name",
    );
    const holes: Hole[] = command.segmentIds.flatMap((id, index) => {
      const segment = course.segments.find((s) => s.id === id);
      requireRule(segment, "segments");
      return segment.pars.map((par, i) => ({
        number: index * 9 + i + 1,
        sourceSegmentId: id,
        sourceHole: i + 1,
        segmentName: segment.name,
        par,
      }));
    });
    const players: Player[] = command.players.map((p) => ({
      id: p.id,
      name: p.self ? current.profile!.nickname : p.name.trim(),
      userId: p.self ? actor : null,
      scores: holes.map(() => ({ value: null, version: 0 })),
    }));
    const round: Round = {
      id: command.id,
      courseId: course.id,
      courseName: course.name,
      location: course.location,
      holes,
      players,
      creatorId: actor,
      participants: [
        { userId: actor, canEnd: true, targets: players.map((p) => p.id) },
      ],
      status: "active",
      createdAt: now,
      lastActivityAt: now,
      endedAt: null,
      autoEnded: false,
      receipts: [],
      audit: [],
    };
    return { ...current, rounds: [round, ...current.rounds] };
  }
  if (command.type === "courseOrder") {
    requireRule(
      command.ids.length === current.courses.length &&
        new Set(command.ids).size === command.ids.length,
      "invalid",
    );
    requireRule(
      command.ids.every((id) => current.courses.some((c) => c.id === id)),
      "course",
    );
    return {
      ...current,
      courses: command.ids.map((id) =>
        current.courses.find((c) => c.id === id)!,
      ),
    };
  }
  if (command.type === "removeCourse")
    return {
      ...current,
      courses: current.courses.filter((c) => c.id !== command.courseId),
    };
  if (["join", "invite", "acceptInvite", "cancelInvite"].includes(command.type))
    throw new RuleError("serverRequired");
  if (!("roundId" in command)) throw new RuleError("invalid");
  const source = current.rounds.find((r) => r.id === command.roundId);
  requireRule(source, "round");
  const r: Round = JSON.parse(JSON.stringify(source));
  const participant = r.participants.find((p) => p.userId === actor);
  requireRule(participant, "permission");
  if (command.type === "targets") {
    requireRule(r.status === "active", "ended");
    requireRule(
      command.targets.every((id) => r.players.some((p) => p.id === id)),
      "player",
    );
    requireRule(
      new Set(command.targets).size === command.targets.length,
      "duplicate",
    );
    participant.targets = [...command.targets];
  } else if (command.type === "addPlayer") {
    requireRule(r.status === "active", "ended");
    requireRule(r.players.length < 8, "players");
    requireRule(validName(command.name), "name");
    requireRule(!r.players.some((p) => p.id === command.id), "duplicate");
    r.players.push({
      id: command.id,
      name: command.name.trim(),
      userId: null,
      scores: r.holes.map(() => ({ value: null, version: 0 })),
    });
    participant.targets.push(command.id);
  } else if (command.type === "renamePlayer") {
    const p = r.players.find((p) => p.id === command.playerId);
    requireRule(p && !p.userId, "permission");
    requireRule(validName(command.name), "name");
    if (p.name === command.name.trim()) return current;
    p.name = command.name.trim();
  } else if (command.type === "linkSelf") {
    requireRule(r.status === "active", "ended");
    const p = r.players.find((p) => p.id === command.playerId);
    requireRule(p && !p.userId, "player");
    requireRule(!r.players.some((p) => p.userId === actor), "duplicate");
    p.userId = actor;
    p.name = current.profile.nickname;
  } else if (command.type === "unlinkPlayer") {
    requireRule(r.status === "active", "ended");
    const p = r.players.find((p) => p.id === command.playerId);
    requireRule(
      p && (p.userId === actor || r.creatorId === actor),
      "permission",
    );
    requireRule(validName(command.name), "name");
    requireRule(
      !r.receipts.length &&
        !(r.deliveries ?? []).some((d) => d.playerId === p.id),
      "impact",
    );
    p.userId = null;
    p.name = command.name.trim();
  } else if (command.type === "deletePlayer") {
    const p = r.players.find((p) => p.id === command.playerId);
    requireRule(p && r.status === "active", "player");
    requireRule(
      !p.userId &&
        p.scores.every((s) => s.value === null) &&
        !(r.deliveries ?? []).some((d) => d.playerId === p.id) &&
        !r.receipts.length,
      "impact",
    );
    requireRule(r.players.length > 1, "players");
    r.players = r.players.filter((x) => x.id !== p.id);
    r.participants.forEach((x) => {
      x.targets = x.targets.filter((id) => id !== p.id);
    });
  } else if (command.type === "delegateEnd") {
    requireRule(r.creatorId === actor && r.status === "active", "permission");
    const target = r.participants.find((p) => p.userId === command.userId);
    requireRule(target && target.userId !== r.creatorId, "permission");
    target.canEnd = command.enabled;
  } else if (command.type === "sendRecord") {
    requireRule(r.status !== "active", "notEnded");
    const p = r.players.find((p) => p.id === command.playerId);
    requireRule(p?.userId, "notPlayer");
    r.deliveries ??= [];
    requireRule(
      !r.deliveries.some((d) => d.playerId === p.id && d.status === "pending"),
      "duplicate",
    );
    // Server replaces this placeholder with a unique delivery id before persistence.
    r.deliveries.push({
      id: `pending:${p.id}:${now}`,
      playerId: p.id,
      userId: p.userId,
      status: "pending",
      createdAt: now,
    });
  } else if (command.type === "cancelDelivery") {
    const delivery = r.deliveries?.find((d) => d.id === command.deliveryId);
    requireRule(delivery && delivery.status === "pending", "invalid");
    requireRule(
      actor === r.creatorId || actor === delivery.userId,
      "permission",
    );
    delivery.status = "cancelled";
  } else if (command.type === "deleteReceipt") {
    const receipt = r.receipts.find((x) => x.userId === actor);
    requireRule(receipt, "invalid");
    receipt.deletedAt = now;
  } else if (command.type === "scores") {
    requireRule(command.changes.length > 0, "invalid");
    requireRule(
      new Set(command.changes.map((c) => `${c.playerId}:${c.hole}`)).size ===
        command.changes.length,
      "duplicate",
    );
    // Validate every cell before committing any cell; an entire hole saves atomically.
    const conflicts: {
      change: ScoreChange;
      current: number | null;
      version: number;
    }[] = [];
    for (const change of command.changes) {
      const p = r.players.find((p) => p.id === change.playerId);
      requireRule(p, "player");
      requireRule(
        editable(r, actor, p, now),
        isLocked(r, now) ? "locked" : "permission",
      );
      requireRule(
        Number.isInteger(change.hole) &&
          change.hole >= 0 &&
          change.hole < r.holes.length,
        "hole",
      );
      requireRule(
        change.value === null ||
          (Number.isInteger(change.value) &&
            change.value >= 1 &&
            change.value <= 99),
        "score",
      );
      const stored = p.scores[change.hole];
      if (
        stored.value !== change.value &&
        stored.version !== change.expectedVersion
      )
        conflicts.push({
          change,
          current: stored.value,
          version: stored.version,
        });
    }
    if (conflicts.length) throw new RuleError("conflict", conflicts);
    let changed = false;
    for (const c of command.changes) {
      const p = r.players.find((p) => p.id === c.playerId)!;
      const old = p.scores[c.hole];
      if (old.value === c.value) continue;
      changed = true;
      p.scores[c.hole] = { value: c.value, version: old.version + 1 };
      r.audit.push({
        playerId: p.id,
        hole: c.hole,
        before: old.value,
        after: c.value,
        actorId: actor,
        at: now,
        version: old.version + 1,
      });
    }
    if (!changed) return current;
  } else if (command.type === "end") {
    requireRule(r.status === "active", "ended");
    requireRule(participant.canEnd, "permission");
    r.status = r.players.every(complete) ? "complete" : "incomplete";
    r.endedAt = now;
  } else if (command.type === "receive") {
    requireRule(r.status !== "active", "notEnded");
    requireRule(
      r.players.some((p) => p.userId === actor),
      "notPlayer",
    );
    const old = r.receipts.find((x) => x.userId === actor);
    const delivery = r.deliveries?.find(
      (x) => x.userId === actor && x.status === "pending",
    );
    if (hasReceipt(r, actor) && !delivery) return current;
    requireRule(!old || delivery, "noDelivery");
    if (old) {
      old.receivedAt = now;
      old.deletedAt = null;
    } else r.receipts.push({ userId: actor, receivedAt: now });
    r.deliveries
      ?.filter((x) => x.userId === actor && x.status === "pending")
      .forEach((x) => {
        x.status = "received";
      });
  }
  if (r.status === "active" && command.type !== "targets")
    r.lastActivityAt = now;
  if (r.status !== "active" && command.type === "scores")
    r.status = r.players.every(complete) ? "complete" : "incomplete";
  return {
    ...current,
    rounds: current.rounds.map((x) => (x.id === r.id ? r : x)),
  };
}
