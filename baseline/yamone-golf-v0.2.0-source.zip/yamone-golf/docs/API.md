# API와 데이터 구조

인증된 API는 native의 `Authorization: Bearer <기기 비밀값>` 또는 web의 HttpOnly 쿠키를 사용한다. 사용자가 직접 user_id를 입력하여 로그인하는 API는 없다. 모든 변경은 POST JSON이며 서버 시각으로 판단한다.

## 주요 경로

| 경로 | 역할 |
|---|---|
| POST /api/users | nickname, language, secret으로 서버 사용자 생성. secret은 기기가 먼저 안전하게 보관한 난수. UUID·개인 코드·복구 키는 서버 생성 |
| GET /api/state | 현재 사용자와 그 사용자가 참여한 라운드/개인 골프장/홈 초대, 서버 시각 |
| POST /api/command | 골프장·라운드·대상·스코어·초대·수신 등 검증된 명령 |
| POST /api/transfer/issue | 인증된 기기에서 email, days(1/3/5)로 이전권 발급 |
| POST /api/transfer/claim | email, code, 새 secret으로 동일 사용자 활성 기기 교체 |
| POST /api/recovery/email/register/request | 인증된 사용자 복구 이메일 확인 OTP 발송 |
| POST /api/recovery/email/register/verify | email, code 검증 후 복구 이메일 등록 |
| POST /api/recovery/email/request | 사전 등록 주소에만 복구 OTP 발송, 계정 존재 여부는 응답으로 공개하지 않음 |
| POST /api/recovery/email/verify | 이메일 소유 증명 후 grant와 복구 가능 사용자 목록 반환 |
| POST /api/recovery/email/claim | email, grant, userId, 새 secret으로 복구 |
| POST /api/recovery/key/claim | key, 새 secret으로 복구 후 새 복구 키 반환 |
| POST /api/recovery/key/rotate | 활성 기기의 기존 복구 키 교체 |
| POST /api/device/reset | 이 클라이언트의 쿠키 제거. 사용자·기록 삭제가 아님 |

`server/validation.ts`가 실제 요청 스키마다. 요청의 임의 필드는 권한을 만들지 않는다. profile 명령의 id가 달라도 인증된 사용자 ID로 고정하며 개인 코드/복구 이메일 등의 서버 필드는 클라이언트 변경값을 받지 않는다.

## 관계

| 개념 | 저장 관계 |
|---|---|
| USER | users, devices, recovery_keys, recovery_emails, tickets, device_events |
| ROUND | rounds(홀·골프장 snapshot·상태·시각 등 메타데이터), round_codes |
| ROUND PARTICIPANT | round_participants, participant_rights |
| PLAYER SLOT | player_slots |
| INPUT TARGET | input_targets(user_id + round_id + player_id + sort_order) |
| SCORE | scores(round_id + player_id + hole, nullable value, version), score_audit |
| RECEIPT | receipts(received_at, deleted_at). 삭제 후에도 과거 수신 사실 유지 |
| DELIVERY | deliveries(고유 id, 대상 슬롯/사용자, pending/received/cancelled) |
| USER COURSE | courses 공용 원본과 user_courses 개인 관계 |
| PEORIA RUN | peoria_runs. 실행 API는 정책 확정 전까지 제공하지 않음 |

SQLite `BEGIN IMMEDIATE` 안에서 활성 기기·라운드 상태·참여·권한을 확인하고 변경을 원자적으로 저장한다. 기기 이전도 기존 인증 폐기와 신규 활성화를 한 트랜잭션에서 처리한다. 라운드 본문에는 관계 엔터티를 중복 원본으로 저장하지 않는다.

스코어 명령은 현재 홀의 셀 변경 목록을 받는다. 각 셀은 `playerId, hole(0 기반), value(null 또는 1~99), expectedVersion`이다. 하나라도 충돌하면 전체 명령이 실패한다. 같은 값이면 이전 버전이어도 멱등 성공한다. 클라이언트는 새 조회 → 변경값 확인 → 새 버전으로 저장하며, 확인 중 재변경되면 다시 확인한다.

## 환경 변수

`.env.example` 참조. 서버는 `NODE_ENV=production`일 때 Secure 쿠키를 사용한다. TLS는 배포 프록시/호스팅에서 제공해야 한다. 브라우저의 Origin은 `ALLOWED_ORIGINS`와 정확히 일치해야 하며 쿠키 인증 POST에는 허용된 Origin이 필수다. 운영 secret이나 DB를 저장소에 넣지 않는다.
